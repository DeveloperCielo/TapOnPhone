#!/bin/bash

# Verifique se o arquivo libppconecta64.so existe e copie para /usr/local/lib
if [ -f "libppconecta64.so" ]; then
    echo "Copiando libppconecta64.so para /usr/local/lib"
    sudo install -v libppconecta64.so /usr/local/lib
    if [ $? -eq 0 ]; then
        echo "libppconecta64.so copiado com sucesso."
    else
        echo "Erro ao copiar libppconecta64.so."
    fi
else
    echo "Aviso: O arquivo libppconecta64.so não existe."
fi

# Verifique se os arquivos de cabeçalho existem antes de copiá-los
if [ -f "ppconecta.h" ]; then
    cp -vfr ppconecta.h /usr/local/include
else
    echo "Aviso: O arquivo ppconecta.h não existe."
fi

if [ -f "ppconecta_pltf.h" ]; then
    cp -vfr ppconecta_pltf.h /usr/local/include
else
    echo "Aviso: O arquivo ppconecta_pltf.h não existe."
fi

# Atualize o cache do linker
echo "Atualizando o cache do linker"
sudo /sbin/ldconfig
if [ $? -eq 0 ]; then
    echo "Cache do linker atualizado com sucesso."
else
    echo "Erro ao atualizar o cache do linker."
fi
