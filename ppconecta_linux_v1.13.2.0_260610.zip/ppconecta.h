/********************************* SETIS - Automa��o e Sistemas ***********************************\
 Arquivo         : ppconecta.h
 Projeto         : Biblioteca de pinpad para o sistema Cielo Conecta
 Plataforma      : Gen�rica
 Data de Criacao : 11/jul/2022
 Autor           : Wilson F. Martins

 Descri��o: Defini��es e fun��es da biblioteca "PPCONECTA". Para mais informa��es, consultar o
            documento "Cielo Conecta - Biblioteca de Pinpad".

 =========================================== HIST�RICO ============================================
 data     |respons�vel |modifica��o
 ---------|------------|---------------------------------------------------------------------------
 26/jun/23|WFM (SETIS) |- Inclu�do comando PPC_CMD_MF_WCARD e entrada PPC_INP_MF_PROMPT.
          |            |- Suporte a pinpad sem display, atrav�s dos retornos PPC_NOTIFY_DSP,
          |            |  PPC_NOTIFY_MNU e PPC_NOTIFY_PIN e dos par�metros PPC_OUT_MENUOPTS e
          |            |  PPC_INP_MENUSEL.
 19/set/24|WFM (SETIS) |- Inclu�dos comandos para gerenciamento e apresenta��o de imagens
          |            |  (PPC_CMD_MM_LIST, PPC_CMD_MM_LOAD, PPC_CMD_MM_DELETE e PPC_CMD_MM_SHOW) e
          |            |  os respectivos par�metros de entrada e sa�da.
\**************************************************************************************************/

#ifndef _PPCONECTA_INCLUDED_
#define _PPCONECTA_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "ppconecta_pltf.h"

/*----------------------------------------------------*/
/*           C�digos de retorno das fun��es           */
/*----------------------------------------------------*/

#define PPC_OK              0  // Comando executado com sucesso.
#define PPC_PROCESSING      1  // Comando em processamento.
#define PPC_NOTIFY          2  // Comando em processamento, mensagem de notifica��o dispon�vel.

#define PPC_F1              4  // Pressionada tecla de fun��o #1.
#define PPC_F2              5  // Pressionada tecla de fun��o #2.
#define PPC_F3              6  // Pressionada tecla de fun��o #3.
#define PPC_F4              7  // Pressionada tecla de fun��o #4.
#define PPC_BACKSP          8  // Pressionada tecla de limpar ("backspace").

#define PPC_INVCALL        10  // Chamada inv�lida � fun��o (opera��es pr�vias s�o necess�rias).
#define PPC_INVPARAM       11  // Um par�metro inv�lido foi passado � fun��o.
#define PPC_TIMEOUT        12  // Esgotado o tempo m�ximo estipulado para a opera��o.
#define PPC_CANCEL         13  // Opera��o cancelada pelo portador do cart�o.
#define PPC_ALREADYOPEN    14  // Biblioteca j� �aberta�.
#define PPC_NOTOPEN        15  // Pinpad n�o foi "aberto" (comando "OPN" n�o foi chamado previamente).
#define PPC_EXECERR        16  // Erro interno de execu��o - problema de implementa��o da biblioteca (software).
#define PPC_INVMODEL       17  // Fun��o n�o suportada.
#define PPC_NOFUNC         18  // Fun��o n�o dispon�vel.
#define PPC_ERRMANDAT      19  // Um par�metro mandat�rio n�o foi enviado pelo SPE.

#define PPC_TABEXP         20  // Vers�o das Tabelas EMV difere da esperada.
#define PPC_TABERR         21  // Erro ao tentar gravar tabelas (falta de espa�o, por exemplo).
#define PPC_DATNFOUND      28  // Dado de resposta n�o foi encontrado.
#define PPC_INVREF         29  // Refer�ncia desconhecida de par�metro de entrada ou dado de resposta.

#define PPC_PORTERR        30  // Erro de comunica��o: porta serial do pinpad provavelmente ocupada.
#define PPC_COMMERR        31  // Erro de comunica��o: pinpad provavelmente desconectado ou problemas com a interface serial.
#define PPC_UNKNOWNSTAT    32  // Status informado pelo pinpad n�o � conhecido.
#define PPC_RSPERR         33  // Mensagem recebida do pinpad possui formato inv�lido.
#define PPC_COMMTOUT       34  // Tempo esgotado ao esperar pela resposta do pinpad (no caso de comandos n�o blocantes).
#define PPC_DATANOTFOUND   35  // Propriet�rio

#define PPC_INTERR         40  // Erro interno do pinpad (situa��o inesperada que n�o possui correspond�ncia com os outros c�digos de erro aqui descritos).
#define PPC_MCDATAERR      41  // Erro de leitura do cart�o magn�tico.
#define PPC_ERRPIN         42  // MK / DUKPT referenciado n�o est� presente no pinpad.
#define PPC_NOCARD         43  // N�o h� ICC presente no acoplador ou CTLS detectado na antena.
#define PPC_PINBUSY        44  // Pinpad n�o pode processar a captura de PIN temporariamente devido a quest�es de seguran�a.
#define PPC_RSPOVRFL       45  // Montagem dos dados de resposta supera o tamanho m�ximo permitido.
#define PPC_RSP1           46  // Reservado
#define PPC_SECURITY       47  // Cartao nao removido na ultima transacao

#define PPC_SAMERR         50  // Erro gen�rico no m�dulo SAM.
#define PPC_NOSAM          51  // SAM ausente, "mudo", ou com erro de comunica��o.
#define PPC_SAMINV         52  // SAM inv�lido, desconhecido ou com problemas.

#define PPC_DUMBCARD       60  // ICC ausente ou n�o responde ("mudo").
#define PPC_ERRCARD        61  // Erro de comunica��o do terminal com o cart�o com chip.
#define PPC_CARDINV        62  // Cart�o do tipo inv�lido ou desconhecido, n�o pode ser tratado.
#define PPC_CARDINVALIDAT  67  // Cart�o foi invalidado (Comando Select retornou status �6283�).
#define PPC_CARDPROBLEMS   68  // ICC com problemas.
#define PPC_CARDINVDATA    69  // O ICC comporta-se corretamente, por�m possui dados inv�lidos ou inconsistentes.
#define PPC_CARDAPPNAV     70  // ICC EMV sem nenhuma aplica��o dispon�vel para as condi��es pedidas.
#define PPC_CARDAPPNAUT    71  // A aplica��o selecionada no ICC EMV n�o pode ser utilizada nesta situa��o.
#define PPC_ERRFALLBACK    76  // Erro de alto n�vel no ICC EMV que � pass�vel de "fallback" para tarja magn�tica.
#define PPC_INVAMOUNT      77  // Valor inv�lido para a transa��o.
#define PPC_ERRMAXAID      78  // N�mero de AIDs candidatos supera a capacidade de tratamento do Kernel EMV.
#define PPC_ERRCARDBLOCKED 79  // Cart�o bloqueado - quando sele��o de aplica��o retornar status 6A81.

#define PPC_CTLSSMULTIPLE  80  // Mais de um CTLS foi apresentado ao leitor simultaneamente.
#define PPC_CTLSSCOMMERR   81  // Erro de comunica��o entre o pinpad (antena) e o CTLS.
#define PPC_CTLSSINVALIDAT 82  // CTLS foi invalidado.
#define PPC_CTLSSPROBLEMS  83  // CTLS com problemas.
#define PPC_CTLSSAPPNAV    84  // CTLS sem nenhuma aplica��o dispon�vel para as condi��es pedidas.
#define PPC_CTLSSAPPNAUT   85  // A aplica��o selecionada no CTLS n�o pode ser utilizada nesta situa��o.

#define PPC_MFNFOUND      100  // Arquivo multim�dia inexistente.
#define PPC_MFERRFMT      101  // Erro no formato do arquivo multim�dia.
#define PPC_MFERR         102  // Erro na carga do arquivo multim�dia.
#define PPC_MFSRCNFOUND   110  // Arquivo de imagem original n�o encontrado no PC.

#define PPC_SW_WARNING                 120   /* Maximum error code for warning SW error codes */
#define PPC_SW_FILEINVALIDATED         121   /* '6283' File invalidated */
#define PPC_SW_AUTHFAILED              122   /* '6300' Authentication failed */
#define PPC_SW_COUNTER_MAX             123   /* '63Cx' - Maximum value */
#define PPC_SW_COUNTER_MIN             124   /* '63Cx' - Minimum value (this value is always incremented by 'x') */
#define PPC_SW_WARNING_OTHER           125   /* Other 'warning' value of SW */
#define PPC_SW_WARNING_MIN             126   /* Minimum error code for warning SW error codes */
#define PPC_SW_ABORT_MAX               127   /* Maximum error code for abortion SW error codes */                
#define PPC_SW_AUTHBLOCKED             129   /* '6983' Authentication method blocked */
#define PPC_SW_DATAINVALIDATED         130   /* '6984' Referenced data invalidated */
#define PPC_SW_CONDNOTSATISFIED        131   /* '6985' Conditions of use not statisfied */
#define PPC_SW_FUNCTIONNOTSUPPORTED    132   /* '6A81' Function not supported */
#define PPC_SW_FILENOTFOUND            133   /* '6A82' File not found */
#define PPC_SW_RECORDNOTFOUND          134   /* '6A83' Record not found */
#define PPC_SW_DATANOTFOUND            135   /* '6A88' Referenced data not found */
#define PPC_SW_ABORT_OTHER             136   /* Other 'abortion' value of SW */
#define PPC_SW_ABORT_MIN               137   /* Minimum error code for abortion SW error codes */
#define PPC_SW_MIN                     140   /* Minimum error code for SW error codes */

#define PPC_INVLICENSE    200  // C�digo de licen�a inv�lido.
#define PPC_INVCOMPANY    201  // Nome da empresa incompat�vel com licen�a.
#define PPC_EXPLICENSE    202  // Licen�a expirada.

#define PPC_NOTIFY_DSP   1001  // Pinpad sem display: notifica��o para mensagem de display do pinpad.
#define PPC_NOTIFY_MNU   1002  // Pinpad sem display: notifica��o para apresenta��o de menu de sele��o de aplica��o.
#define PPC_NOTIFY_PIN   1003  // Pinpad sem display: notifica��o indicando quantos d�gitos de PIN est�o sendo capturados.


/*----------------------------------------------------*/
/*                Fun��es da PPCONECTA                */
/*----------------------------------------------------*/


int  LIBEXP PPC_SetParam(int iParam, const char *pszValue, int iLen);
int  LIBEXP PPC_ExecCmdNBlk(int iCmdRef);
int  LIBEXP PPC_StartExecCmd(int iCmdRef);
int  LIBEXP PPC_FinishExecCmd(char *psNotify);
void LIBEXP PPC_AbortCmd(void);
int  LIBEXP PPC_GetResp(int iRespDat, int iMaxLen, char *pszValue);


/*----------------------------------------------------*/
/*                Comandos da PPCONECTA               */
/*----------------------------------------------------*/

#define PPC_CMD_INIT        0 // [n�o bloc] Inicializa a PPCONECTA.
#define PPC_CMD_OPEN        1 // [n�o bloc] Aloca os recursos de hardware e software para utiliza��o da PPCONECTA.
#define PPC_CMD_CLOSE       2 // [n�o bloc] Libera os recursos de hardware e software alocados � PPCONECTA.
#define PPC_CMD_TEST        3 // [n�o bloc] Testa se existe um pinpad conectado em uma determinada porta do dispositivo.
#define PPC_CMD_VERSAO      4 // [n�o bloc] Retorna a versao da lib

#define PPC_CMD_DISPLAY    11 // [n�o bloc] Apresenta mensagem no display.
#define PPC_CMD_GETCLRDATA 12 // [blocante] Captura dado em aberto no teclado do pinpad.
#define PPC_CMD_GETKEY     13 // [blocante] Aguarda digita��o de tecla n�o num�rica.
#define PPC_CMD_GETPIN     14 // [blocante] Captura a senha criptografada do portador do cart�o magn�tico.
#define PPC_CMD_ENCPAN     15 // [n�o bloc] Criptografa o n�mero do cart�o digitado naAplica��o de Pagamento.
#define PPC_CMD_REMCARD    16 // [blocante] Aguarda a remo��o do cart�o com chip.
#define PPC_CMD_DISPLAYEX  17 // [n�o bloc] Apresenta mensagem no display estendido.

#define PPC_CMD_TAB_VER    31 // [n�o bloc] Obt�m a vers�o das Tabelas EMV carregadas no pinpad.
#define PPC_CMD_TAB_LOAD   32 // [n�o bloc] Carrega um conjunto de tabelas no pinpad.

#define PPC_CMD_GETCARD    41 // [blocante] Solicita a apresenta��o de cart�o, seja magn�tico, chip com contato ou contactless.
#define PPC_CMD_GETTRACKS  42 // [n�o bloc] Obt�m as trilhas completas do cart�o, criptografadas ou em claro.
#define PPC_CMD_PROCCHIP   43 // [blocante] Continua o processamento se for cart�o com chip (com contato ou contactless).
#define PPC_CMD_FINISHCHIP 44 // [blocante] Finaliza o processamento online de cart�o com chip (com contato ou contactless).

#define PPC_CMD_MM_LIST    51 // [n�o bloc] Lista os nomes dos arquivos de imagem carregadosno pinpad.
#define PPC_CMD_MM_LOAD    52 // [n�o bloc] Carrega um arquivo de imagem no pinpad.
#define PPC_CMD_MM_DELETE  53 // [n�o bloc] Exclui um arquivo de imagem do pinpad.
#define PPC_CMD_MM_SHOW    54 // [n�o bloc] Apresenta um arquivo de imagem no display.

#define PPC_CMD_PIXNFC     61  // [blocante] PIX por aproxima��o
#define PPC_CMD_MNU        62  // [blocante] Menu no pinpad

#define PPC_CMD_MF_ACTIV   90 // [n�o bloc] Activation
#define PPC_CMD_MF_AUTH    91 // [n�o bloc] Authentication
#define PPC_CMD_MF_WRITE   92 // [n�o bloc] Write
#define PPC_CMD_MF_READ    93 // [n�o bloc] Read
#define PPC_CMD_MF_OPER    94 // [n�o bloc] Operation
#define PPC_CMD_MF_BLKCFG  95 // [n�o bloc] Block Configuration
#define PPC_CMD_MF_KEYCHG  96 // [n�o bloc] Key Change
#define PPC_CMD_MF_WCARD   97 // [blocante] Aguarda cart�o Mifare ou magn�tico


/*----------------------------------------------------*/
/*        Par�metros de Entrada dos comandos          */
/*----------------------------------------------------*/

#define PPC_INP_COMM        1 // [A..32] Porta de comunica��o onde est� conectado o pinpad, sendo que o formato depende da plataforma.
                              //         Windows: �COMnnn�, sendo �n� o n�mero da porta serial (ex.: �COM7�, �COM65�)
                              //         Linux: Nome do device (ex.: �/dev/ttyS0�).
                              //         Android: Ver documenta��o fornecida com a biblioteca
#define PPC_INP_DSPMSG      2 // [A32] Mensagem de 2 linhas por 16 colunas para apresenta��o no display do pinpad.
#define PPC_INP_MSGIDX      3 // [N..3] �ndice da mensagem a ser apresentada.
#define PPC_INP_MINDIG      4 // [N..2] Quantidade m�nima de d�gitos a ser capturada no pinpad (de 0 a 32).
#define PPC_INP_MAXDIG      5 // [N..2] Quantidade m�xima de d�gitos a ser capturada no pinpad (de 1 a 32).
#define PPC_INP_TIMEOUT     6 // [N..3] Tempo de espera por uma a��o do portador do cart�o (em segundos - at� 255).
#define PPC_INP_PAN         7 // [N..19] N�mero do cart�o (PAN).
#define PPC_INP_KEYIDX      8 // [N..2] �ndice da chave de criptografia a ser utilizada.
#define PPC_INP_INITVER     9 // [A10] �ltimos 10 caracteres da Vers�o da Inicializa��o.
#define PPC_INP_TABAID     10 // [A..var] Conjunto de Tabelas de AID
#define PPC_INP_TABCAPK    11 // [A..var] Conjunto de Tabelas de Chaves P�blicas EMV
#define PPC_INP_APPTYPE    12 // [N2] Tipo de aplica��o desejada se cart�o com chip:
                              //      �01� = cr�dito
                              //      �02� = d�bito
#define PPC_INP_AMOUNT     13 // [N..12] Valor total da transa��o, em centavos, podendo ou n�o ter zeros � esquerda.
#define PPC_INP_CASHBACK   14 // [N..12] Valor do cashback, em centavos, podendo ou n�o ter zeros � esquerda.
#define PPC_INP_DATETIME   15 // [A19] Data e hora da transa��o no formato: �AAAA-MM-DDThh:mm:ss�
#define PPC_INP_TRNTYPE    16 // [N2] Tipo de transa��o:
                              //      �00� = Compra;
                              //      �01� = Saque;
                              //      �09� = Compra com saque/troco (cashback);
                              //      �20� = Cancelamento (refund);
                              //      �30� = Consulta de saldo; ou
                              //      Outros valores de acordo com ISO 8583:1987.
#define PPC_INP_GTMODE     17 // [N1] Forma de opera��o do comando PPC_CMD_GETTRACKS:
                              //      �0� = Devolver trilhas em claro; ou
                              //      �1� = Devolver as trilhas criptografadas.
#define PPC_INP_FLRLIMIT   18 // [N..12] Par�metro para processamento EMV: Floor Limit
#define PPC_INP_THRSVAL    19 // [N..12] Par�metro para processamento EMV: Threshold Value
#define PPC_INP_TGTPRCT    20 // [N..2] Par�metro para processamento EMV: Target Percentage to Be Used For Biased Random Selection
#define PPC_INP_MAXTPRCT   21 // [N..2] Par�metro para processamento EMV: Maximum Target Percentage to Be Used For Biased Random Selection
#define PPC_INP_TAGLIST    22 // [H..256] Lista de tags referentes aos objetos EMV requeridos na resposta do comando.
#define PPC_INP_ENCMETHD   23 // [N1] M�todo de criptografia a ser utilizado:
                              //      �1� = Master Key / Working Key Triple-DES; ou
                              //      �3� = DUKPT Triple-DES.
#define PPC_INP_RETCODE    24 // [N..3] C�digo de resposta de autoriza��o do Host Cielo (Authorization Response Code)
#define PPC_INP_EMVDATA    25 // [H..1024] Objetos EMV devolvidos pelo Host Cielo na resposta da autoriza��o, em formato TLV.
#define PPC_INP_WKENC      26 // [H32] Working Key Triple-DES criptografada pela Master Key
#define PPC_INP_CTLSON     27 // [N1] Indica se a interface de cart�o sem contato deve ser ativada ("0" = desativa, "1" = ativa)
#define PPC_INP_MM_NAME    28 // [A8] Nome do arquivo multim�dia (sempre 8 caracteres num�ricos e letras, sem espa�os ou s�mbolos).
#define PPC_INP_MM_FILE    29 // [A..var] Nome do arquivo de imagem no PC, com caminho completo (ex.: �C:\temp\qrcode.png�).
#define PPC_INP_CS_KMOD    40 // [H512] M�dulo da chave RSA a ser usada no processo de �Comunica��o Segura� do pinpad v2.xx (obrigatoriamente de 2048 bits).
#define PPC_INP_CS_KPUB    41 // [H..6] Expoente p�blico da chave RSA a ser usada no processo de �Comunica��o Segura� do pinpad v2.xx (normalmente �03� ou �010001�).
#define PPC_INP_CS_KPRV    42 // [H512] Expoente privado da chave RSA a ser usada no processo de �Comunica��o Segura�.
#define PPC_INP_WKP_KMOD   43 // [H256] M�dulo da chave RSA a ser usada no processo de �PAN Criptografado� do pinpad v1.08 (obrigatoriamente de 1024 bits).
#define PPC_INP_WKP_KPUB   44 // [H..6] Expoente p�blico da chave RSA a ser usada no processo de �PAN Criptografado� do pinpad v1.08 (normalmente �03� ou �010001�).
#define PPC_INP_WKP_KPRV   45 // [H256] Expoente privado da chave RSA a ser usada no processo de �PAN Criptografado� do�pinpad v1.08.
#define PPC_INP_LOG_FNAME  46 // [A..200] Nome do arquivo de log para depura��o da biblioteca, com caminho completo (ex.: �C:\logs\debug.log�).
#define PPC_INP_LICENSE    47 // [H32] C�digo de licen�a para uso da biblioteca.
#define PPC_INP_COMPANY    48 // [A..32] Nome da empresa a quem a licen�a foi concedida.
#define PPC_INP_MENUSEL    49 // [N1] Op��o selecionada no menu, para pinpad sem display (PPC_NOTIFY_MNU).
#define PPC_INP_AIDPIXNFC  50 // AID Para o PIX NFC
#define PPC_INP_HOSTPIX    51 // Host ao qual o PIX foi gerado
#define PPC_INP_QRCODE     52 // Valor da String QRCode a ser processada
#define PPC_INP_PROMPT_MNU 53 // Prompt do Menu a ser apresentado no PP
#define PPC_INP_ITEM_MNU   54 // Item do Menu
#define PPC_INP_NUMITEMMNU 55 // N�mero de itens do Menu
#define PPC_INP_DSPMSGEX   56 // [S...160] Mensagem a ser apresentada, podendo excepcionalmente conter 
                              // o caractere de controle CR(0Dh) para quebra de linha.

#define PPC_INP_MF_PROMPT  87 // [A..70] Mifare - Mensagem a ser apresentada no display para solicitar o cart�o, com formato livre e quebras de linha usando �\r�.
#define PPC_INP_MF_KEYTYP2 88 // [A1] Mifare - Key Type (�A� ou �B�).
#define PPC_INP_MF_KEYVAL2 89 // [H12] Mifare - Key Value.
#define PPC_INP_MF_BLKADR  90 // [N4] Mifare - Block Address (�0000� a �9999�).
#define PPC_INP_MF_KEYTYP  91 // [A1] Mifare - Key Type (�A� ou �B�).
#define PPC_INP_MF_KEYVAL  92 // [H12] Mifare - Key Value.
#define PPC_INP_MF_SERNO   93 // [H..32] Mifare -Serial Number.
#define PPC_INP_MF_BYTEPOS 94 // [N2] Mifare- Posi��o do byte no bloco (�00� a �15�).
#define PPC_INP_MF_DATA    95 // [H..32] Mifare - dados de entrada do comando.
#define PPC_INP_MF_DSTADR  96 // [N4] Mifare - Block Address (�0000� a �9999�) de destino.
#define PPC_INP_MF_OPER    97 // [A1] Mifare - opera��o a ser efetuada:
                              //      �W�: Armazena valor;
                              //      �R�: L� valor;
                              //      �+�: Soma;
                              //      �-�: Subtrai;
                              //      �=�: Copia valor do destino para a origem.
#define PPC_INP_MF_VALUE   98 // [A..11] Mifare - Valor de 32 bits com sinal, de �-2147483648� a �2147483647�.
#define PPC_INP_MF_BITCFG  99 // [N3] Mifare - Bits de configura��o C1C2C3 (�000� a �111�).


/*----------------------------------------------------*/
/*          Dados de Resposta dos comandos            */
/*----------------------------------------------------*/

#define PPC_OUT_SERNUM     100 // [A..32] N�mero de s�rie do pinpad(formato livre, depende do fabricante).
#define PPC_OUT_PHYSCHR    101 // [A..64] Caracter�sticas f�sicas do pinpad, podendo ser:
                               //         �PinPadWithChipReaderWithoutSamModule�;
                               //         �PinPadWithChipReaderWithSamModule�;
                               //         �PinPadWithChipReaderWithoutSamAndContactless�; ou
                               //         �PinPadWithChipReaderWithSamModuleAndContactless�
#define PPC_OUT_RETDTINF   102 // [N3] C�digo de retorno do comando �GIN�/�GIX�.
#define PPC_OUT_EMVVER     103 // [A..20] Vers�o do Kernel EMV para cart�o contato.
#define PPC_OUT_CTLSVER    104 // [A..20] Vers�o principal do Kernel EMV para contactless.
#define PPC_OUT_MCVER      105 // [A..20] Vers�o do Kernel EMV CTLS para cart�es MasterCard PayPass.
#define PPC_OUT_VSVER      106 // [A..20] Vers�o do Kernel EMV CTLS para cart�es VISA PayWave.
#define PPC_OUT_HWMODEL    107 // [A..20] Modelo/vers�o do hardware.
#define PPC_OUT_MANUFCT    108 // [A..20] Nome do fabricante do pinpad (formato livre).
#define PPC_OUT_FWVER      109 // [A..20] Vers�o do software b�sico ou sistema operacional (formato livre).
#define PPC_OUT_BLIBVER    110 // [A16] Vers�o da aplica��o �Gerenciadora�, no formato �VVV.VVAAMMDD�.
#define PPC_OUT_SPECVER    111 // [A4] Vers�o da especifica��o, no formato �V.VV�.
#define PPC_OUT_ACQVER     112 // [A16] Vers�o da aplica��o da rede adquirente, no formato �VVV.VV AAMMDD�.
#define PPC_OUT_VALUE      113 // [N..32] Valor digitado no teclado do pinpad.
#define PPC_OUT_PINBLK     114 // [H16] PIN criptografado.
#define PPC_OUT_PINKSN     115 // [H20] KSN (Key Serial Number) do processo DUKPT para criptografia do PIN.
#define PPC_OUT_ENCTYPE    116 // [A..16] Tipo de criptografia usada no comando: �MasterKey�, �Dukpt3Des� ou �Dukpt3DesCBC�
#define PPC_OUT_TABVER     117 // [A10] Vers�o das tabelas carregadas no pinpad.
#define PPC_OUT_ENCPAN     118 // [H..32] N�mero do cart�o criptografado.
#define PPC_OUT_PANKSN     119 // [H20] KSN (Key Serial Number) do processo DUKPT para criptografia do n�mero do cart�o (PAN).
#define PPC_OUT_CBCIV      120 // [H16] Initialization Vector (�IV�) usado na criptografia quando em modo CBC.
#define PPC_OUT_CARDTYPE   121 // [A..20] Tipo de cart�o utilizado: �MagStripe�, �Emv�, �ContactlessMagStripe� ou �ContactlessEmv�.
#define PPC_OUT_CARDBIN    122 // [N6] BIN do cart�o (6 primeiros d�gitos � direita).
#define PPC_OUT_CARDAID    123 // [H..32] AID do cart�o com chip.
#define PPC_OUT_SERVCODE   124 // [N3] C�digo de Servi�o do cart�o magn�tico.
#define PPC_OUT_CHNAME     125 // [A..26] Nome do portador do cart�o.
#define PPC_OUT_PANSEQNBR  126 // [N..2] PAN Sequence Number do cart�o com chip.
#define PPC_OUT_CARDEXP    127 // [A7] Data de expira��o do cart�o, no formado �MM/AAAA�
#define PPC_OUT_ISFBACK    128 // [A..5] Se o cart�o magn�tico sendo passado � resultado de uma opera��o de fallback por erro no cart�o com chip. (booleano �true� ou �false�).
#define PPC_OUT_TRACK1     129 // [A..176] Trilha 1 do cart�o, em claro ou criptografada.
#define PPC_OUT_TRACK2     130 // [A..56] Trilha 2 do cart�o, em claro ou criptografada.
#define PPC_OUT_TRK1KSN    131 // [H20] KSN (Key Serial Number) do processo DUKPT para criptografia da Trilha 1.
#define PPC_OUT_TRK2KSN    132 // [H20] KSN (Key Serial Number) do processo DUKPT para criptografia da Trilha 2.
#define PPC_OUT_AUTHMET    133 // [A..24] M�todo de autentica��o de portador usado na transa��o, podendo ser: �NoPassword�, �OnlineAuthentication� ou �OfflineAuthentication�.
#define PPC_OUT_RESULT     134 // [N1] Resultado de PPC_CMD_PROCCHIP:
                               //      �0� = Transa��o aprovada offline;
                               //      �1� = Transa��o negada offline; ou
                               //      �2� = Transa��o requer autoriza��o online.
#define PPC_OUT_EMVDATA    135 // [H..1024] Lista de objetos EMV resultantes do processamento, em formato TLV.
#define PPC_OUT_FINALRES   136 // [N1] Resultado de PPC_CMD_FINISHCHIP:
                               //      �0� = Transa��o aprovada offline pelo cart�o;
                               //      �1� = Transa��o negada
                               //      �2� = Transa��o aprovada online; ou
                               //      �3� = Transa��o aprovada online foi negada pelo cart�o (desfazer).
#define PPC_OUT_SCRIPTRES  137 // [H..100] Resultado do processamento de Issuer Scripts EMV.
#define PPC_OUT_PAN        138 // [N..19] N�mero do cart�o (PAN).
#define PPC_OUT_VERLIB     139 // [A..20] Vers�o da biblioteca PPCONECTA (formato livre).
#define PPC_OUT_LABEL      140 // [A..16] �Label� da aplica��o do cart�o com chip.
#define PPC_OUT_APLCRYPT   141 // [H16] Criptograma gerado pelo cart�o com chip.
#define PPC_OUT_LICEXPDATE 142 // [N6] Data de expira��o da licen�a fornecida no formato AAMMDD
#define PPC_OUT_VALCODE    143 // [H4] C�digo de valida��o gerado em PPC_CMD_GETCARD
#define PPC_OUT_MENUOPTS   144 // [A..160] Op��es de menu, para pinpad sem display, cada uma com 16 caracteres (PPC_NOTIFY_MNU).
#define PPC_OUT_4LASTDIG   145 // [N4] Quatro �ltimos d�gitos do n�mero do cart�o (PAN).
#define PPC_OUT_CARDID     146 // [A..44] C�digo de refer�ncia para identifica��o do cart�o.
#define PPC_OUT_MM_LIST    147 // [A..180] Lista dos nomes dos arquivos multim�dia carregados no pinpad, separados pelo caractere �/� (2Fh).
#define PPC_OUT_MM_SUP     148 // [A..20] Tipos de arquivo multim�dia suportados: �1xxx...� = Suporta o formato PNG; �x1xx...� = Suporta o formato JPG. �xx1x...� = Suporta o formato GIF.
#define PPC_OUT_MM_DSPSZ   149 // [N8] N�mero m�ximo de linhas e colunas do display gr�fico do pinpad para apresenta��o de arquivos multim�dia (formato �LLLLCCCC�, em pixels).
#define PPC_OUT_MNU_SEL    150 // [N02] Item do menu selecionado. 
#define PPC_OUT_MM_DSPTXT  151 // []

/*  */
#define PPC_OUT_MF_SERNO   197 // [H..32] N�mero de s�rie do cart�o Mifare.
#define PPC_OUT_MF_DATA    198 // [H..32] Mifare - dados de sa�da do comando.
#define PPC_OUT_MF_VALUE   199 // [A..11] Valor de 32 bits com sinal, de �-2147483648� a �2147483647�

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif // -- #ifndef _PPCONECTA_INCLUDED_
