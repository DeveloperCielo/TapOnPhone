# Manual Extrato Eletronico Cielo (AI-friendly)

Este pacote organiza o manual de Extrato Eletronico Cielo para consumo por times de implantacao, engenharia e agentes de IA.

## Fluxo oficial para clientes

A execucao oficial para cliente esta definida somente em `quickstart-implantacao.md`.

Use este arquivo para:

1. Pre-requisitos.
2. Instalacao.
3. Validacao estrutural.
4. Homologacao.
5. Troubleshooting basico.

Os demais documentos deste repositorio sao referencia complementar.

## Estrutura principal do toolkit

- `2.manual-extrato-v15.15.schema.json`: contrato canonico.
- `3.schemas/`: layouts posicionais dos registros.
- `4.tabelas/`: dominios codificados (tabelas I a XI).
- `5.manual-completo.md`: narrativa consolidada do manual.
- `6.glossario.md`: normalizacao de termos.
- `prompts/7.prompt-implantacao-ai.md`: prompt de implantacao para LLM.
- `resultado-validacao.schema.json`: contrato de saida da validacao.
- `resultado-conciliacao.schema.json`: contrato de saida da conciliacao.
- `scripts/`: automacoes do toolkit.
- `.github/workflows/manual-extrato-ci.yml`: quality gates em CI.

## Referencias complementares

- `1.toolkit-uso-em-ia.md`: playbook tecnico para consumo por agentes.
- `8.onboarding-operacional-cliente.md`: onboarding operacional do cliente.
- `integracao-bancaria-interface.md`: interface de conciliacao com extrato bancario.
- `troubleshooting-operacional.md`: runbook de incidentes.

## Validacao rapida da estrutura

Execute na raiz deste diretorio:

```bash
python scripts/validate_manual_package.py
```

## Homologacao rapida

```bash
python scripts/run_homologation_suite.py
```

## Fonte do manual

- DOCX oficial: `CIELO_Extrato_Eletronico_-_Manual_-_Versao_15_15.docx`
