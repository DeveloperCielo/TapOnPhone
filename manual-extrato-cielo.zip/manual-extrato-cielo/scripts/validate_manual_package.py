import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCHEMAS_DIR = ROOT / "3.schemas"
TABLES_DIR = ROOT / "4.tabelas"


def _load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _load_json_safe(path: Path, errors: list[str], label: str):
    if not path.exists():
        errors.append(f"missing_required_file:{path.relative_to(ROOT)}")
        return {}
    try:
        return _load_json(path)
    except Exception as exc:
        errors.append(f"invalid_json:{label}:{path.relative_to(ROOT)}:{exc}")
        return {}


def validate_package() -> int:
    errors = []

    required_dirs = [
        SCHEMAS_DIR,
        TABLES_DIR,
        ROOT / "prompts",
    ]

    for path in required_dirs:
        if not path.is_dir():
            errors.append(f"missing_required_directory:{path.relative_to(ROOT)}")

    required_files = [
        ROOT / "2.manual-extrato-v15.15.schema.json",
        ROOT / "5.manual-completo.md",
        ROOT / "6.glossario.md",
        ROOT / "changelog" / "versoes.yaml",
        ROOT / "prompts" / "7.prompt-implantacao-ai.md",
        SCHEMAS_DIR / "_index.json",
        TABLES_DIR / "_index.json",
        TABLES_DIR / "tabela-IX-motivos-ajuste.normalized.json",
        TABLES_DIR / "tabela-IX-motivos-ajuste.refined.json",
        ROOT / "resultado-validacao.schema.json",
        ROOT / "resultado-conciliacao.schema.json",
    ]

    for path in required_files:
        if not path.exists():
            msg = f"missing_required_file:{path.relative_to(ROOT)}"
            if path.name == "tabela-IX-motivos-ajuste.normalized.json":
                msg += ":run_python_scripts/normalize_table_ix.py"
            if path.name == "tabela-IX-motivos-ajuste.refined.json":
                msg += ":run_python_scripts/refine_table_ix_near_duplicates.py"
            errors.append(msg)

    tables_index = _load_json_safe(TABLES_DIR / "_index.json", errors, "tables_index")
    schemas_index = _load_json_safe(SCHEMAS_DIR / "_index.json", errors, "schemas_index")

    for table_id in tables_index.get("tables_expected", []):
        filename = f"tabela-{table_id}-"
        matches = [
            p
            for p in TABLES_DIR.glob(f"{filename}*.json")
            if ".normalized." not in p.name and ".refined." not in p.name
        ]
        if not matches:
            errors.append(f"missing_table_file:{table_id}")

    record_to_filename = {
        "0": "registro-0-header.json",
        "D": "registro-D-ur-agenda.json",
        "E": "registro-E-lancamento.json",
        "8": "registro-8-pix.json",
        "A": "registro-A-resumo-negociacao.json",
        "B": "registro-B-detalhe-negociacao.json",
        "C": "registro-C-conta-negociacao.json",
        "R": "registro-R-reserva-financeira.json",
        "9": "registro-9-trailer.json",
    }
    for record_id in schemas_index.get("records_expected", []):
        filename = record_to_filename.get(record_id)
        if not filename:
            errors.append(f"unknown_record_expected:{record_id}")
            continue
        if not (SCHEMAS_DIR / filename).exists():
            errors.append(f"missing_schema_file:{filename}")

    status = "ok" if not errors else "error"
    report = {
        "status": status,
        "errors": errors,
        "tables_expected": tables_index.get("tables_expected", []),
        "records_expected": schemas_index.get("records_expected", []),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(validate_package())
