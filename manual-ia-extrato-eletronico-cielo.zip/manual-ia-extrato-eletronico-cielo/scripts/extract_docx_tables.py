import argparse
import json
import re
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List


NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

# Observed stable block for domain tables in v15.15 document.
TABLE_INDEX_TO_ROMAN = {
    31: "I",
    32: "II",
    33: "III",
    34: "IV",
    35: "V",
    36: "VI",
    37: "VII",
    38: "VIII",
    39: "IX",
    40: "X",
    41: "XI",
}

ROMAN_TO_CANONICAL_FILENAME = {
    "I": "tabela-I-tipos-arquivo.json",
    "II": "tabela-II-tipos-lancamento.json",
    "III": "tabela-III-tipos-registro.json",
    "IV": "tabela-IV-status-pagamento.json",
    "V": "tabela-V-formas-pagamento.json",
    "VI": "tabela-VI-origem-ajuste-pix.json",
    "VII": "tabela-VII-status-debito-conta.json",
    "VIII": "tabela-VIII-tipo-captura.json",
    "IX": "tabela-IX-motivos-ajuste.json",
    "X": "tabela-X-bandeiras.json",
    "XI": "tabela-XI-efeitos-negociacao.json",
}


def _norm(text: str) -> str:
    text = re.sub(r"\s+", " ", text or "").strip()
    return text


def _sanitize_key(text: str, idx: int) -> str:
    raw = _norm(text).lower()
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    canonical_map = {
        "codigo": "codigo",
        "descricao": "descricao",
        "ini": "ini",
        "fim": "fim",
        "tam": "tam",
        "tipo": "tipo",
        "consistencias edi": "consistencias_edi",
    }
    if raw in canonical_map:
        return canonical_map[raw]

    key = raw
    key = key.replace("%", " pct ")
    key = re.sub(r"[^a-z0-9]+", "_", key)
    key = re.sub(r"_+", "_", key).strip("_")
    return key or f"coluna_{idx + 1}"


def _extract_tables(document_xml: Path) -> List[dict]:
    root = ET.parse(document_xml).getroot()
    body = root.find("w:body", NS)
    if body is None:
        return []

    recent_paragraphs: List[str] = []
    tables = []
    table_idx = 0

    for block in list(body):
        tag = block.tag.rsplit("}", 1)[-1]
        if tag == "p":
            txt = _norm("".join(t.text or "" for t in block.findall(".//w:t", NS)))
            if txt:
                recent_paragraphs.append(txt)
                if len(recent_paragraphs) > 8:
                    recent_paragraphs = recent_paragraphs[-8:]
            continue

        if tag != "tbl":
            continue

        table_idx += 1
        rows: List[List[str]] = []
        for tr in block.findall(".//w:tr", NS):
            cells = []
            for tc in tr.findall("./w:tc", NS):
                cell_texts = []
                for p in tc.findall(".//w:p", NS):
                    segment = _norm("".join(t.text or "" for t in p.findall(".//w:t", NS)))
                    if segment:
                        cell_texts.append(segment)
                cells.append(_norm(" ".join(cell_texts)))
            if any(cells):
                rows.append(cells)

        title = recent_paragraphs[-1] if recent_paragraphs else ""
        context = " | ".join(recent_paragraphs)
        roman_match = list(re.finditer(r"Tabela\s+([IVXLCDM]+)", context, flags=re.IGNORECASE))
        inferred_roman = roman_match[-1].group(1).upper() if roman_match else ""

        tables.append(
            {
                "table_index": table_idx,
                "title": title,
                "inferred_roman": inferred_roman,
                "row_count": len(rows),
                "col_count": max((len(r) for r in rows), default=0),
                "rows": rows,
            }
        )

    return tables


def _table_to_domain_payload(roman: str, table: dict) -> dict:
    rows = table.get("rows", [])
    header = rows[0] if rows else []
    body_rows = rows[1:] if len(rows) > 1 else []

    if not header:
        header = ["codigo", "descricao"]

    col_count = max([len(header)] + [len(r) for r in body_rows] + [2])
    padded_header = header + [f"coluna_{i + 1}" for i in range(len(header), col_count)]
    keys = [_sanitize_key(h, i) for i, h in enumerate(padded_header)]

    domain = []
    for row in body_rows:
        padded = row + [""] * (col_count - len(row))
        item = {keys[i]: padded[i] for i in range(col_count)}
        if any(v for v in item.values()):
            domain.append(item)

    return {
        "tabela": roman,
        "nome": table.get("title", "").strip() or f"Tabela {roman}",
        "source": {
            "type": "docx",
            "document": "CIELO_Extrato_Eletronico_-_Manual_-_Versao_15_15.docx",
            "table_index": table.get("table_index"),
            "inferred_roman": table.get("inferred_roman", ""),
        },
        "header": padded_header,
        "dominio": domain,
        "completude": "extraido_docx",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Extrai tabelas do manual DOCX para JSON")
    parser.add_argument("--workspace", default=".", help="Diretorio base do pacote")
    parser.add_argument("--promote", action="store_true", help="Atualiza tabelas canonicas em contracts/tabelas/")
    args = parser.parse_args()

    root = Path(args.workspace)
    docx_xml = root / "internal" / "_docx_unzip" / "word" / "document.xml"
    if not docx_xml.exists():
        print(json.dumps({"status": "error", "message": f"missing:{docx_xml}"}, ensure_ascii=False))
        return 1

    tables = _extract_tables(docx_xml)

    extracted_dir = root / "internal" / "oficial-docx" / "tabelas"
    extracted_dir.mkdir(parents=True, exist_ok=True)

    (extracted_dir / "_all_tables_raw.json").write_text(
        json.dumps(tables, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    promoted = []
    generated = []
    for idx, roman in TABLE_INDEX_TO_ROMAN.items():
        table = next((t for t in tables if t.get("table_index") == idx), None)
        if not table:
            continue

        payload = _table_to_domain_payload(roman, table)
        out_name = ROMAN_TO_CANONICAL_FILENAME.get(roman, f"tabela-{roman}.json")
        extracted_path = extracted_dir / out_name
        extracted_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        generated.append(str(extracted_path.as_posix()))

        if args.promote:
            canonical_path = root / "contracts" / "tabelas" / out_name
            canonical_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            promoted.append(str(canonical_path.as_posix()))

    report = {
        "status": "ok",
        "tables_total": len(tables),
        "generated": generated,
        "promoted": promoted,
        "raw_output": str((extracted_dir / "_all_tables_raw.json").as_posix()),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
