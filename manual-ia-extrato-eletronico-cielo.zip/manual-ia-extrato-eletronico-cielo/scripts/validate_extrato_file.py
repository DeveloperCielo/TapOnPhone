import argparse
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "contracts" / "2.manual-extrato-v15.15.schema.json"
SCHEMAS_DIR = ROOT / "contracts" / "schemas"
FILENAME_PATTERN = re.compile(
    r"^CIELO(?P<tipo>03|04|09|15|16)D_(?P<ec>\d{10})_(?P<d1>\d{8})_(?P<d2>\d{8})_(?P<d3>\d{8})\.TXT$"
)


RECORD_SCHEMA_FILES = {
    "0": "registro-0-header.json",
    "D": "registro-D-ur-agenda.json",
    "E": "registro-E-lancamento.json",
    "8": "registro-8-pix.json",
    "A": "registro-A-resumo-negociacao.json",
    "B": "registro-B-detalhe-negociacao.json",
    "C": "registro-C-conta-negociacao.json",
    "R": "registro-R-reserva-financeira.json",
    "9": "registro-9-trailer.json",
}


def _slice(line: str, ini: int, fim: int) -> str:
    # ini/fim are 1-based inclusive offsets from manual schemas.
    return line[ini - 1 : fim]


def _load_schema() -> dict:
    with SCHEMA_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def _load_record_schemas() -> dict:
    payload = {}
    for rec, filename in RECORD_SCHEMA_FILES.items():
        path = SCHEMAS_DIR / filename
        if not path.exists():
            continue
        try:
            with path.open("r", encoding="utf-8") as f:
                payload[rec] = json.load(f)
        except Exception:
            continue
    return payload


def _record_min_lengths(record_schemas: dict) -> dict:
    out = {}
    for rec, schema in record_schemas.items():
        max_fim = 0
        for field in schema.get("campos", []):
            try:
                max_fim = max(max_fim, int(field.get("fim", 0)))
            except Exception:
                continue
        if max_fim > 0:
            out[rec] = max_fim
    return out


def _is_num_compatible(value: str) -> bool:
    # Accept all spaces (optional field) or only digits.
    if value.strip() == "":
        return True
    return value.isdigit()


def _parse_signed_int(sign_value: str, number_value: str) -> int | None:
    num = number_value.strip()
    if not num.isdigit():
        return None
    base = int(num)
    sign = sign_value.strip()[:1] if sign_value else "+"
    if sign == "-":
        return -base
    return base


def _build_structured_issues(file_path: str, errors: list[str], warnings: list[str]) -> list[dict]:
    issues = []

    def parse_entry(message: str, severity: str) -> dict:
        parts = str(message).split(":")
        code = parts[0] if parts else "unknown_issue"
        issue = {
            "code": code,
            "severity": severity,
            "message": str(message),
            "file": file_path,
            "line": None,
            "record": "",
            "field": "",
            "rule": code if code.startswith("R") else "",
            "details": {},
        }

        for token in parts[1:]:
            if "=" not in token:
                continue
            key, value = token.split("=", 1)
            key = key.strip()
            value = value.strip()
            issue["details"][key] = value
            if key == "line" and value.isdigit():
                issue["line"] = int(value)
            elif key == "record":
                issue["record"] = value
            elif key == "field":
                issue["field"] = value

        return issue

    for item in errors:
        issues.append(parse_entry(item, "error"))
    for item in warnings:
        issues.append(parse_entry(item, "warning"))

    return issues


def _detect_file_type(header_line: str) -> str:
    if not header_line or header_line[0] != "0":
        return ""

    # Production files carry the literal token CIELOXX in the header.
    match = re.search(r"CIELO(?P<tipo>\d{2})", header_line)
    if not match:
        return ""
    return f"CIELO{match.group('tipo')}"


def _detect_file_type_from_filename(path: Path) -> str:
    match = FILENAME_PATTERN.match(path.name)
    if not match:
        return ""
    return f"CIELO{match.group('tipo')}"


def validate_extrato(path: Path) -> tuple[int, dict]:
    errors = []
    warnings = []

    if not path.exists():
        missing = [f"file_not_found:{path}"]
        return 1, {
            "status": "error",
            "errors": missing,
            "warnings": [],
            "issues": _build_structured_issues(str(path), missing, []),
        }

    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines:
        errs = ["empty_file"]
        return 1, {
            "status": "error",
            "errors": errs,
            "warnings": [],
            "issues": _build_structured_issues(str(path), errs, []),
        }

    records_seen = [line[:1] if line else "" for line in lines]
    header_count = sum(1 for r in records_seen if r == "0")
    trailer_count = sum(1 for r in records_seen if r == "9")

    if lines[0][:1] != "0":
        errors.append("first_record_must_be_header_0")
    if lines[-1][:1] != "9":
        errors.append("last_record_must_be_trailer_9")
    if header_count != 1:
        errors.append(f"expected_1_header_found:{header_count}")
    if trailer_count != 1:
        errors.append(f"expected_1_trailer_found:{trailer_count}")

    schema = _load_schema()
    record_schemas = _load_record_schemas()
    min_lengths = _record_min_lengths(record_schemas)
    allowed_global = set(schema.get("registros", {}).keys())
    file_type = _detect_file_type(lines[0])
    file_type_from_name = _detect_file_type_from_filename(path)

    allowed_per_file = {}
    for item in schema.get("arquivos", []):
        allowed_per_file[item.get("codigo", "")] = set(item.get("registros", []))

    if not file_type_from_name:
        warnings.append("filename_not_in_expected_pattern")

    if file_type and file_type_from_name and file_type != file_type_from_name:
        errors.append(f"file_type_mismatch_header_vs_filename:header={file_type}:filename={file_type_from_name}")

    effective_file_type = file_type if file_type else file_type_from_name

    if not effective_file_type:
        errors.append("unable_to_detect_file_type_from_header")
    elif effective_file_type not in allowed_per_file:
        warnings.append(f"unknown_file_type:{effective_file_type}")

    for idx, rec in enumerate(records_seen, start=1):
        if rec not in allowed_global:
            errors.append(f"invalid_record_type:line={idx}:record={rec}")
            continue
        if effective_file_type in allowed_per_file and rec not in allowed_per_file[effective_file_type]:
            errors.append(
                f"record_not_allowed_for_file_type:line={idx}:record={rec}:file_type={effective_file_type}"
            )

        # Truncation guard per schema minimum length.
        expected_len = min_lengths.get(rec, 0)
        if expected_len and len(lines[idx - 1]) < expected_len:
            errors.append(
                f"line_too_short_for_record_schema:line={idx}:record={rec}:len={len(lines[idx - 1])}:expected_min={expected_len}"
            )

    # Fallback truncation detection for malformed/unavailable schema files.
    lengths_by_record = {}
    for idx, line in enumerate(lines, start=1):
        rec = line[:1] if line else ""
        lengths_by_record.setdefault(rec, []).append((idx, len(line)))

    for rec, items in lengths_by_record.items():
        if len(items) < 2:
            continue
        max_len = max(length for _, length in items)
        for idx, length in items:
            if length < max_len:
                errors.append(
                    f"line_too_short_for_record_schema:line={idx}:record={rec}:len={length}:expected_min={max_len}"
                )

    # Critical numeric checks to catch malformed data early.
    for idx, line in enumerate(lines, start=1):
        rec = line[:1] if line else ""
        if rec == "0":
            if not _is_num_compatible(_slice(line, 2, 11)):
                errors.append(f"numeric_field_invalid:line={idx}:record=0:field=estabelecimento_matriz")
        elif rec == "E":
            if not _is_num_compatible(_slice(line, 28, 29)):
                errors.append(f"numeric_field_invalid:line={idx}:record=E:field=tipo_lancamento")
        elif rec == "8":
            tipo_transacao = _slice(line, 12, 13)
            if not _is_num_compatible(tipo_transacao):
                errors.append(f"numeric_field_invalid:line={idx}:record=8:field=tipo_transacao")
            elif tipo_transacao not in {"01", "02", "03"}:
                warnings.append(
                    f"unknown_domain_code:line={idx}:record=8:field=tipo_transacao:code={tipo_transacao}"
                )

            # R002 - Pix adjustment must link to original sale.
            if tipo_transacao in {"02", "03"}:
                id_pix_original = _slice(line, 182, 217)
                if id_pix_original.strip(" 0") == "":
                    errors.append(
                        f"R002_PIX_ADJUSTMENT_MUST_LINK_SALE:line={idx}:record=8:missing_id_pix_original"
                    )

    # R001 - D x E consistency by (chave_ur + tipo_lancamento), applicable on files with both records.
    if effective_file_type in {"CIELO03", "CIELO04"}:
        sum_d = {}
        sum_e = {}
        for line in lines:
            rec = line[:1] if line else ""
            if rec == "D" and len(line) >= 253:
                tipo_lanc = _slice(line, 150, 151)
                chave = _slice(line, 152, 251).strip()
                val = _parse_signed_int(_slice(line, 100, 100), _slice(line, 101, 113))
                if chave and val is not None:
                    key = f"{chave}|{tipo_lanc}"
                    sum_d[key] = sum_d.get(key, 0) + val
            elif rec == "E" and len(line) >= 288:
                tipo_lanc = _slice(line, 28, 29)
                chave = _slice(line, 30, 129).strip()
                val = _parse_signed_int(_slice(line, 275, 275), _slice(line, 276, 288))
                if chave and val is not None:
                    key = f"{chave}|{tipo_lanc}"
                    sum_e[key] = sum_e.get(key, 0) + val

        common_keys = set(sum_d.keys()) & set(sum_e.keys())
        for key in sorted(common_keys):
            if sum_d[key] != sum_e[key]:
                errors.append(
                    f"R001_D_E_NET_MATCH:key={key}:d={sum_d[key]}:e={sum_e[key]}"
                )

    trailer_line = lines[-1]
    trailer_match = re.match(r"^9(?P<count>\d+)[+-]", trailer_line)
    if trailer_match:
        declared = int(trailer_match.group("count"))
        # In production files, trailer count represents detail records (excludes header and trailer).
        actual = max(len(lines) - 2, 0)
        if declared != actual:
            warnings.append(f"trailer_record_count_mismatch:declared={declared}:actual={actual}")
    else:
        warnings.append("trailer_count_not_numeric")

    status = "ok" if not errors else "error"
    report = {
        "status": status,
        "file": str(path),
        "file_type": effective_file_type,
        "file_type_header": file_type,
        "file_type_filename": file_type_from_name,
        "line_count": len(lines),
        "errors": errors,
        "warnings": warnings,
        "issues": _build_structured_issues(str(path), errors, warnings),
        "rules_checked": [
            "R001_D_E_NET_MATCH",
            "R002_PIX_ADJUSTMENT_MUST_LINK_SALE",
            "R004_TRAILER_TOTALS_BY_FILE_TYPE",
        ],
    }
    return (0 if not errors else 1), report


def self_check() -> int:
    sample_ok = ROOT / "exemplos" / "cielo03-exemplo.txt"
    sample_pix = ROOT / "exemplos" / "cielo16-pix-exemplo.txt"

    samples = [sample_ok, sample_pix]
    if not all(sample.exists() for sample in samples):
        samples = sorted((ROOT / "exemplos").glob("CIELO*.TXT"))

    if not samples:
        print(json.dumps({"status": "error", "errors": ["no_example_files_found"]}, ensure_ascii=False, indent=2))
        return 1

    exit_codes = []
    reports = []
    for sample in samples:
        code, rep = validate_extrato(sample)
        exit_codes.append(code)
        reports.append(rep)

    final_code = 0 if all(code == 0 for code in exit_codes) else 1
    print(json.dumps({"self_check": reports}, ensure_ascii=False, indent=2))
    return final_code


def main() -> int:
    parser = argparse.ArgumentParser(description="Validador basico de arquivo Extrato Cielo")
    parser.add_argument("--file", type=str, help="Caminho do arquivo extrato")
    parser.add_argument("--self-check", action="store_true", help="Executa validacao dos exemplos")
    args = parser.parse_args()

    if args.self_check:
        return self_check()

    if not args.file:
        print(json.dumps({"status": "error", "errors": ["missing_argument:file"]}, indent=2))
        return 1

    code, report = validate_extrato(Path(args.file))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
