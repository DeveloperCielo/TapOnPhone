import json
import re
import zipfile
import unicodedata
from datetime import datetime, timezone
from pathlib import Path
from difflib import SequenceMatcher
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
DOCX = ROOT / "CIELO_Extrato_Eletronico_-_Manual_-_Versao_15_15.docx"
MANUAL = ROOT / "docs" / "5.manual-completo.md"
RAW_REPORT = ROOT / "changelog" / "manual-sync-semantic-report-20260714-after-fix.json"
OUT_REPORT = ROOT / "changelog" / "manual-sync-semantic-report-20260714-after-fix-filtered.json"
OUT_DELTA = ROOT / "changelog" / "manual-sync-semantic-delta-20260714-filtered.json"

HEADING_EXACT = {
    "descricao do produto",
    "ultimas atualizacoes",
    "tipos de registros e estrutura",
    "transmissao e reenvio de arquivos",
    "conceitos de captura e liquidacao",
    "carta de circularizacao",
}

SHORT_LABEL_NOISE = {
    "status de pagamento",
    "forma de pagamento",
    "grupo de cartoes",
    "registradora",
    "valor bruto",
    "agenda de recebiveis",
    "data da captura",
    "tipo de cartao",
    "tipos de arquivo",
    "canal da venda",
    "codigo da negociacao",
    "data de pagamento",
    "data efetiva de pagamento",
    "codigos de bandeira",
    "tipo de precificacao",
}


def normalize(text: str) -> str:
    text = text.strip().lower()
    text = text.replace("\u201c", '"').replace("\u201d", '"').replace("\u2019", "'").replace("\u2018", "'")
    text = text.replace("\u2013", "-")
    text = re.sub(r"\s+", " ", text)
    return text


def normalize_ascii(text: str) -> str:
    n = normalize(text)
    n = unicodedata.normalize("NFD", n)
    n = "".join(ch for ch in n if unicodedata.category(ch) != "Mn")
    n = re.sub(r"\s+", " ", n).strip()
    return n


def strip_accents_like(text: str) -> str:
    swaps = {
        "a": "[a\u00e1\u00e0\u00e2\u00e3\u00e4]",
        "e": "[e\u00e9\u00e8\u00ea\u00eb]",
        "i": "[i\u00ed\u00ec\u00ee\u00ef]",
        "o": "[o\u00f3\u00f2\u00f4\u00f5\u00f6]",
        "u": "[u\u00fa\u00f9\u00fb\u00fc]",
        "c": "[c\u00e7]",
    }
    out = []
    for ch in text:
        out.append(swaps.get(ch, re.escape(ch)))
    return "".join(out)


def contains_folded(haystack_norm: str, needle_plain: str) -> bool:
    return re.search(strip_accents_like(needle_plain), haystack_norm) is not None


def is_all_caps_heading(text: str) -> bool:
    letters = [c for c in text if c.isalpha()]
    if len(letters) < 8:
        return False
    upper_letters = [c for c in letters if c.isupper()]
    return len(upper_letters) / len(letters) >= 0.9


def is_noise_docx_paragraph(text: str) -> bool:
    n = normalize(text)
    a = normalize_ascii(text)

    if "todos os direitos reservados" in a and "manual de especificacao tecnica" in a:
        return True

    version_re = strip_accents_like("versao") + r"\s*:\s*\d+(?:\.\d+){0,2}"
    if re.fullmatch(version_re, a):
        return True

    if a in HEADING_EXACT:
        return True

    if a in SHORT_LABEL_NOISE:
        return True

    if is_all_caps_heading(text) and len(n) <= 90:
        return True

    return False


def load_docx_paragraphs(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as zf:
        xml_data = zf.read("word/document.xml")
    root = ET.fromstring(xml_data)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paragraphs = []
    for p in root.findall('.//w:body/w:p', ns):
        text = "".join((t.text or "") for t in p.findall('.//w:t', ns)).strip()
        if text:
            paragraphs.append(text)
    return paragraphs


def load_manual_candidates(path: Path) -> list[tuple[str, str, str]]:
    lines = path.read_text(encoding="utf-8").splitlines()
    section = "PREAMBULO"
    section_lines = []
    grouped = []

    for line in lines:
        if line.startswith("### "):
            grouped.append((section, section_lines))
            section = line[4:].strip()
            section_lines = []
            continue

        s = line.strip()
        if not s or s.startswith("---") or s.startswith("#"):
            continue
        if s.startswith(("secao:", "versao_", "formato:", "fonte:", "atualizado_em:")):
            continue
        section_lines.append(s)

    grouped.append((section, section_lines))

    out = []
    for sec, sec_lines in grouped:
        for ln in sec_lines:
            n = normalize(ln)
            if len(n) >= 8:
                out.append((sec, ln, n))
    return out


def compute_report(filtered: bool) -> dict:
    docx_paragraphs = load_docx_paragraphs(DOCX)
    manual_candidates = load_manual_candidates(MANUAL)
    manual_norm = [n for _, _, n in manual_candidates]

    exact_hits = 0
    non_exact = []
    noise_excluded = []

    for paragraph in docx_paragraphs:
        p_norm = normalize(paragraph)
        if len(p_norm) < 8:
            continue

        if filtered and is_noise_docx_paragraph(paragraph):
            noise_excluded.append(paragraph)
            continue

        if p_norm in manual_norm:
            exact_hits += 1
            continue

        best_index = -1
        best_score = 0.0

        for idx, m_norm in enumerate(manual_norm):
            if abs(len(m_norm) - len(p_norm)) > 120:
                continue
            score = SequenceMatcher(None, p_norm, m_norm).ratio()
            if score > best_score:
                best_score = score
                best_index = idx

        if best_index >= 0:
            sec, m_text, _ = manual_candidates[best_index]
            non_exact.append(
                {
                    "docx_text": paragraph,
                    "best_manual_section": sec,
                    "best_manual_text": m_text,
                    "similarity": round(best_score, 4),
                }
            )
        else:
            non_exact.append(
                {
                    "docx_text": paragraph,
                    "best_manual_section": None,
                    "best_manual_text": None,
                    "similarity": 0.0,
                }
            )

    high = [c for c in non_exact if c["similarity"] < 0.70]
    medium = [c for c in non_exact if 0.70 <= c["similarity"] < 0.85]
    low = [c for c in non_exact if 0.85 <= c["similarity"] < 0.95]

    report = {
        "filter_version": "2026-07-14-v2",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "mode": "filtered" if filtered else "raw",
        "docx_paragraphs_non_empty": len(docx_paragraphs),
        "manual_candidate_lines": len(manual_candidates),
        "noise_excluded_count": len(noise_excluded),
        "noise_excluded_examples": noise_excluded[:20],
        "exact_hits": exact_hits,
        "non_exact_candidates": len(non_exact),
        "counts": {
            "high_divergence": len(high),
            "medium_divergence": len(medium),
            "low_divergence": len(low),
        },
        "top_high_divergence": sorted(high, key=lambda x: x["similarity"])[:40],
        "top_medium_divergence": sorted(medium, key=lambda x: x["similarity"])[:40],
    }
    return report


def main() -> None:
    filtered_report = compute_report(filtered=True)
    OUT_REPORT.write_text(json.dumps(filtered_report, ensure_ascii=False, indent=2), encoding="utf-8")

    raw_counts = {}
    if RAW_REPORT.exists():
        raw_obj = json.loads(RAW_REPORT.read_text(encoding="utf-8"))
        raw_counts = raw_obj.get("counts", {})

    filtered_counts = filtered_report.get("counts", {})

    delta = {
        "raw_after_fix_counts": raw_counts,
        "filtered_after_fix_counts": filtered_counts,
        "noise_excluded_count": filtered_report.get("noise_excluded_count", 0),
        "delta_filtered_minus_raw": {
            "high_divergence": filtered_counts.get("high_divergence", 0) - raw_counts.get("high_divergence", 0),
            "medium_divergence": filtered_counts.get("medium_divergence", 0) - raw_counts.get("medium_divergence", 0),
            "low_divergence": filtered_counts.get("low_divergence", 0) - raw_counts.get("low_divergence", 0),
        },
    }
    OUT_DELTA.write_text(json.dumps(delta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(delta, ensure_ascii=False))


if __name__ == "__main__":
    main()
