# Manual Extrato Eletronico Cielo (AI-friendly)

Este pacote organiza o manual de Extrato Eletronico Cielo para consumo por times de implantacao, engenharia e agentes de IA.

## Ponto de entrada para agentes de IA

Todo agente de IA que for operar neste pacote deve ler `0.manual-extrato-cielo.md` primeiro. Ele roteia, por intencao, qual artefato e script usar - evita que o agente precise ler o pacote inteiro para descobrir o caminho certo.

## Fluxo oficial para clientes

A execucao oficial para cliente esta definida somente em `docs/quickstart-implantacao.md`.

Use este arquivo para:

1. Pre-requisitos.
2. Instalacao.
3. Validacao estrutural.
4. Homologacao.
5. Troubleshooting basico.

Os demais documentos deste repositorio sao referencia complementar.

## Estrutura principal do toolkit

- `0.manual-extrato-cielo.md`: ponto de entrada e roteador por intencao para agentes de IA.
- `contracts/2.manual-extrato-v15.15.schema.json`: contrato canonico.
- `contracts/schemas/`: layouts posicionais dos registros.
- `contracts/tabelas/`: dominios codificados (tabelas I a XI).
- `docs/5.manual-completo.md`: narrativa consolidada do manual.
- `docs/6.glossario.md`: normalizacao de termos.
- `prompts/7.prompt-implantacao-ai.md`: prompt de implantacao para LLM.
- `contracts/resultado-validacao.schema.json`: contrato de saida da validacao.
- `contracts/resultado-conciliacao.schema.json`: contrato de saida da conciliacao.
- `scripts/`: automacoes operacionais do toolkit (as que o cliente/agente executa).
- `.github/workflows/manual-extrato-ci.yml`: quality gates em CI (uso interno Cielo).

## Distribuicao para clientes

Este repositorio tambem serve de workspace interno de manutencao da Cielo. Ao empacotar para um cliente, **nao envie**:

- `.cielo/`: fonte bruta do DOCX, scripts de geracao/regeneracao de contratos e relatorios internos de sync semantico. Nao e contrato nem e necessario para operar o toolkit.
- `.github/`: pipeline de CI da Cielo (nao roda nem e util fora do repositorio interno).

Tudo que esta fora dessas duas pastas e seguro para distribuicao.

## Referencias complementares

- `docs/1.toolkit-uso-em-ia.md`: playbook tecnico para consumo por agentes.
- `docs/8.onboarding-operacional-cliente.md`: onboarding operacional do cliente.
- `docs/integracao-bancaria-interface.md`: interface de conciliacao com extrato bancario.
- `docs/troubleshooting-operacional.md`: runbook de incidentes.

## Validacao rapida da estrutura

Execute na raiz deste diretorio:

```bash
python scripts/validate_manual_package.py
```

## Homologacao rapida

```bash
python scripts/run_homologation_suite.py
```

## Fonte do manual

- DOCX oficial: `CIELO_Extrato_Eletronico_-_Manual_-_Versao_15_15.docx`
