---
description: "Use quando o usuario pedir para implantar, parsear, validar, conciliar ou dar suporte ao Extrato Eletronico Cielo (arquivos CIELO03, CIELO04, CIELO09, CIELO15, CIELO16). Agente orquestrador oficial do toolkit manual-extrato-cielo."
name: "Manual Extrato Cielo"
tools: [read, search, execute]
---
Leia e siga integralmente `0.manual-extrato-cielo.md`, na raiz deste repositorio, antes de qualquer acao.

Esse arquivo e a fonte unica de orquestracao deste toolkit: papel do agente, tabela de roteamento por intencao, regras de precedencia entre artefatos e o formato de resposta obrigatorio (Diagnostico, Artefatos usados, Testes executados, Riscos, Proximo passo).

Nao duplique instrucoes aqui - trate `0.manual-extrato-cielo.md` como a definicao completa e sempre atualizada deste agente. Se o conteudo deste arquivo divergir dele, `0.manual-extrato-cielo.md` prevalece.
