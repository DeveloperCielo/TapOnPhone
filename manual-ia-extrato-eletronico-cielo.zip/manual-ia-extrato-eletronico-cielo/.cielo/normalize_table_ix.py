import json
import re
import unicodedata
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INPUT_PATH = ROOT / "contracts" / "tabelas" / "tabela-IX-motivos-ajuste.json"
OUTPUT_PATH = ROOT / "contracts" / "tabelas" / "tabela-IX-motivos-ajuste.normalized.json"

# Manual correction for OCR/doc extraction ambiguity where the same code appears with two descriptions.
CODE_DESCRIPTION_OVERRIDES = {
    "0111": "Valores não reconhecidos",
}


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _normalize_text(text: str) -> str:
    raw = (text or "").strip().lower()
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    raw = raw.replace("\u201c", '"').replace("\u201d", '"').replace("\u2019", "'")
    raw = re.sub(r"\s+", " ", raw)
    raw = re.sub(r"\s*[-–]\s*", " - ", raw)
    return raw.strip()


def build_normalized_table_ix(payload: dict) -> dict:
    rows = payload.get("dominio", [])

    grouped_by_desc_key = {}
    code_to_desc_keys = {}
    overrides_applied = []

    for row in rows:
        code = str(row.get("codigo", "")).strip()
        desc = str(row.get("descricao", "")).strip()
        if not code or not desc:
            continue

        desc_key = _normalize_text(desc)
        if desc_key not in grouped_by_desc_key:
            grouped_by_desc_key[desc_key] = {
                "descricao_canonica": desc,
                "codigos": set(),
                "descricoes_origem": set(),
            }

        grouped_by_desc_key[desc_key]["codigos"].add(code)
        grouped_by_desc_key[desc_key]["descricoes_origem"].add(desc)

        if code not in code_to_desc_keys:
            code_to_desc_keys[code] = set()
        code_to_desc_keys[code].add(desc_key)

    for code, preferred_desc in CODE_DESCRIPTION_OVERRIDES.items():
        if code not in code_to_desc_keys:
            continue

        preferred_key = _normalize_text(preferred_desc)
        if preferred_key not in grouped_by_desc_key:
            continue

        if preferred_key not in code_to_desc_keys[code]:
            continue

        if len(code_to_desc_keys[code]) <= 1:
            continue

        code_to_desc_keys[code] = {preferred_key}
        overrides_applied.append(
            {
                "codigo": code,
                "descricao_preferida": grouped_by_desc_key[preferred_key]["descricao_canonica"],
                "motivo": "desambiguacao_manual",
            }
        )

    deduplicated = []
    alias_por_codigo = {}
    ambiguidades_codigo = []

    sorted_desc_keys = sorted(grouped_by_desc_key.keys())
    for idx, desc_key in enumerate(sorted_desc_keys, start=1):
        item = grouped_by_desc_key[desc_key]
        canonical_id = f"IXD{idx:04d}"
        deduplicated.append(
            {
                "canonical_id": canonical_id,
                "descricao_canonica": item["descricao_canonica"],
                "codigos": sorted(item["codigos"]),
                "descricoes_origem": sorted(item["descricoes_origem"]),
            }
        )

    desc_key_to_canonical_id = {}
    for item in deduplicated:
        desc_key = _normalize_text(item["descricao_canonica"])
        desc_key_to_canonical_id[desc_key] = item["canonical_id"]

    for code, desc_keys in sorted(code_to_desc_keys.items()):
        canonical_ids = [desc_key_to_canonical_id[k] for k in sorted(desc_keys)]
        descricoes_canonicas = [grouped_by_desc_key[k]["descricao_canonica"] for k in sorted(desc_keys)]
        alias_por_codigo[code] = {
            "canonical_ids": canonical_ids,
            "descricoes_canonicas": descricoes_canonicas,
            "descricao_canonica": descricoes_canonicas[0] if len(descricoes_canonicas) == 1 else None,
            "ambiguous": len(canonical_ids) > 1,
        }
        if len(canonical_ids) > 1:
            ambiguidades_codigo.append(
                {
                    "codigo": code,
                    "canonical_ids": canonical_ids,
                    "descricoes": [grouped_by_desc_key[k]["descricao_canonica"] for k in sorted(desc_keys)],
                }
            )

    return {
        "tabela": "IX",
        "nome": payload.get("nome", "Tabela IX - Motivos de Ajuste"),
        "source": payload.get("source", {}),
        "normalizacao": {
            "descricao": "deduplicacao semantica por descricao normalizada + aliases por codigo",
            "input_rows": len(rows),
            "canonical_rows": len(deduplicated),
            "ambiguous_codes": len(ambiguidades_codigo),
            "overrides_applied": len(overrides_applied),
        },
        "dominio_canonico": deduplicated,
        "alias_por_codigo": alias_por_codigo,
        "ambiguidade_por_codigo": ambiguidades_codigo,
        "overrides_aplicados": overrides_applied,
    }


def main() -> int:
    if not INPUT_PATH.exists():
        print(json.dumps({"status": "error", "message": f"missing:{INPUT_PATH}"}, ensure_ascii=False))
        return 1

    payload = _load_json(INPUT_PATH)
    normalized = build_normalized_table_ix(payload)

    OUTPUT_PATH.write_text(json.dumps(normalized, ensure_ascii=False, indent=2), encoding="utf-8")
    print(
        json.dumps(
            {
                "status": "ok",
                "input": str(INPUT_PATH.as_posix()),
                "output": str(OUTPUT_PATH.as_posix()),
                "canonical_rows": normalized["normalizacao"]["canonical_rows"],
                "ambiguous_codes": normalized["normalizacao"]["ambiguous_codes"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
