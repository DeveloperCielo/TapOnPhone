import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

REQUIRED_ARTIFACTS = [
    "contracts/2.manual-extrato-v15.15.schema.json",
    "contracts/schemas",
    "contracts/tabelas",
    "docs/5.manual-completo.md",
    "docs/6.glossario.md",
    "prompts/7.prompt-implantacao-ai.md",
    "contracts/resultado-validacao.schema.json",
    "contracts/resultado-conciliacao.schema.json",
]

DOC_GLOBS = [
    "README.md",
    "0.manual-extrato-cielo.md",
    "docs/*.md",
    "prompts/*.md",
]

MD_LINK_RE = re.compile(r"\[[^\]]+\]\(([^)]+)\)")
CODE_PATH_RE = re.compile(r"`([^`]+)`")
FENCED_CODE_BLOCK_RE = re.compile(r"```.*?```", re.DOTALL)


def _is_external_link(target: str) -> bool:
    return target.startswith("http://") or target.startswith("https://") or target.startswith("mailto:")


def _looks_like_local_path(token: str) -> bool:
    if token.startswith("#"):
        return False
    if " " in token:
        return False
    if token.startswith("--"):
        return False
    has_sep = "/" in token or "\\" in token
    has_ext = any(token.endswith(ext) for ext in [".md", ".json", ".py", ".yml", ".yaml", ".TXT", ".txt", ".csv"])
    return has_sep or has_ext


def _is_placeholder_path(token: str) -> bool:
    upper = token.upper()
    placeholders = ["CAMINHO_", "YYYYMMDD", "<", "*", "(", ")", "|", "{"]
    return any(marker in upper for marker in placeholders)


def _resolve(root: Path, base_file: Path, target: str) -> Path:
    normalized = target.split("#", 1)[0].strip()
    if normalized in {"manual-extrato-cielo", "manual-extrato-cielo/"}:
        return root
    if normalized.startswith("./") or normalized.startswith("../"):
        return (base_file.parent / normalized).resolve()
    if "/" not in normalized and "\\" not in normalized and normalized.endswith(".py"):
        scripts_candidate = (root / "scripts" / normalized).resolve()
        if scripts_candidate.exists():
            return scripts_candidate
    return (root / normalized).resolve()


def main() -> int:
    issues = []

    for rel in REQUIRED_ARTIFACTS:
        path = ROOT / rel
        if rel.endswith("/"):
            if not path.is_dir():
                issues.append(f"missing_required_directory:{rel}")
            continue
        if path.suffix == "":
            if not path.is_dir():
                issues.append(f"missing_required_directory:{rel}")
        elif not path.exists():
            issues.append(f"missing_required_file:{rel}")

    doc_files = []
    for pattern in DOC_GLOBS:
        doc_files.extend(ROOT.glob(pattern))

    seen = set()
    for doc in doc_files:
        if doc in seen or not doc.exists():
            continue
        seen.add(doc)

        text = doc.read_text(encoding="utf-8")
        text_without_fences = FENCED_CODE_BLOCK_RE.sub("", text)

        for match in MD_LINK_RE.finditer(text):
            target = match.group(1).strip()
            if not target or _is_external_link(target) or target.startswith("#"):
                continue
            resolved = _resolve(ROOT, doc, target)
            if not resolved.exists():
                issues.append(f"broken_markdown_link:{doc.relative_to(ROOT)}:{target}")

        for match in CODE_PATH_RE.finditer(text_without_fences):
            token = match.group(1).strip()
            if not token or _is_placeholder_path(token) or not _looks_like_local_path(token):
                continue
            if _is_external_link(token):
                continue
            resolved = _resolve(ROOT, doc, token)
            if not resolved.exists():
                issues.append(f"broken_inline_path:{doc.relative_to(ROOT)}:{token}")

    report = {
        "status": "ok" if not issues else "error",
        "checked_docs": len(seen),
        "issues": issues,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if not issues else 1


if __name__ == "__main__":
    raise SystemExit(main())
