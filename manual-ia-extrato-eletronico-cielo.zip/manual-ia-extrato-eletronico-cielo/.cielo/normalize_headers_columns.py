import json
import re
import unicodedata
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TABLES_DIR = ROOT / "contracts" / "tabelas"
SCHEMAS_DIR = ROOT / "contracts" / "schemas"

TABLE_FILES = [
    "tabela-I-tipos-arquivo.json",
    "tabela-II-tipos-lancamento.json",
    "tabela-III-tipos-registro.json",
    "tabela-IV-status-pagamento.json",
    "tabela-V-formas-pagamento.json",
    "tabela-VI-origem-ajuste-pix.json",
    "tabela-VII-status-debito-conta.json",
    "tabela-VIII-tipo-captura.json",
    "tabela-IX-motivos-ajuste.json",
    "tabela-X-bandeiras.json",
    "tabela-XI-efeitos-negociacao.json",
]

SCHEMA_FILES = [
    "registro-0-header.json",
    "registro-D-ur-agenda.json",
    "registro-E-lancamento.json",
    "registro-8-pix.json",
    "registro-A-resumo-negociacao.json",
    "registro-B-detalhe-negociacao.json",
    "registro-C-conta-negociacao.json",
    "registro-R-reserva-financeira.json",
    "registro-9-trailer.json",
]


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "")).strip()


def _sanitize_key(text: str, idx: int) -> str:
    raw = _norm(text).lower()
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    canonical_map = {
        "codigo": "codigo",
        "descricao": "descricao",
        "ini": "ini",
        "fim": "fim",
        "tam": "tam",
        "tipo": "tipo",
        "consistencias edi": "consistencias_edi",
    }
    if raw in canonical_map:
        return canonical_map[raw]

    key = raw.replace("%", " pct ")
    key = re.sub(r"[^a-z0-9]+", "_", key)
    key = re.sub(r"_+", "_", key).strip("_")
    return key or f"coluna_{idx + 1}"


def _header_map(header: list[str]) -> list[dict]:
    return [
        {
            "origem": _norm(value),
            "chave_estavel": _sanitize_key(value, i),
            "indice": i + 1,
        }
        for i, value in enumerate(header)
    ]


def _stable_columns(rows: list[dict]) -> list[str]:
    cols = []
    seen = set()
    for row in rows:
        for key in row.keys():
            if key not in seen:
                seen.add(key)
                cols.append(key)
    return cols


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_tables() -> list[str]:
    changed = []
    for name in TABLE_FILES:
        path = TABLES_DIR / name
        if not path.exists():
            continue
        payload = _load_json(path)
        header = payload.get("header", [])
        domain = payload.get("dominio", [])

        payload["header_normalizado"] = _header_map(header)
        payload["colunas_negociais_estaveis"] = _stable_columns(domain)

        _save_json(path, payload)
        changed.append(path.as_posix())
    return changed


def normalize_schemas() -> list[str]:
    changed = []
    for name in SCHEMA_FILES:
        path = SCHEMAS_DIR / name
        if not path.exists():
            continue
        payload = _load_json(path)
        header = payload.get("header", [])
        fields = payload.get("campos", [])

        payload["header_normalizado"] = _header_map(header)
        payload["colunas_negociais_estaveis"] = _stable_columns(fields)

        _save_json(path, payload)
        changed.append(path.as_posix())
    return changed


def main() -> int:
    changed_tables = normalize_tables()
    changed_schemas = normalize_schemas()
    print(
        json.dumps(
            {
                "status": "ok",
                "tables_updated": len(changed_tables),
                "schemas_updated": len(changed_schemas),
                "tables": changed_tables,
                "schemas": changed_schemas,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
