import json
from pathlib import Path

raw_file = Path(__file__).resolve().parents[1] / ".cielo" / "oficial-docx" / "tabelas" / "_all_tables_raw.json"
raw_data = json.load(raw_file.open(encoding="utf-8"))

# Find table IX (table_index == 39)
t9 = [x for x in raw_data if x.get("table_index") == 39][0]

# Build base tabela-IX with all rows
base_ix = {
    "tabela": "IX",
    "nome": t9["title"],
    "source": {
        "type": "docx",
        "document": "CIELO_Extrato_Eletronico_-_Manual_-_Versao_15_15.docx",
        "table_index": 39,
        "inferred_roman": ""
    },
    "dominio": []
}

# Skip header row, add all data rows
for row in t9["rows"][1:]:
    if len(row) >= 2:
        base_ix["dominio"].append({
            "codigo": row[0].strip(),
            "descricao": row[1].strip()
        })

print(f"Total itens extraid (sem duplicatas de código): {len(base_ix['dominio'])}")
print(f"Sample: {base_ix['dominio'][:3]}")

# Write base file
out_file = Path(__file__).resolve().parents[1] / "contracts" / "tabelas" / "tabela-IX-motivos-ajuste.base.json"
out_file.write_text(json.dumps(base_ix, ensure_ascii=False, indent=2), encoding="utf-8")
print(f"Arquivo gerado: {out_file}")
