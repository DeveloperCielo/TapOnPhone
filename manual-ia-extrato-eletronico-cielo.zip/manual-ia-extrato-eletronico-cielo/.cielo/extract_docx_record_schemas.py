import argparse
import json
import re
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import List


NS = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}

# Observed stable block in v15.15 for record layouts.
TABLE_INDEX_TO_RECORD = {
    22: "0",
    23: "D",
    24: "E",
    25: "8",
    26: "A",
    27: "B",
    28: "C",
    29: "R",
    30: "9",
}

RECORD_TO_FILENAME = {
    "0": "registro-0-header.json",
    "D": "registro-D-ur-agenda.json",
    "E": "registro-E-lancamento.json",
    "8": "registro-8-pix.json",
    "A": "registro-A-resumo-negociacao.json",
    "B": "registro-B-detalhe-negociacao.json",
    "C": "registro-C-conta-negociacao.json",
    "R": "registro-R-reserva-financeira.json",
    "9": "registro-9-trailer.json",
}

RECORD_LABEL = {
    "0": "Header",
    "D": "Agenda UR",
    "E": "Detalhe do Lancamento",
    "8": "Detalhe Transacao Pix",
    "A": "Resumo Negociacao",
    "B": "Detalhe Negociacao",
    "C": "Conta Negociacao",
    "R": "Reserva Financeira",
    "9": "Trailer",
}


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def _sanitize_key(text: str, idx: int) -> str:
    raw = _norm(text).lower()
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    canonical_map = {
        "codigo": "codigo",
        "descricao": "descricao",
        "ini": "ini",
        "fim": "fim",
        "tam": "tam",
        "tipo": "tipo",
        "consistencias edi": "consistencias_edi",
    }
    if raw in canonical_map:
        return canonical_map[raw]

    key = raw
    key = key.replace("%", " pct ")
    key = re.sub(r"[^a-z0-9]+", "_", key)
    key = re.sub(r"_+", "_", key).strip("_")
    return key or f"coluna_{idx + 1}"


def _extract_tables(document_xml: Path) -> List[dict]:
    root = ET.parse(document_xml).getroot()
    body = root.find("w:body", NS)
    if body is None:
        return []

    recent: List[str] = []
    tables = []
    idx = 0

    for block in list(body):
        tag = block.tag.rsplit("}", 1)[-1]
        if tag == "p":
            txt = _norm("".join(t.text or "" for t in block.findall(".//w:t", NS)))
            if txt:
                recent.append(txt)
                if len(recent) > 8:
                    recent = recent[-8:]
            continue

        if tag != "tbl":
            continue

        idx += 1
        rows = []
        for tr in block.findall(".//w:tr", NS):
            cells = []
            for tc in tr.findall("./w:tc", NS):
                parts = []
                for p in tc.findall(".//w:p", NS):
                    seg = _norm("".join(t.text or "" for t in p.findall(".//w:t", NS)))
                    if seg:
                        parts.append(seg)
                cells.append(_norm(" ".join(parts)))
            if any(cells):
                rows.append(cells)

        title = recent[-1] if recent else ""
        tables.append({"table_index": idx, "title": title, "rows": rows})

    return tables


def _build_schema_payload(record: str, table: dict) -> dict:
    rows = table.get("rows", [])
    if not rows:
        return {
            "registro": record,
            "nome": RECORD_LABEL.get(record, f"Registro {record}"),
            "layout_version": "15.15",
            "source": {"type": "docx", "table_index": table.get("table_index")},
            "header": [],
            "campos": [],
            "status": "extraido_docx_vazio",
        }

    header = rows[0]
    data = rows[1:]
    col_count = max([len(header)] + [len(r) for r in data])
    padded_header = header + [f"coluna_{i + 1}" for i in range(len(header), col_count)]
    keys = [_sanitize_key(h, i) for i, h in enumerate(padded_header)]

    campos = []
    for row in data:
        padded = row + [""] * (col_count - len(row))
        item = {keys[i]: padded[i] for i in range(col_count)}
        if any(v for v in item.values()):
            campos.append(item)

    return {
        "registro": record,
        "nome": RECORD_LABEL.get(record, f"Registro {record}"),
        "layout_version": "15.15",
        "source": {
            "type": "docx",
            "document": "CIELO_Extrato_Eletronico_-_Manual_-_Versao_15_15.docx",
            "table_index": table.get("table_index"),
            "title": table.get("title", ""),
        },
        "header": padded_header,
        "campos": campos,
        "status": "extraido_docx",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Extrai schemas posicionais dos registros no DOCX")
    parser.add_argument("--workspace", default=".", help="Diretorio base")
    parser.add_argument("--promote", action="store_true", help="Sobrescreve schemas canonicos")
    args = parser.parse_args()

    root = Path(args.workspace)
    document_xml = root / ".cielo" / "_docx_unzip" / "word" / "document.xml"
    if not document_xml.exists():
        print(json.dumps({"status": "error", "message": f"missing:{document_xml}"}, ensure_ascii=False))
        return 1

    tables = _extract_tables(document_xml)
    extracted_dir = root / ".cielo" / "oficial-docx" / "schemas"
    extracted_dir.mkdir(parents=True, exist_ok=True)

    generated = []
    promoted = []

    for idx, record in TABLE_INDEX_TO_RECORD.items():
        table = next((t for t in tables if t.get("table_index") == idx), None)
        if not table:
            continue
        payload = _build_schema_payload(record, table)
        filename = RECORD_TO_FILENAME[record]

        extracted_path = extracted_dir / filename
        extracted_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        generated.append(str(extracted_path.as_posix()))

        if args.promote:
            canonical_path = root / "contracts" / "schemas" / filename
            canonical_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            promoted.append(str(canonical_path.as_posix()))

    report = {
        "status": "ok",
        "generated": generated,
        "promoted": promoted,
        "record_table_map": TABLE_INDEX_TO_RECORD,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
