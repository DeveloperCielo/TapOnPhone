import difflib
import json
import re
import unicodedata
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INPUT_PATH = ROOT / "contracts" / "tabelas" / "tabela-IX-motivos-ajuste.normalized.json"
OUTPUT_PATH = ROOT / "contracts" / "tabelas" / "tabela-IX-motivos-ajuste.refined.json"
OUTPUT_TOP_REVIEW_PATH = ROOT / "contracts" / "tabelas" / "tabela-IX-motivos-ajuste.review-top.json"

STOPWORDS = {
    "a",
    "ao",
    "aos",
    "as",
    "com",
    "da",
    "das",
    "de",
    "do",
    "dos",
    "e",
    "em",
    "na",
    "nas",
    "no",
    "nos",
    "o",
    "os",
    "para",
    "por",
    "que",
    "ref",
    "referente",
}

CONFLICT_PAIRS = [
    ("credito", "debito"),
    ("entrada", "saida"),
    ("inclusao", "exclusao"),
    ("cancelamento", "reativacao"),
]

PRIORITY_ORDER = {"alta": 0, "media": 1, "baixa": 2}

# Manual decisions approved from review-top queue.
MANUAL_MERGE_PAIRS = [
    ("IXD0077", "IXD0227"),
    ("IXD0076", "IXD0226"),
]

# Reviewed low-priority pairs approved as no-merge.
MANUAL_NO_MERGE_PAIRS = [
    ("IXD0357", "IXD0358"),
    ("IXD0333", "IXD0336"),
    ("IXD0182", "IXD0183"),
    ("IXD0333", "IXD0337"),
    ("IXD0193", "IXD0198"),
    ("IXD0291", "IXD0292"),
    ("IXD0406", "IXD0407"),
    ("IXD0308", "IXD0309"),
    ("IXD0103", "IXD0104"),
    ("IXD0259", "IXD0373"),
    ("IXD0249", "IXD0250"),
    ("IXD0211", "IXD0218"),
    ("IXD0102", "IXD0103"),
    ("IXD0379", "IXD0384"),
    ("IXD0077", "IXD0090"),
    ("IXD0359", "IXD0360"),
    ("IXD0096", "IXD0294"),
    ("IXD0059", "IXD0077"),
    ("IXD0288", "IXD0304"),
]


def _load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _normalize_text(text: str) -> str:
    raw = (text or "").strip().lower()
    raw = unicodedata.normalize("NFKD", raw)
    raw = "".join(ch for ch in raw if not unicodedata.combining(ch))
    raw = raw.replace("\u201c", '"').replace("\u201d", '"').replace("\u2019", "'")
    raw = re.sub(r"\s+", " ", raw)
    return raw.strip()


def _tokenize(text: str) -> set[str]:
    tokens = re.findall(r"[a-z0-9]+", _normalize_text(text))
    return {t for t in tokens if t not in STOPWORDS and len(t) > 1}


def _jaccard(tokens_a: set[str], tokens_b: set[str]) -> float:
    if not tokens_a and not tokens_b:
        return 1.0
    inter = len(tokens_a & tokens_b)
    union = len(tokens_a | tokens_b)
    return inter / union if union else 0.0


def _has_conflict(tokens_a: set[str], tokens_b: set[str]) -> bool:
    merged = tokens_a | tokens_b
    for left, right in CONFLICT_PAIRS:
        if left in merged and right in merged:
            return True
    return False


def _is_auto_merge_candidate(item_a: dict, item_b: dict) -> tuple[bool, dict]:
    desc_a = item_a["descricao_canonica"]
    desc_b = item_b["descricao_canonica"]

    norm_a = _normalize_text(desc_a)
    norm_b = _normalize_text(desc_b)

    tokens_a = _tokenize(desc_a)
    tokens_b = _tokenize(desc_b)

    ratio = difflib.SequenceMatcher(a=norm_a, b=norm_b).ratio()
    jaccard = _jaccard(tokens_a, tokens_b)
    overlap = len(tokens_a & tokens_b)

    conflict = _has_conflict(tokens_a, tokens_b)
    strong_match = ratio >= 0.95 or (jaccard >= 0.90 and ratio >= 0.90 and overlap >= 4)
    decision = strong_match and not conflict

    return decision, {
        "ratio": round(ratio, 4),
        "jaccard": round(jaccard, 4),
        "overlap_tokens": overlap,
        "conflict": conflict,
    }


def _is_review_candidate(item_a: dict, item_b: dict, auto_metrics: dict) -> bool:
    ratio = auto_metrics["ratio"]
    jaccard = auto_metrics["jaccard"]
    overlap = auto_metrics["overlap_tokens"]
    if auto_metrics["conflict"]:
        # Keep conflict pairs visible for manual review with stricter threshold.
        return ratio >= 0.92 and overlap >= 4
    return (ratio >= 0.88 and overlap >= 3) or (jaccard >= 0.78 and ratio >= 0.84 and overlap >= 3)


def _review_priority(metrics: dict) -> str:
    ratio = metrics["ratio"]
    jaccard = metrics["jaccard"]
    overlap = metrics["overlap_tokens"]
    conflict = metrics["conflict"]

    if conflict:
        if ratio >= 0.96 and overlap >= 5:
            return "media"
        return "baixa"

    if ratio >= 0.95 and jaccard >= 0.88 and overlap >= 4:
        return "alta"
    if ratio >= 0.91 and jaccard >= 0.82 and overlap >= 3:
        return "media"
    return "baixa"


def _review_recommendation(metrics: dict, priority: str) -> str:
    ratio = metrics["ratio"]
    jaccard = metrics["jaccard"]
    overlap = metrics["overlap_tokens"]
    conflict = metrics["conflict"]

    if conflict:
        return "so_revisar"
    if priority == "alta" and ratio >= 0.96 and jaccard >= 0.90 and overlap >= 5:
        return "merge_sugerido"
    if priority in {"alta", "media"}:
        return "so_revisar"
    return "nao_merge"


def _cluster_auto_merge(items: list[dict]) -> tuple[list[list[int]], list[dict]]:
    n = len(items)
    parent = list(range(n))
    review_pairs = []

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    for i in range(n):
        for j in range(i + 1, n):
            auto_merge, metrics = _is_auto_merge_candidate(items[i], items[j])
            if auto_merge:
                union(i, j)
                continue
            if _is_review_candidate(items[i], items[j], metrics):
                priority = _review_priority(metrics)
                recommendation = _review_recommendation(metrics, priority)
                review_pairs.append(
                    {
                        "canonical_id_a": items[i]["canonical_id"],
                        "canonical_id_b": items[j]["canonical_id"],
                        "descricao_a": items[i]["descricao_canonica"],
                        "descricao_b": items[j]["descricao_canonica"],
                        "ratio": metrics["ratio"],
                        "jaccard": metrics["jaccard"],
                        "overlap_tokens": metrics["overlap_tokens"],
                        "conflict": metrics["conflict"],
                        "prioridade": priority,
                        "recomendacao": recommendation,
                    }
                )

    clusters = {}
    for idx in range(n):
        root = find(idx)
        clusters.setdefault(root, []).append(idx)

    clustered = sorted(clusters.values(), key=lambda group: (len(group), group[0]), reverse=True)
    review_pairs = sorted(
        review_pairs,
        key=lambda x: (
            PRIORITY_ORDER.get(x["prioridade"], 99),
            -x["ratio"],
            -x["jaccard"],
            -x["overlap_tokens"],
        ),
    )
    return clustered, review_pairs


def _apply_manual_merges(
    clusters: list[list[int]],
    canonical_items: list[dict],
) -> tuple[list[list[int]], list[dict], set[tuple[str, str]]]:
    n = len(canonical_items)
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    # Seed DSU with current clustering.
    for group in clusters:
        if not group:
            continue
        head = group[0]
        for idx in group[1:]:
            union(head, idx)

    id_to_idx = {item["canonical_id"]: idx for idx, item in enumerate(canonical_items)}
    applied = []
    applied_pair_set = set()
    for left_id, right_id in MANUAL_MERGE_PAIRS:
        left_idx = id_to_idx.get(left_id)
        right_idx = id_to_idx.get(right_id)
        if left_idx is None or right_idx is None:
            continue
        union(left_idx, right_idx)
        pair = tuple(sorted((left_id, right_id)))
        applied_pair_set.add(pair)
        applied.append(
            {
                "canonical_id_a": pair[0],
                "canonical_id_b": pair[1],
                "decision": "merge_aprovado",
                "source": "review-top",
            }
        )

    grouped = {}
    for idx in range(n):
        root = find(idx)
        grouped.setdefault(root, []).append(idx)

    merged_clusters = sorted(grouped.values(), key=lambda group: (len(group), group[0]), reverse=True)
    return merged_clusters, applied, applied_pair_set


def build_refined_near_duplicates(payload: dict) -> dict:
    canonical_items = payload.get("dominio_canonico", [])
    alias_por_codigo = payload.get("alias_por_codigo", {})
    clusters, review_pairs = _cluster_auto_merge(canonical_items)
    clusters, manual_merges_applied, manual_pair_set = _apply_manual_merges(clusters, canonical_items)

    # Remove manually resolved pairs from manual-review queue.
    def _pair_key(item: dict) -> tuple[str, str]:
        return tuple(sorted((item.get("canonical_id_a", ""), item.get("canonical_id_b", ""))))

    manual_no_merge_pair_set = {tuple(sorted(pair)) for pair in MANUAL_NO_MERGE_PAIRS}

    review_pairs = [
        item
        for item in review_pairs
        if _pair_key(item) not in manual_pair_set and _pair_key(item) not in manual_no_merge_pair_set
    ]

    manual_no_merges_applied = [
        {
            "canonical_id_a": pair[0],
            "canonical_id_b": pair[1],
            "decision": "nao_merge_aprovado",
            "source": "review-low",
        }
        for pair in sorted(manual_no_merge_pair_set)
    ]

    priority_counts = {
        "alta": sum(1 for x in review_pairs if x.get("prioridade") == "alta"),
        "media": sum(1 for x in review_pairs if x.get("prioridade") == "media"),
        "baixa": sum(1 for x in review_pairs if x.get("prioridade") == "baixa"),
    }

    auto_clusters = []
    refined_domain = []
    cluster_idx = 0

    for group in clusters:
        if len(group) == 1:
            item = canonical_items[group[0]]
            refined_domain.append(
                {
                    "refined_id": item["canonical_id"],
                    "merge_type": "none",
                    "canonical_ids": [item["canonical_id"]],
                    "descricao_representante": item["descricao_canonica"],
                    "descricoes_representadas": [item["descricao_canonica"]],
                    "codigos": item.get("codigos", []),
                }
            )
            continue

        cluster_idx += 1
        cluster_id = f"IXN{cluster_idx:04d}"
        group_items = [canonical_items[i] for i in group]

        representative = min(group_items, key=lambda x: (len(x["descricao_canonica"]), x["descricao_canonica"].lower()))
        merged_codes = sorted({code for item in group_items for code in item.get("codigos", [])})
        canonical_ids = [item["canonical_id"] for item in group_items]

        merge_type = "auto_high_confidence"
        for left_id, right_id in manual_pair_set:
            if left_id in canonical_ids and right_id in canonical_ids:
                merge_type = "manual_review_approved"
                break

        cluster_payload = {
            "cluster_id": cluster_id,
            "merge_type": merge_type,
            "canonical_ids": canonical_ids,
            "descricao_representante": representative["descricao_canonica"],
            "descricoes_cluster": [item["descricao_canonica"] for item in group_items],
            "codigos": merged_codes,
        }
        auto_clusters.append(cluster_payload)
        refined_domain.append(
            {
                "refined_id": cluster_id,
                "merge_type": merge_type,
                "canonical_ids": cluster_payload["canonical_ids"],
                "descricao_representante": cluster_payload["descricao_representante"],
                "descricoes_representadas": cluster_payload["descricoes_cluster"],
                "codigos": merged_codes,
            }
        )

    refined_domain = sorted(refined_domain, key=lambda x: x["descricao_representante"].lower())

    canonical_to_refined_id = {}
    refined_descricao_by_id = {}
    for item in refined_domain:
        refined_id = item["refined_id"]
        refined_descricao_by_id[refined_id] = item["descricao_representante"]
        for canonical_id in item.get("canonical_ids", []):
            canonical_to_refined_id[canonical_id] = refined_id

    alias_por_codigo_refinado = {}
    for code, alias in sorted(alias_por_codigo.items()):
        canonical_ids = alias.get("canonical_ids", [])
        refined_ids = sorted({canonical_to_refined_id[x] for x in canonical_ids if x in canonical_to_refined_id})
        descricoes_canonicas = alias.get("descricoes_canonicas", [])

        descricao_representante = None
        if len(refined_ids) == 1:
            descricao_representante = refined_descricao_by_id.get(refined_ids[0])

        alias_por_codigo_refinado[code] = {
            "canonical_ids": canonical_ids,
            "descricoes_canonicas": descricoes_canonicas,
            "refined_ids": refined_ids,
            "descricao_representante": descricao_representante,
            "ambiguous": len(canonical_ids) > 1,
        }

    return {
        "tabela": "IX",
        "nome": payload.get("nome", "Tabela IX - Motivos de Ajuste"),
        "source": payload.get("source", {}),
        "derivado_de": "tabela-IX-motivos-ajuste.normalized.json",
        "refinamento_near_duplicates": {
            "descricao": "auto-merge conservador de near-duplicates e fila de revisao manual",
            "input_canonical_rows": len(canonical_items),
            "auto_merge_clusters": len(auto_clusters),
            "manual_merge_clusters": sum(1 for x in auto_clusters if x.get("merge_type") == "manual_review_approved"),
            "review_candidates": len(review_pairs),
            "review_priority_counts": priority_counts,
            "refined_rows": len(refined_domain),
            "codes_with_alias": len(alias_por_codigo_refinado),
        },
        "dominio_refinado": refined_domain,
        "alias_por_codigo_refinado": alias_por_codigo_refinado,
        "clusters_auto_merge": auto_clusters,
        "manual_merges_aplicados": manual_merges_applied,
        "manual_no_merges_aplicados": manual_no_merges_applied,
        "review_candidates": review_pairs,
    }


def build_top_review_view(refined: dict) -> dict:
    top_candidates = [
        item
        for item in refined.get("review_candidates", [])
        if item.get("prioridade") in {"alta", "media"}
    ]

    return {
        "tabela": "IX",
        "derivado_de": "tabela-IX-motivos-ajuste.refined.json",
        "descricao": "fila prioritaria para revisao manual (media/alta)",
        "resumo": {
            "total_review_candidates": len(refined.get("review_candidates", [])),
            "top_review_candidates": len(top_candidates),
            "priority_counts": refined.get("refinamento_near_duplicates", {}).get("review_priority_counts", {}),
        },
        "review_candidates_top": top_candidates,
    }


def main() -> int:
    if not INPUT_PATH.exists():
        print(json.dumps({"status": "error", "message": f"missing:{INPUT_PATH}"}, ensure_ascii=False))
        return 1

    payload = _load_json(INPUT_PATH)
    refined = build_refined_near_duplicates(payload)
    top_review = build_top_review_view(refined)
    OUTPUT_PATH.write_text(json.dumps(refined, ensure_ascii=False, indent=2), encoding="utf-8")
    OUTPUT_TOP_REVIEW_PATH.write_text(json.dumps(top_review, ensure_ascii=False, indent=2), encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "ok",
                "input": str(INPUT_PATH.as_posix()),
                "output": str(OUTPUT_PATH.as_posix()),
                "output_top_review": str(OUTPUT_TOP_REVIEW_PATH.as_posix()),
                "auto_merge_clusters": refined["refinamento_near_duplicates"]["auto_merge_clusters"],
                "review_candidates": refined["refinamento_near_duplicates"]["review_candidates"],
                "top_review_candidates": top_review["resumo"]["top_review_candidates"],
                "refined_rows": refined["refinamento_near_duplicates"]["refined_rows"],
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
