# Orquestrador Inicial - Versao MD Only

Este arquivo organiza a leitura da versao documental, sem dependencias de scripts.

## Ordem recomendada

1. Contexto geral
- `README.md`

2. Fluxo oficial de implantacao
- `docs/operacao/quickstart-implantacao.md`

3. Diretrizes para uso com agentes/IA
- `docs/operacao/1.toolkit-uso-em-ia.md`
- `docs/prompts/7.prompt-implantacao-ai.md`

4. Base de referencia funcional
- `docs/core/5.manual-completo.md`
- `docs/core/6.glossario.md`

5. Operacao do cliente
- `docs/operacao/8.onboarding-operacional-cliente.md`
- `docs/operacao/integracao-bancaria-interface.md`
- `docs/operacao/troubleshooting-operacional.md`

6. Evidencias e exemplos de homologacao (documentais)
- `exemplos/README.md`
- `exemplos/cenarios-homologacao-leitor-edi.md`

## Uso recomendado desta versao

- Compartilhamento com clientes que nao podem baixar scripts.
- Alinhamento de processo, regras e responsabilidades.
- Treinamento operacional e onboarding.

## Limite desta versao

Esta versao nao executa validacoes automaticas. Quando necessario, usar o pacote tecnico completo para execucao e evidencias automatizadas.
