# Quickstart de Implantacao

Este e o unico fluxo oficial para implantacao do toolkit em ambiente de cliente.

## 1. Pre-requisitos

- Acesso aos arquivos do toolkit
- Time tecnico e time operacional alinhados no escopo

## 2. Preparacao

1. Validar se o pacote contem todos os documentos obrigatorios.
2. Definir responsaveis de implantacao, homologacao e suporte.
3. Confirmar dados e escopo funcional antes da homologacao.

## 3. Estrutura esperada

A execucao exige estes artefatos:

- `2.manual-extrato-v15.15.schema.json`
- `3.schemas/`
- `4.tabelas/`
- `docs/core/5.manual-completo.md`
- `docs/core/6.glossario.md`
- `docs/prompts/7.prompt-implantacao-ai.md`
- `resultado-validacao.schema.json`
- `resultado-conciliacao.schema.json`

## 4. Comando de validacao estrutural

Nesta versao MD-only, usar checklist documental para validacao estrutural.

Criterio de aceite:

- todos os artefatos obrigatorios presentes
- sem lacunas de documentacao no escopo contratado

## 5. Comando de homologacao

Nesta versao MD-only, homologacao deve ser conduzida por evidencias documentais e registros operacionais.

Criterio de aceite:

- todos os cenarios obrigatorios avaliados
- evidencias de aprovacao registradas

## 6. Comandos essenciais adicionais

Atividades essenciais adicionais:

1. Revisar aderencia ao layout por tipo de arquivo.
2. Validar regras de negocio criticas por amostragem.
3. Confirmar trilha de conciliacao entre venda, pagamento e banco.

## 7. Troubleshooting basico

- Erro de arquivo ausente:
  - Ajustar estrutura do pacote e reconfirmar checklist documental.
- Erro de dependencia de automacao:
  - Nesta versao, registrar o bloqueio e direcionar para o pacote tecnico completo.
- Erro de permissao em escrita:
  - Registrar incidente de ambiente e acionar time de infraestrutura.
