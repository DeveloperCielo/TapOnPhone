# Integracao Bancaria - Validacao de Valores no Banco

## Objetivo

Definir como validar, no extrato bancario do cliente, os valores enviados pela Cielo, sem depender de layout de exemplo.

## Regra oficial de validacao bancaria

Para validacao bancaria, o cliente deve conferir os valores enviados em:

1. `CIELO04`
2. `CIELO16` (caso transacione Pix)
3. `CIELO03` (exclusivamente para cliente que transaciona `TC D0`)

Observacao:
- Nao usar `CIELO03` como base geral de validacao bancaria quando o cliente nao opera `TC D0`.

## Politica deste pacote

1. Nao manter arquivo bancario de exemplo fixo no repositorio.
2. A validacao deve usar o extrato bancario real do cliente (com mascaramento quando necessario).
3. O layout bancario deve ser mapeado por cliente/banco antes da conciliacao.

## Contrato minimo para ingestao bancaria (CSV)

Campos obrigatorios:
- `data_movimento` (YYYY-MM-DD)
- `valor` (decimal com sinal)

Campos recomendados para rastreabilidade:
- `descricao`
- `documento`
- `conta`
- `fonte_edi` (`CIELO04`, `CIELO16`, `CIELO03_TC_D0`)

## Execucao

Usar arquivo real do cliente e registrar o resultado conciliado em artefato versionado de evidencias.

## Resultado esperado

O resultado deve destacar:

1. `matched`
2. `unmatched_bank`
3. `unmatched_edi`

e suportar rastreabilidade por valor, data e origem.
# Integracao Bancaria - Interface de Validacao Bancaria (CSV/OFX/API)

## Objetivo

Definir o contrato minimo para validar no banco os valores enviados pela Cielo.

Regra do manual para validacao bancaria:
1. Validar valores enviados no arquivo `CIELO04`.
2. Validar valores enviados no arquivo `CIELO16` quando o cliente transaciona Pix.
3. Validar valores enviados no arquivo `CIELO03` exclusivamente para cliente que transaciona `TC D0`.

Observacao importante:
- O arquivo `CIELO03` nao deve ser usado como base geral de validacao bancaria quando o cliente nao opera `TC D0`.

## Escopo desta versao

1. Suporte implementado: CSV.
2. OFX/API: interface especificada para adaptadores futuros.
3. Validacao orientada por origem de arquivo EDI (`CIELO04`, `CIELO16`, `CIELO03-TC-D0`).

## Contrato minimo de evento bancario

Campos obrigatorios:
- `data_movimento` (YYYY-MM-DD)
- `valor` (decimal com sinal; credito positivo, debito negativo)

Campos recomendados:
- `descricao`
- `documento`
- `conta`
- `origem`

Campos recomendados para rastreabilidade com EDI:
- `fonte_edi` (`CIELO04`, `CIELO16`, `CIELO03_TC_D0`)
- `chave_conciliacao`

## Mapeamento CSV padrao

Colunas padrao esperadas:
- `data_movimento`
- `valor`
- `descricao`
- `documento`
- `fonte_edi` (recomendado)

Exemplo:

```csv
id,data_movimento,valor,descricao,documento,fonte_edi
1,2026-07-01,9329.70,CREDITO CIELO,REF001,CIELO04
2,2026-07-01,120.35,TARIFA BANCARIA,REF002,
```

## Regras de validacao bancaria (versao inicial)

1. Origem dos valores por arquivo EDI
- Base principal: `CIELO04`.
- Adicional para Pix: `CIELO16`.
- Excecao `TC D0`: `CIELO03` apenas quando aplicavel ao cliente.

2. Chave de conciliacao bancaria
- `abs(valor)` com tolerancia configuravel (default 0.01)

3. Resultado
- `matched`: evento do banco encontrou trilha do EDI por valor
- `unmatched_bank`: evento bancario sem correspondente no EDI
- `unmatched_edi`: trilha EDI sem correspondente no banco

4. Saida
- JSON com trilhas conciliadas e pendencias bancarias auditaveis

## Extensoes futuras

1. OFX adapter
- Conversao OFX -> contrato minimo acima

2. API adapter
- Conversao payload API -> contrato minimo acima

3. Matching avancado
- Compor chave por valor + data + documento
- Janela de tolerancia temporal configuravel



