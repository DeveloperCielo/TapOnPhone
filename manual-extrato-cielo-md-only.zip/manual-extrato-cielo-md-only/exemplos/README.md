# Exemplos

Arquivos reais de producao para validacao documental de leitura e consistencia.

Conjunto atual:

- CIELO03D_1234567890_20260701_20260701_20260701.TXT
- CIELO04D_1234567890_20260701_20260701_20260701.TXT
- CIELO09D_1234567890_20260701_20260701_20260701.TXT
- CIELO15D_1234567890_20260701_20260701_20260701.TXT
- CIELO16D_1234567890_20260701_20260701_20260701.TXT

Observacao sobre mascaramento:

- Dados sensiveis de identificacao (estabelecimento, CNPJ e dados bancarios) foram mascarados.
- O layout fixo, tipos de registro e regras de nomenclatura do manual foram preservados para validacao.

Nomenclatura esperada para validacao:

- CIELOXXD_<ec_10_digitos>*<data_yyyymmdd>*<data_yyyymmdd>_<data_yyyymmdd>.TXT

Uso nesta versao MD-only:

- Utilizar os arquivos como referencia de layout, cenarios e evidencias.
- Registrar resultados de validacao/homologacao em artefatos documentais do projeto.
- Quando for necessaria execucao automatizada, utilizar o pacote tecnico completo.

