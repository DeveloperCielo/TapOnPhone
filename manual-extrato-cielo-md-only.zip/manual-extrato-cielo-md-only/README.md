# Manual Extrato Eletronico Cielo - Versao MD Only

Esta versao foi preparada para distribuicao apenas com arquivos Markdown (`.md`), sem scripts, sem JSON e sem automacoes locais.

## Objetivo

Fornecer um pacote documental leve para clientes que possuem restricoes de download/execucao de scripts no ambiente.

## Ponto de entrada

- `docs/00-orquestrador-inicial.md`

## O que esta versao contem

- Documentacao funcional e operacional em Markdown.
- Fluxo de leitura e implantacao orientado por documento.
- Referencias de onboarding, troubleshooting e integracao bancaria.

## O que esta versao NAO contem

- Scripts Python.
- Automacoes tecnicas de esteira.
- Contratos JSON/JSON Schema.
- Fixtures de automacao.

## Observacao importante

Se o cliente quiser automacao tecnica (parser, validacao, homologacao, conciliacao), deve usar o pacote tecnico completo `manual-extrato-cielo`.

Nesta versao MD-only, o foco e orientacao, governanca e operacao documental.
