# Implementação Tap on Phone com IA

Este repositório contém instruções e documentação para implementar o SDK Cielo Tap on Phone utilizando agentes de IA como assistentes no desenvolvimento.

## Pré-requisitos

Antes de utilizar as instruções de IA para implementação, é necessário ter o SDK devidamente configurado no seu projeto.

### Android

Você deve ter os arquivos `.aar` do SDK adicionados ao seu projeto. Estes arquivos podem ser baixados através do [Manual de integração](https://docs.cielo.com.br/conecta/docs/requisitos-android).

**Localização esperada das bibliotecas:**

![Localização da libs](./skill-tap/docs/markdown/images-android/img_19.png)

> ⚠️ **Importante:** Sem essa configuração, o agente não conseguirá prosseguir com a implementação.

## Como utilizar as instruções de IA

Após descompactar o arquivo na raiz do projeto em uma pasta, por exemplo `skill-tap`, você pode escolher entre a melhor abordagens para integrar as instruções com seu agente de IA. Abaixo, segue dois exemplos.

### Opção 1: Arquivo AGENTS.md (Recomendado para GitHub Copilot Workspace)

**1. Estrutura de pastas:**
```
seu-projeto/
├── skill-tap/
│   └── tap_implementation.md
│   └── tap_android.md
│   └── docs/
│       └── markdown/
└── AGENTS.md
```

**2. Crie o arquivo `AGENTS.md` na raiz do projeto:**

**Exemplo de conteúdo:**
```markdown
# Instruções para Agentes de IA

## Tap on Phone (SDK Cielo)

Para tudo relacionado à implementação do SDK Tap on Phone, incluindo:
- Inicialização e configuração
- Implementação de transações
- Tratamento de erros
- Customização de UI

Consulte as instruções detalhadas em:
- `skill-tap/tap_implementation.md` - Instruções gerais
- `skill-tap/tap_android.md` - Específico para Android
```

**3. Exemplo de uso com o agente:**

> 💡 **Dica:** Você pode gerar o AGENTS.md automaticamente usando o seguinte prompt:
> 
> _"Crie um arquivo padrão AGENTS.md na raiz do projeto. Para tudo relacionado a TAP (implementação, troubleshooting e customização), referencie o arquivo skill-tap/tap_implementation.md"_

### Opção 2: GitHub Copilot Instructions

Para usuários do GitHub Copilot, você pode criar instruções específicas no diretório `.github/instructions/`.

**1. Estrutura de pastas:**
```
seu-projeto/
├── .github/
│   └── instructions/
│       └── tap.instructions.md
└── skill-tap/
    └── ...
```

**2. Conteúdo do arquivo `.github/instructions/tap.instructions.md`:**

**Exemplo:**
```markdown
# Tap on Phone SDK - Instruções de Implementação

Ao trabalhar com o SDK Cielo Tap on Phone:

1. Sempre consulte a documentação em `skill-tap/tap_implementation.md`
2. Para código Android específico: `skill-tap/tap_android.md`
3. Siga as práticas recomendadas de segurança do SDK
4. Sempre trate erros usando os callbacks apropriados
```

**3. Exemplo de utilização:**

## Documentação Disponível

Este repositório contém a seguinte documentação:

- 📱 **Android:**
  - [Manual de integração](https://docs.cielo.com.br/conecta/docs/requisitos-android)

## Suporte

Para dúvidas ou problemas com o SDK, consulte:
1. Os manuais de integração específicos da sua plataforma
2. As instruções de troubleshooting nos arquivos `tap_*.md`
3. O suporte técnico da Cielo
