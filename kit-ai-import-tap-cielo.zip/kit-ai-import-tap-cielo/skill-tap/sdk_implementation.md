# SDK Implementation Guide

## Instruções para Agente de IA

Este documento contém as regras de implementação do SDK para projeto Android.

---

## Fluxo de Decisão (Android)

### 1. Verificar Contexto

Verifique se já existe informação no contexto sobre qual SDK será integrado (TAP ou PIX).

### 2. Questionar Usuário (se necessário)

**⚠️ OBRIGATÓRIO:** Se não houver informação no contexto, **SEMPRE** pergunte ao usuário:

> **"Deseja se integrar ao SDK TAP ou PIX?"**

### 3. Seguir Documentação Apropriada

Com base na resposta ou informação de contexto:

- **Se TAP:**  
  ✅ **Ação:** Leia e siga as instruções do arquivo: [`tap_android.md`](./tap_android.md)

- **Se PIX:**  
  ✅ **Ação:** Leia e siga as instruções do arquivo: [`pix_android.md`](./pix_android.md)

---

## Resumo do Fluxo

```
┌─────────────────────────────┐
│ Projeto Android             │
└──────────┬──────────────────┘
           │
┌──────────▼─────────────────────────┐
│ Já sabe se é integração TAP ou PIX?│
└──────────┬─────────────────────────┘
           │
    ┌──────┴────────┐
    │               │
 ┌──▼──┐         ┌──▼───────────────────────────┐
 │ Sim │         │ Não → PERGUNTAR ao usuário:  │
 └──┬──┘         │ "Deseja integrar TAP ou PIX?"│
    │            └──┬───────────────────────────┘
    │               │
    └───────┬───────┘
            │
     ┌──────┴──────┐
     │             │
 ┌───▼───┐     ┌───▼───┐
 │  TAP  │     │  PIX  │
 └───┬───┘     └───┬───┘
     │             │
┌────▼──────────┐ ┌▼───────────────┐
│ tap_android.md│ │ pix_android.md │
└───────────────┘ └────────────────┘
```

---

## Arquivos de Referência

- **Android + TAP:** [`tap_android.md`](./tap_android.md)
- **Android + PIX:** [`pix_android.md`](./pix_android.md)

---

## Notas Importantes

1. **Sempre verifique o contexto** antes de fazer perguntas ao usuário
2. A pergunta sobre TAP ou PIX é **obrigatória** se não houver contexto
3. Siga rigorosamente o arquivo de documentação apropriado após identificar o SDK
