# Skill TAP — Documentação do SDK Cielo TAP

Esta documentação técnica do **SDK Cielo TAP** para integração via pagamento por aproximação (NFC) em dispositivos Android.

## O que é o SDK Cielo TAP?

O SDK Cielo TAP permite que aplicativos móveis realizem cobranças por aproximação (NFC) sem necessidade de hardware externo de POS. O smartphone do lojista se transforma no terminal de pagamento.

---
## Regras OBRIGATÓRIO
- Deve seguir todas instruções abaixo sem ignorar, elas são OBRIGATÓRIAS
- Não tem autorização para instalar nada na máquina do usuário

## Android
- Verificar se há pasta libs dentro do modulo principal, e que dentro dessa pasta contenha algum aar com nome taponphone*, se não estiver, parar a execução e informar ao usuário que é necessário implementar os aars antes de continuar.
- Antes de iniciar qualquer tarefa, usando esse arquivo, o agente deve ler todas documentações contidas na pasta ./docs/markdown/*-android.md, após leitura, deve confirmar que já possuí contexto sobre a implementacao do TAP.
- Nunca use reflection, se ocorreu algum problema na implementação, faça a correção, e tente novamente.

### 1. Gradle (OBRIGATÓRIO)
- Deve realizar a configuração das dependências conforme descrito no manual-integracao-android.md
- Deve ser aplicado os implementation conforme descrito no manual-integracao-android.md.
- Configurar os build hml para usar o as dependencias *.aar ou *.jar contidos na pasta "**modulo principal**/libs/hml", por exemplo, app/libs/hml

### 1.0 Dependências Completas (OBRIGATÓRIO — NENHUMA PODE SER OMITIDA)

O agente DEVE implementar **todas** as dependências abaixo no arquivo `app/build.gradle.kts`, sem exceção. Cada grupo corresponde a um módulo funcional do SDK.

#### 1.0.1 Plugins obrigatórios no `app/build.gradle.kts`

```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
}
```

#### 1.0.2 Configuração do `build.gradle.kts` raiz (OBRIGATÓRIO)

O agente DEVE adicionar o bloco `buildscript` no arquivo `build.gradle.kts` da **raiz do projeto** (não no app). Este é o local correto para o Dynatrace e R8:

```kotlin
buildscript {
    repositories {
        mavenCentral()
        maven {
            url = uri("https://storage.googleapis.com/r8-releases/raw")
        }
    }
    dependencies {
        classpath("com.android.tools:r8:8.3.37")
        classpath("com.dynatrace.tools.android:gradle-plugin:8.279.1.1002")
    }
}
```

> ⚠️ **ATENÇÃO — Dynatrace Plugin**: O plugin `com.dynatrace.tools.android` **não pode** ser aplicado via `id(...)` no bloco `plugins {}` do `app/build.gradle.kts`, pois ele não registra esse plugin ID no manifesto de forma compatível com o Gradle moderno. O correto é adicioná-lo como `classpath` no `buildscript` do `build.gradle.kts` raiz conforme acima, e usar o agente como dependência de runtime (item 1.0.3).

#### 1.0.3 `settings.gradle.kts` — Repositórios e artefatos locais (OBRIGATÓRIO)

```kotlin
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        mavenLocal {
            setUrl("${rootDir}/artefacts")
        }

        flatDir {
            dirs("libs")
        }
    }
}
```

#### 1.0.4 `gradle.properties` — Jetifier (OBRIGATÓRIO)

```properties
android.enableJetifier=true
```

#### 1.0.5 Dependências completas no `app/build.gradle.kts` (OBRIGATÓRIO)

O agente DEVE implementar **todas** as linhas abaixo sem omitir nenhuma:

```kotlin
dependencies {
    // AAR/JAR locais da pasta libs (OBRIGATÓRIO)
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
    debugImplementation(fileTree(mapOf("dir" to "libs/hml", "include" to listOf("*.jar", "*.aar"))))

    // Dependências nativas AndroidX
    implementation("androidx.core:core-ktx:1.9.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Módulo de segurança — OkHttp
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // Módulo de segurança — Camera (Allowme)
    implementation("androidx.camera:camera-camera2:1.4.0")
    implementation("androidx.camera:camera-lifecycle:1.4.0")
    implementation("androidx.camera:camera-view:1.4.0")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.scottyab:rootbeer-lib:0.1.1")

    // Google Mobile Services
    implementation("com.google.android.gms:play-services-ads-identifier:18.0.1")
    implementation("com.google.android.gms:play-services-appset:16.0.2")
    implementation("com.google.android.gms:play-services-tasks:18.0.2")

    // Módulo de pagamento — TAP
    implementation("com.google.android.play:integrity:1.2.0")
    implementation("com.madgag.spongycastle:core:1.58.0.0")
    implementation("com.madgag.spongycastle:prov:1.58.0.0")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78")
    implementation("io.reactivex.rxjava2:rxjava:2.2.6")
    implementation("io.reactivex.rxjava2:rxandroid:2.1.1")
    implementation("com.airbnb.android:lottie:6.7.1")
    implementation("com.android.volley:volley:1.2.1")
    implementation("net.danlew:android.joda:2.9.9.4")
    implementation("com.google.guava:guava:32.0.1-jre")
    implementation("androidx.databinding:viewbinding:7.1.2")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.squareup.retrofit2:retrofit:3.0.0")
    implementation("com.squareup.retrofit2:converter-gson:3.0.0")

    // Room — Persistência local
    implementation("androidx.room:room-runtime:2.7.0")
    implementation("androidx.room:room-ktx:2.7.0")
    annotationProcessor("androidx.room:room-compiler:2.7.0")
    kapt("androidx.room:room-compiler:2.7.0")
    testImplementation("androidx.room:room-testing:2.7.0")

    // JWT
    api("io.jsonwebtoken:jjwt-api:0.13.0")
    runtimeOnly("io.jsonwebtoken:jjwt-gson:0.13.0")
    runtimeOnly("io.jsonwebtoken:jjwt-impl:0.13.0")

    // WorkManager — versão estritamente fixada
    api("androidx.work:work-runtime:2.8.1")
    api("androidx.work:work-runtime-ktx:2.8.1")

    // Módulo de log — Datadog
    implementation("com.datadoghq:dd-sdk-android-logs:2.11.0")
    implementation("com.datadoghq:dd-sdk-android-okhttp:2.11.0")

    // Módulo de log — Dynatrace Agent (dependência de runtime — NÃO aplicar como plugin)
    implementation("com.dynatrace.agent:agent-android:8.279.1.1002")

    // Segurança
    implementation("androidx.security:security-crypto:1.1.0-alpha03")

    // Testes
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
```

#### 1.0.6 Dependência Discover SDK — Atenção à versão (OBRIGATÓRIO)

> ⚠️ **ATENÇÃO — Discover SDK**: As versões do `com.discover.sdk:core` e `com.discover.sdk:card-reader` usam nomenclatura especial (ex: `COR1.1.4-releaseCandidate`, `TOOK2.3.2-releaseCandidate`). O agente **deve verificar** a pasta `artefacts/com/discover/sdk/` no projeto para descobrir as versões disponíveis antes de adicionar as dependências. Se as versões com nomenclatura especial não estiverem disponíveis no Maven local, omitir essas dependências para não bloquear o build — o TAP SDK inclui essas bibliotecas internamente nos AARs da pasta `libs/`.

Para verificar as versões disponíveis:
```bash
ls artefacts/com/discover/sdk/core/
ls artefacts/com/discover/sdk/card-reader/
```

Se existirem as pastas com as versões corretas, adicionar:
```kotlin
implementation("com.discover.sdk:core:<VERSAO_ENCONTRADA>")
implementation("com.discover.sdk:card-reader:<VERSAO_ENCONTRADA>")
```

### 1.1 Resolução de Conflito META-INF (IMPORTANTE)
Durante a integração, podem ocorrer conflitos de empacotamento quando múltiplas dependências (ex: `bcprov-jdk18on` e `jspecify`) contêm o mesmo caminho de recurso `META-INF/versions/9/OSGI-INF/MANIFEST.MF`.

**Solução:** Adicione o seguinte bloco ao arquivo `app/build.gradle.kts` dentro de `android { ... }`:

```kotlin
packaging {
    resources {
        excludes += "META-INF/versions/9/OSGI-INF/MANIFEST.MF"
    }
}
```

**Explicação:** O recurso `META-INF/versions/9/OSGI-INF/MANIFEST.MF` é metadado OSGI para ambientes Java e não é funcional em runtime Android. Sua exclusão não impacta a funcionalidade do TAP.

**Validação:** Executar `./gradlew :app:assembleDebug` para confirmar que o build finaliza sem erro de "duplicate path".

### 1.2 AndroidManifest.xml (OBRIGATÓRIO)

Antes de concluir a tarefa, o agente DEVE revisar e ajustar o `app/src/main/AndroidManifest.xml` para garantir que os itens de integração TAP estão explícitos no app integrador.

Checklist obrigatório no `manifest`:

```xml
<uses-permission android:name="android.permission.NFC" />

<uses-feature
    android:name="android.hardware.nfc"
    android:required="false"
    tools:replace="android:required" />

<uses-feature
    android:name="android.hardware.camera"
    android:required="false"
    tools:replace="android:required" />
```

Se houver conflito de merge no `<application>`, o agente pode usar `tools:replace` (exemplo: `android:allowBackup`) para resolver o build, porém isso NÃO substitui o checklist acima.

Regra de prevenção:
- É proibido encerrar a implementação com "build passou" sem validar o checklist do `AndroidManifest.xml`.
- A validação final deve incluir: ajuste de manifest + `./gradlew :app:assembleDebug`.

### 2. Jornadas (OBRIGATÓRIO)

## ⛔ PARADA OBRIGATÓRIA — Antes de implementar qualquer código

> O agente DEVE fazer a seguinte pergunta ao usuário e aguardar a resposta antes de escrever qualquer linha de código:
> "Você vai querer usar as telas do SDK para jornada?"
> - Resposta positiva ou dúvida → seguir a seção 2.1
> - Resposta negativa → seguir a seção 2.2

**NÃO prosseguir sem a resposta do usuário.**

#### 2.1 Jornadas usando telas do SDK (OBRIGATÓRIO)
Ao optar por esse ponto, o agente deve seguir, obrigatoriamente, os seguintes metodos do tap(initializer, initJourney e por último initPayment)
- **Importante**: Quando implementar o initJourney não iniciar o parâmetro **defaultData**, a menos que o usuário solicite.
- Ordem lógica para implementação:
  - Quando initializer retornar onInitializeSuccess, iniciar o initJourney
  - Quando initJourney retornar endCallback, com o dado journeyData preenchido, ai pode ser iniciado initPayment

Exemplo de incorreto do JourneyData
```Kotlin
private fun startPayment(config: ConfigBuilder) {
  val journeyData = JourneyData(
    price = BigDecimal("10.00"),
    paymentMethod = PaymentMethodsEnum.CREDIT_SINGLE,
    installments = 1
  )

  val tapOnPhoneSdk = TapOnPhone.getInstance()
  tapOnPhoneSdk.initPayment(
    context = this,
    logoImageRes = R.drawable.ic_launcher_foreground,
    initialData = journeyData,
    config = config,
    onPaymentStart = {
      Toast.makeText(this, "Pagamento iniciado", Toast.LENGTH_SHORT).show()
    },
    onPaymentSuccess = { paymentTransaction ->
      Toast.makeText(
        this,
        "Pagamento realizado com sucesso!",
        Toast.LENGTH_SHORT
      ).show()
    },
    onPaymentFailure = { errorEnum, exception ->
      Toast.makeText(
        this,
        "Erro no pagamento: $errorEnum - ${exception?.message ?: ""}",
        Toast.LENGTH_SHORT
      ).show()
    },
    onNewSale = {
      Toast.makeText(this, "Nova venda iniciada", Toast.LENGTH_SHORT).show()
    },
    onEnd = {
      Toast.makeText(this, "Encerrado", Toast.LENGTH_SHORT).show()
    }
  )
}
```

Exemplo de correto do JourneyData
```Kotlin
private fun startPayment(config: ConfigBuilder, journeyData: JourneyData) {
  val tapOnPhoneSdk = TapOnPhone.getInstance()
  tapOnPhoneSdk.initPayment(
    context = this,
    logoImageRes = R.drawable.ic_launcher_foreground,
    initialData = journeyData,
    config = config,
    onPaymentStart = {
      Toast.makeText(this, "Pagamento iniciado", Toast.LENGTH_SHORT).show()
    },
    onPaymentSuccess = { paymentTransaction ->
      Toast.makeText(
        this,
        "Pagamento realizado com sucesso!",
        Toast.LENGTH_SHORT
      ).show()
    },
    onPaymentFailure = { errorEnum, exception ->
      Toast.makeText(
        this,
        "Erro no pagamento: $errorEnum - ${exception?.message ?: ""}",
        Toast.LENGTH_SHORT
      ).show()
    },
    onNewSale = {
      Toast.makeText(this, "Nova venda iniciada", Toast.LENGTH_SHORT).show()
    },
    onEnd = {
      Toast.makeText(this, "Encerrado", Toast.LENGTH_SHORT).show()
    }
  )
}
```

#### 2.2 Jornada usando telas do usuário. (OBRIGATÓRIO)
Ao optar por esse ponto, o agente deve seguir, obrigatoriamente, os seguintes metodos do tap, o initializer, e criar um metodo para o initPayment recebendo o initialData via parametro do metodo.
- **Importante**: O initialData deve ser recebido por parametro do metodo que está implementado o initPayment.
- Ordem lógica para implementação:
  - Quando initializer retornar onInitializeSuccess, iniciar o initPayment com obrigatoriedade de receber via parâmetro o journeyData que não pode ser nulo.

### 2.3 Fluxo de Cancelamento (OBRIGATÓRIO)

## ⛔ PARADA OBRIGATÓRIA — Antes de implementar o cancelamento

> Quando o usuário solicitar a implementação do **fluxo de cancelamento**, o agente DEVE fazer a seguinte pergunta ao usuário e aguardar a resposta antes de escrever qualquer linha de código:
> "Você vai querer usar as telas do SDK para o cancelamento?"
> - Resposta positiva ou dúvida → seguir a seção 2.3.1
> - Resposta negativa → seguir a seção 2.3.2

**NÃO prosseguir sem a resposta do usuário.**

#### 2.3.1 Cancelamento usando telas do SDK (OBRIGATÓRIO)

Ao optar por esse ponto, o agente deve seguir, obrigatoriamente, a seguinte ordem de implementação:

1. **Ordem lógica obrigatória**:
   - Quando `initialize` retornar `onInitializeSuccess`, chamar o método `showAgenda` do `TapOnPhone`
   - Quando o callback `selectedTransactionToCancelation` do `showAgenda` devolver o `transaction`, chamar o método `initCancelation` passando o `transaction` recebido

2. **Fluxo de execução**:
   ```
   Initialize → onInitializeSuccess
       ↓
   ShowAgenda → usuário seleciona transação
       ↓
   selectedTransactionToCancelation(transaction)
       ↓
   InitCancelation(transaction)
   ```

3. **Regras importantes**:
   - O `transaction` deve ser obtido **exclusivamente** do callback `selectedTransactionToCancelation`
   - Não criar ou manipular o objeto `transaction` manualmente
   - O SDK gerencia toda a interface de seleção de transação

**Exemplo de implementação correta**:

```kotlin
private fun iniciarCancelamentoComTelas() {
    val config = createConfig()
    
    // Passo 1: Initialize
    paymentProcessor.initialize(
        context = this,
        config = config,
        onSuccess = {
            // Passo 2: ShowAgenda quando initialize tem sucesso
            abrirAgendaParaCancelamento(config)
        },
        onFailure = { exception ->
            Toast.makeText(this, "Erro ao inicializar: ${exception.message}", Toast.LENGTH_LONG).show()
        }
    )
}

private fun abrirAgendaParaCancelamento(config: ConfigBuilder) {
    val tapOnPhoneSdk = TapOnPhone.getInstance()
    
    tapOnPhoneSdk.showAgenda(
        context = this,
        config = config,
        selectedTransactionToCancelation = { transaction ->
            // Passo 3: InitCancelation quando usuário seleciona transação
            if (transaction != null) {
                iniciarCancelamento(config, transaction)
            }
        },
        onStartDetailsSale = {
            Toast.makeText(this, "Carregando detalhes...", Toast.LENGTH_SHORT).show()
        },
        onSuccessDetailsSale = {
            Toast.makeText(this, "Detalhes carregados", Toast.LENGTH_SHORT).show()
        },
        onFailure = {
            Toast.makeText(this, "Erro ao carregar agenda", Toast.LENGTH_LONG).show()
        }
    )
}

private fun iniciarCancelamento(config: ConfigBuilder, transaction: PaymentTransaction) {
    val tapOnPhoneSdk = TapOnPhone.getInstance()
    
    tapOnPhoneSdk.initCancelation(
        context = this,
        config = config,
        paymentTransaction = transaction,
        onCancelationStart = {
            Toast.makeText(this, "Iniciando cancelamento...", Toast.LENGTH_SHORT).show()
        },
        onCancelationSuccess = { cancelationResult ->
            Toast.makeText(this, "Cancelamento realizado com sucesso!", Toast.LENGTH_LONG).show()
        },
        onCancelationFailure = { errorEnum, exception ->
            Toast.makeText(this, "Erro no cancelamento: ${exception?.message}", Toast.LENGTH_LONG).show()
        },
        onEnd = {
            Toast.makeText(this, "Processo finalizado", Toast.LENGTH_SHORT).show()
        }
    )
}
```

#### 2.3.2 Cancelamento usando telas do usuário (OBRIGATÓRIO)

Ao optar por esse ponto, o agente deve seguir, obrigatoriamente, a seguinte ordem de implementação:

1. **Ordem lógica obrigatória**:
   - Quando `initialize` retornar `onInitializeSuccess`, chamar o método `initCancelation`
   - O `paymentTransaction` DEVE ser recebido via **parâmetro** no método que implementa o `initCancelation`
   - É **OBRIGATÓRIO** que o `paymentTransaction` não seja nulo

2. **Fluxo de execução**:
   ```
   Initialize → onInitializeSuccess
       ↓
   InitCancelation(paymentTransaction) ← paymentTransaction recebido via parâmetro
   ```

3. **Regras importantes**:
   - O método que chama `initCancelation` DEVE receber `paymentTransaction` como parâmetro
   - Não é permitido criar o `paymentTransaction` dentro do método
   - O desenvolvedor é responsável por fornecer o `paymentTransaction` (via consulta anterior, banco de dados, etc.)

**Exemplo de implementação correta**:

```kotlin
// Método que recebe paymentTransaction via parâmetro (OBRIGATÓRIO)
private fun iniciarCancelamento(paymentTransaction: PaymentTransaction) {
    val config = createConfig()
    
    // Passo 1: Initialize
    paymentProcessor.initialize(
        context = this,
        config = config,
        onSuccess = {
            // Passo 2: InitCancelation quando initialize tem sucesso
            executarCancelamento(config, paymentTransaction)
        },
        onFailure = { exception ->
            Toast.makeText(this, "Erro ao inicializar: ${exception.message}", Toast.LENGTH_LONG).show()
        }
    )
}

private fun executarCancelamento(config: ConfigBuilder, paymentTransaction: PaymentTransaction) {
    val tapOnPhoneSdk = TapOnPhone.getInstance()
    
    tapOnPhoneSdk.initCancelation(
        context = this,
        config = config,
        paymentTransaction = paymentTransaction,
        onCancelationStart = {
            Toast.makeText(this, "Iniciando cancelamento...", Toast.LENGTH_SHORT).show()
        },
        onCancelationSuccess = { cancelationResult ->
            Toast.makeText(this, "Cancelamento realizado com sucesso!", Toast.LENGTH_LONG).show()
        },
        onCancelationFailure = { errorEnum, exception ->
            Toast.makeText(this, "Erro no cancelamento: ${exception?.message}", Toast.LENGTH_LONG).show()
        },
        onEnd = {
            Toast.makeText(this, "Processo finalizado", Toast.LENGTH_SHORT).show()
        }
    )
}

// Exemplo de como chamar o método (usuário deve fornecer o paymentTransaction)
fun onCancelarTransacaoClick(transacaoSelecionada: PaymentTransaction) {
    iniciarCancelamento(transacaoSelecionada)
}
```

**Exemplo INCORRETO** (paymentTransaction criado dentro do método):
```kotlin
// ❌ INCORRETO - paymentTransaction não pode ser criado dentro do método
private fun iniciarCancelamento() {
    val paymentTransaction = PaymentTransaction(...) // ERRADO!
    val tapOnPhoneSdk = TapOnPhone.getInstance()
    tapOnPhoneSdk.initCancelation(
        context = this,
        config = config,
        paymentTransaction = paymentTransaction,
        // ...
    )
}
```

**Exemplo CORRETO** (paymentTransaction recebido via parâmetro):
```kotlin
// ✅ CORRETO - paymentTransaction recebido via parâmetro
private fun iniciarCancelamento(paymentTransaction: PaymentTransaction) {
    val tapOnPhoneSdk = TapOnPhone.getInstance()
    tapOnPhoneSdk.initCancelation(
        context = this,
        config = config,
        paymentTransaction = paymentTransaction,
        // ...
    )
}
```

### 3. Warmup (OBRIGATÓRIO)
Como referência ao manual de integracao, esse método deve ser usado em um momento anterior ao initializer. Ou seja, deve ser usado no onCreate da  activity principal, ou incluíndo na classe que foi referênciada no name do AndroidManifest.xml

### 4. Implementação (OBRIGATÓRIO)
- Ao realizar a conclusão da implementação, o agente deve executar uma scronização do gradle, e um build, a fim de, verificar se o projeto está executando perfeitamente. Caso ocorra um erro em algumas dessa etapas, o agente deve realizar a correção e executar os passo descritos no item 3.
- O código deve está funcional, ou seja, sem comentários (// /**/)
- O código deve está coberto por teste unitário
- A implementacao de deve seguir as regras de código limpo

#### 4.1 Princípio de Interface Segregation (OBRIGATÓRIO)

A implementação **DEVE** seguir o **Interface Segregation Principle (ISP)** conforme as boas práticas de código limpo e SOLID:

- **Criar uma interface específica**: Defina uma interface clara que represente o contrato necessário para a implementação (ex: `PaymentProcessor`, `TransactionHandler`, etc.).
- **Implementar a interface em uma classe concreta**: Crie uma classe que implemente essa interface, contendo a lógica específica necessária (ex: `TapPaymentProcessor implements PaymentProcessor`).
- **Usar injeção de dependência**: Em vez de instanciar diretamente a classe concreta, use **outra classe (Factory ou Constructor Injection)** para gerenciar a criação e injeção da instância.
- **Separação física obrigatória em arquivos**: Interface, implementação concreta e factory/injeção **DEVEM** estar em **arquivos separados** dentro de **um mesmo pacote** (ex: `payment/PaymentProcessor.kt`, `payment/TapPaymentProcessor.kt`, `payment/PaymentProcessorFactory.kt`).
- **Proibição**: Não é permitido declarar interface + implementação + factory no mesmo arquivo quando esse item 4.1 for aplicado.

**Benefícios:**
- Permite trocar implementações sem alterar o cliente
- Facilita testes unitários através de mocks/stubs
- Segue o princípio SOLID de segregação de interface
- Desacopla a lógica de negócio da criação de instâncias

**Exemplo (arquivos separados no mesmo pacote):**

`payment/PaymentProcessor.kt`
```kotlin
interface PaymentProcessor {
    fun processPayment(amount: BigDecimal): Boolean
    fun getTransactionStatus(): TransactionStatus
}
```

`payment/TapPaymentProcessor.kt`
```kotlin
class TapPaymentProcessor : PaymentProcessor {
    override fun processPayment(amount: BigDecimal): Boolean {
        // Lógica específica do TAP
        return true
    }
    
    override fun getTransactionStatus(): TransactionStatus {
        // Retorna status da transação
        return TransactionStatus.SUCCESS
    }
}
```

`payment/PaymentProcessorFactory.kt`
```kotlin
class PaymentProcessorFactory {
    fun createProcessor(): PaymentProcessor {
        return TapPaymentProcessor()
    }
}
```

`payment/PaymentActivity.kt`
```kotlin
class PaymentActivity : AppCompatActivity() {
    private val processor: PaymentProcessor = PaymentProcessorFactory().createProcessor()
    
    fun executePayment(amount: BigDecimal) {
        processor.processPayment(amount)
    }
}
```
