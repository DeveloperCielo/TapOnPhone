# Release Notes — SDK Cielo TAP Android

# Release Notes SDK Cielo TAP Android


O documento abaixo tem o objetivo de detalhar as modificações realizadas nas versões do SDK Cielo TAP.

| ****Legenda**** 
| ****Descrição**** 
|


| n/m 
| Não mudou 
|


| n/c 
| Não criado 
|


| p/o 
| Pacote oficial (todos os pacotes foram enviados para parceiros) 
|

---

# p/o - 1.8.0 - 31/07/2026

### Descrição:
Atualizada a biblioteca de observabilidade, incorporando melhorias de monitoramento, logging e telemetria para aumentar a visibilidade e facilitar o diagnóstico de problemas.

Versão das dependências:
Tap on phone: 1.8.0

Symbiotic: 2.3.1

AllowMe: 3.7.4

# p/o - 1.7.2 - 17/07/2026

### Descrição:
Inclusão do modo paisagem para tablet.

Versão das dependências:
Tap on phone: 1.7.2

Symbiotic: 2.4.1-preview.90cd4c1

AllowMe: 3.7.4

# p/o - 1.6.15 - 10/07/2026

### Descrição:
Inclusão de suporte ao envio opcional de merchantOrderId no método initPayment.

Quando informado, o campo merchantOrderId deve conter apenas caracteres numéricos e possuir entre 1 e 15 dígitos, e não pode ser duplicado. Essa informação é de total responsabilidade do integrador e sua duplicação pode gerar problemas no desfazimento de transações.

Caso enviado um valor no formato inválido, o SDK retornará a exceção InvalidMerchantOrderIdException por meio do callback onPaymentFailure. Consulte a seção "Tratamento de Erros" do manual de integração para mais informações sobre o retorno e tratamento dessa exceção.

Novo método isUserActive

Adicionada funcionalidade para verificar se um usuário está ativo com base na data da última transação, retornando um valor booleano conforme a regra de até 30 dias de atividade. Para detalhes sobre implementação, parâmetros, retorno e exemplos de uso, consulte o Manual de Integração.

Lista de produtos dinâmica.

Evolução da lista de produtos do SDK para refletir de forma dinâmica as opções de pagamento habilitadas para cada cadastro, incluindo crédito, débito e crédito parcelado.

Versão das dependências:
Tap on phone: 1.6.15

Symbiotic: 2.3.1

AllowMe: 3.7.4

# p/o - 1.6.7 - 11/05/2026

### Descrição:
Atualizações de segurança.

AllowMe: atualizado para versão 3.7.4

Aplicadas atualizações e correções para fortalecer a segurança.

Versão das dependências:
Tap on phone: 1.6.7

Symbiotic: 2.3.0.21

AllowMe: 3.7.4

Versão app demo cielo: 9.0.0


# p/o - 1.6.2 - 13/03/2026


### Descrição:

- Atualizações de Branding.

- Atualização do branding Elo com nova animação e imagem da bandeira.

- Ajuste de layout no Android 16.

- Correção no desalinhamento de componentes quando a barra de navegação estiver configurada com botões.

- Atualizações de Segurança e Dependências.

- Foram atualizadas bibliotecas de terceiros para versões mais seguras após alertas identificados pela ferramenta de análise de dependências. A relação completa das bibliotecas e respectivas versões está disponível no documento “Atualização de Dependências”, fornecido junto aos artefatos.

- **Dispositivos com Android 10 (API 29) deixam de ser suportados**; o mínimo agora é **Android 11 (API 30)**.

### Versão das dependências:

- Tap on phone: 1.6.2


- Symbiotic: 2.3.0.21


- AllowMe: 3.6.2


- Versão app demo cielo: 7.0.4

---


# p/o - 1.5.6 - 08/01/2026


### Descrição:

- Atualizações de segurança;

- AllowMe: atualizado para versão 3.6.2.

- Suporte ao CNPJ Alfanumérico com remoção da sanitização de documentos enviados ao SDK.

- A lógica anterior que removia automaticamente a máscara dos documentos foi descontinuada, essa alteração foi necessária para adequar o sistema ao novo formato de CNPJ Alfanumérico, que será implementado a partir do próximo ano conforme nova regulamentação da Receita Federal.


- **Importante!** A partir dessa versão **não é mais realizada a remoção automática da máscara dos documentos enviados**, portanto o integrador deve garantir que o valor enviado esteja totalmente sanitizado, **contento apenas letras e números**. Consulte nosso manual de integração para mais detalhes.

### Versão das dependências:

- Tap on phone: 1.5.6


- Symbiotic: Todas as dependencias de adotam o prefixo "top”


- AllowMe: 3.6.2


- Versão app demo cielo: 5.0.7/5.0.8/5.0.9

---


# p/o - 1.5.4 - 17/10/2025


### Descrição:

- Correções e melhorias de layout relacionadas à Safe Area e animações de teclado:

- Correção no componente de Safe Area: Ajuste na lógica de tratamento de *WindowInsets* para garantir que o conteúdo da tela respeite corretamente as áreas seguras, especialmente em dispositivos com navegação por gestos ou barras virtuais.


- Inclusão da Status Bar em telas específicas: As telas de Animação de bandeira, Feedback e Comprovante agora consideram a altura da *Status Bar*, evitando sobreposição de conteúdo e melhorando a legibilidade.


- Ajuste dinâmico de padding inferior: Implementação de animações suaves durante a exibição do teclado virtual (IME), garantindo que o conteúdo se reposicione corretamente sem cortes ou sobreposição.


- Melhoria na experiência de entrada de dados: O layout agora se adapta de forma mais fluida à presença do teclado e da barra de navegação, proporcionando uma experiência mais consistente e responsiva.

- Melhoria na validação e sanitização de valores numéricos inseridos pelo usuário.

- Foi adicionada uma lógica robusta para tratar e validar o valor inserido no campo de texto antes de sua conversão para `BigDecimal`. A nova implementação:

- Remove separadores de milhar e converte vírgulas decimais para ponto.


- Elimina caracteres não numéricos.


- Detecta e corrige casos com múltimos pontos decimais, garantindo que o valor final tenha apenas duas casas decimais.


- Garante maior resiliência contra erros de formatação e melhora a experiência do usuário ao lidar com valores monetários.


Essa melhoria reduz falhas de conversão e evita erros inesperados durante o processamento de valores.

### Versão das dependências:

- Tap on phone: 1.5.4


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 5.0.4

# p/o - 1.4.4 - 04/09/2025


### Descrição:

- Compatibilidade com páginas de memória de 16KB.

- Adicionada compatibilidade com páginas de memória de 16KB, conforme práticas recomendadas do Google, visando melhor desempenho e conformidade com dispositivos modernos.

- Atualização do ambiente de build.

- Gradle: versão 8.7.


- Android Gradle Plugin (AGP): versão 8.5.1.


- JDK: versão 17.

- Atualização de dependências.

- As dependências abaixo foram atualizadas e devem ser atualizadas nos aplicativos de parceiros também:

```kotlin
implementation 'androidx.camera:camera-camera2:1.4.0'
implementation 'androidx.camera:camera-lifecycle:1.4.0'
implementation 'androidx.camera:camera-view:1.4.0'
implementation 'com.google.mlkit:face-detection:16.1.7'
implementation 'com.scottyab:rootbeer-lib:0.1.1'
```

- Atualizações de segurança e otimização.

- AllowMe: atualizado para versão 3.4.13.


- DexGuard: atualizado para versão 9.12.0.


- Proguard segmentado no zip da versão.

### Versão das dependências:

- Tap on phone: 1.4.4


- Symbiotic: 1.7.14


- AllowMe: 3.4.13


- Versão app demo cielo: 5.0.1/5.0.1.1

---


# p/o - 1.3.16 - 13/08/2025


### Descrição:

- Novo método showEducationScreen.

- Implementado novo método para exibição da telas educacionais para TapOnPhone, apresentando conteúdos informativos sobre utilização do produto.

- Evolução no retorno das mensagens de erro recebidas na inicialização.

- Evolução na forma como as mensagens de erro são retornadas durante o processo de inicialização, proporcionando diagnósticos mais claros e precisos.

- Aprimoramentos de White Label.

- Ajustes e melhorias na estrutura de White Label, visando maior personalização e adaptação às necessidades de diferentes clientes/parceiros.

### Versão das dependências:

- Tap on phone: 1.3.16


- Symbiotic: 1.7.13


- AllowMe: n/m


- Versão app demo cielo: n/m

---


# p/o - 1.3.1.1 - 23/07/2025


### Descrição:

- Ajustes para Android 15 (API 35).

- Realizados ajustes para compatibilidade com dispositivos Android 15, que passaram a adotar o padrão de telas edge-to-edge. As mudanças garantem melhor aproveitamento da área útil da tela e uma experiência visual mais imersiva, conforme diretrizes do Google.

### Versão das dependências:

- Tap on phone: 1.3.1.1


- Symbiotic: 1.7.10


- AllowMe: n/m


- Versão app demo cielo: n/m

---


# p/o - 1.3.6 - 15/05/2025


### Descrição:

- Melhorias e correções no pagamento.

- Ajuste no tratamento de erros e otimizações significativas que aumentam a velocidade de leitura durante o processo de pagamento, proporcionando uma experiência mais ágil e eficiente.

### Versão das dependências:

- Tap on phone: 1.3.6


- Symbiotic: 1.7.11


- AllowMe: n/m


- Versão app demo cielo: 4.23.0

---


# p/o - 1.3.1 - 08/04/2025


### Descrição:

- Correção na tela de inserir valor.

- Resolvido o problema de crash ao manter pressionado o botão apagar na tela de inserir valor.

- Melhorias nos testes unitários.

- Expansão da cobertura de testes com inclusão de novos cenários, aumentando a confiabilidade e estabilidade da aplicação.


- Adicionado validação de versão Android, para garantir compatibilidade e comportamento adequado em diferentes versões do sistema.

### Versão das dependências:

- Tap on phone: 1.3.1


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.21.0

---


# 1.3.0 - 27/03/2025


### Descrição:

- Remoção de Trace e RUM (Real User Monitoring) com datadog.

- As funcionalidades de monitoramento Trace e Real User Monitoring (RUM) foram removidas da integração com Datadog pois já está sendo usado Dynatrace, mas mantendo os logs ainda integrados ao Datadog.

### Versão das dependências:

- Tap on phone: 1.3.0


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.20.0

---


# 1.2.55 - 07/03/2025


### Descrição:

- Integração com Dynatrace, para utilização de trace e RUM (Real User Monitoring).

- As funcionalidades de monitoramento Trace e Real User Monitoring (RUM) foram integradas com Dynatrace, ampliando a capacidade de observabilidade e análise de desempenho da aplicação.

- Período de transição com Datadog.

- Durante esta fase, as funcionalidades de Trace e RUM permanecem ativas também via Datadog, visando garantir estabilidade. A remoção dessas funcionalidades do Datadog está planejada para uma versão futura.

### Versão das dependências:

- Tap on phone: 1.2.55


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: n/c

---


# p/o - 1.2.54 - 14/02/2025


### Descrição:

- Correção na tela de carregamento.

- Resolvido o problema de exibição do loading quando o White Label está sendo utilizado, garantindo uma experiência visual mais consistente e alinhada com o comportamento esperado.

### Versão das dependências:

- Tap on phone: 1.2.54


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.19.0

---


# 1.2.53 - 12/02/2025


### Descrição:

- Atualização no comportamento de tela após retorno do detalhe da transação.

- Implementado refresh na lista de transações quando o usuário retorna da visualização dos detalhes de uma transação, garantindo que as informações exibidas estejam sempre atualizadas.

### Versão das dependências:

- Tap on phone: 1.2.53


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.18.0

---


# 1.2.52 - 10/02/2025


### Descrição:

- Melhorias de observabilidade.

- Removido tracer do datadog e adicionado instance name.

### Versão das dependências:

- Tap on phone: 1.2.52


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.17.0

---


# 1.2.51 - 05/02/2025


### Descrição:

- Melhoria no comportamento do carregamento padrão.

- Ajustes realizados no loading default, aprimorando a experiência visual durante a exibição do indicador de progresso.

### Versão das dependências:

- Tap on phone: 1.2.51


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.16.0

---


# 1.2.50 - 27/01/2025


### Descrição:

- Unificação de pacotes.

- Consolidado o código dos pacotes TapOnPhone, Commons e Flui em um único módulo, proporcionando melhor organização, manutenção e reutilização de componentes. Essa mudança também visa oferecer uma experiência mais simplificada e eficiente para os integradores da solução.

- Restrição ao botão voltar na tela de comprovante.

- Aplicada regra para impedir o funcionamento do botão voltar na tela de comprovante, garantindo a integridade do fluxo de pagamento e evitando comportamentos indesejados após a finalização da transação.

### Versão das dependências:

- Tap on phone: 1.2.50


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.15.0

---


# p/o - 1.2.49 - 09/12/2024


### Descrição:

- Melhoria de logs.

- Ajustado o tratamento de logs para evitar que cenários de cancelamento e transação expirada sejam registrados como erro, proporcionando maior precisão na análise de eventos.


- Melhorias nos logs transacionais com adição de novas informações para o time de monitoramento.


- Adicionado os campos bundle ID e sistema operacional (SO) em todos os logs enviados ao Datadog, aumentando a rastreabilidade e contexto das informações.

- Mudança de tratamento de certificados.

- Atualização na lógica de validação e uso de certificados, visando maior segurança e conformidade.

- Nova base URL.

- Alterada a base URL utilizada na comunicação com os serviços, refletindo ajustes de infraestrutura e ambiente.

- Refatoração da classe TapOnPhone.

- Melhorias estruturais na classe, com foco em organização, legibilidade e manutenção do código.

- Correção na tela de carregamento ao buscar detalhes da transação.

- Corrigido o comportamento da tela de loading, garantindo seu fechamento adequado após a busca pelos detalhes da transação.

- Ajustes na funcionalidade White Label.

- Adicionada a chave paymentFeedback para as telas de pagamento expirado e cancelado.


- Adicionado White Label no botão fechar a tela de comprovante.


- Corrigida a aplicação da chave message_error com suporte ao White Label.

- Remoção da dependência SafetyNet.

- Eliminada a dependência SafetyNet, simplificando a estrutura e reduzindo acoplamento com serviços externos.

### Versão das dependências:

- Tap on phone: 1.2.49


- Flui: 1.2.18


- Commons: 1.2.22


- Symbiotic: 1.7.9


- AllowMe: n/m


- Versão app demo cielo: 4.14.0

---


# p/o -1.2.35.1 - 11/10/2024


### Descrição:

- Permitir Android 10, versão 29 da API.

- Funcionamento adequado da aplicação em dispositivos com Android 10.

### Versão das dependências:

- Tap on phone: 1.2.35.1


- Flui: n/m


- Commons: n/m


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.10.0

---


# p/o -1.2.35 - 13/09/2024


### Descrição:

- Padronização de nomenclatura de arquivos XML.

- Alterados os nomes dos arquivos XML para garantir maior consistência e organização no projeto.

- Ajustes funcionais.

- Removido campo previsão de pagamento da tela detalhe da venda.

### Versão das dependências:

- Tap on phone: 1.2.35


- Flui: 1.2.15


- Commons: 1.2.11


- Symbiotic: n/m


- AllowMe: n/m


- Versão app demo cielo: 4.9.9

---


# p/o - 1.2.34 - 05/09/2024


### Descrição:

- Correções e melhorias gerais.

- Ajustado o cálculo de divisão no parcelamento, garantindo maior precisão nos valores apresentados.


- Adicionado efeito shimmer durante a consulta aos detalhes da venda, melhorando a percepção de carregamento e fluidez da interface.


- Comprovante de cancelamento agora inclui também a data de cancelamento, oferecendo mais transparência nas informações exibidas.


- Corrigido o comportamento após o clique em nova venda para garantir seu fechamento adequado.


- Adicionado bloqueio à tela de carregamento default para impedir seu fechamento indevido, garantindo estabilidade no fluxo de loading.

### Versão das dependências:

- Tap on phone: 1.2.34


- Flui: 1.2.13


- Commons: 1.2.9


- Symbiotic: n/m


- AllowMe: 3.0.2.3


- Versão app demo cielo: 4.9.8

---


# 1.2.33 - 04/09/2024


### Descrição:

- Correções e melhorias gerais.

- Ajuste no fluxo de pagamento relacionado ao callback do botão Nova venda, garantindo o comportamento esperado após a finalização de uma transação.


- Padronização da nomenclatura dos ícones utilizados na aplicação.


- Atualização do texto do botão "Tentar novamente" para "Fechar" nas telas de erro, alinhando a ação ao contexto apresentado.

### Versão das dependências:

- Tap on phone: 1.2.33


- Flui: 1.2.12


- Commons: 1.2.9


- Symbiotic: n/m


- AllowMe: 3.0.2.3


- Versão app demo cielo: 4.9.6

---


# 1.2.30 - 30/08/2024


### Descrição:

- Correção no horário exibido no comprovante.

- Ajustado o cálculo da data/hora apresentada no comprovante, que anteriormente exibia um valor com defasagem de -3 horas. Agora, o horário reflete corretamente o momento da transação.

- Melhoria na exibição de data no comprovante de transações canceladas.

- Atualizada a lógica de exibição da data no comprovante de cancelamento. Passa a ser exibida a data do cancelamento, em vez da data original da transação, promovendo maior clareza e precisão nas informações apresentadas ao usuário.

### Versão das dependências:

- Tap on phone: 1.2.30


- Flui: 1.2.10


- Commons: 1.2.8


- Symbiotic: n/m


- AllowMe: 3.0.2.3


- Versão app demo cielo: 4.9.7

---


# p/o - 1.2.27 - 16/08/2024


### Descrição:

- Melhorias e ajustes na funcionalidade White Label.

- Implementadas configurações de White Label na tela de comprovante, permitindo maior personalização visual conforme identidade dos parceiros.


- Adicionada também configuração de White Label na status bar, garantindo consistência visual em toda a interface.


- Evoluções na estrutura de White Label para ampliar flexibilidade e facilitar futuras customizações.


- Realizado implementações de ajustes específicos para White Label na tela de pagamento.

- Melhoria na usabilidade do botão de ajuda.

- Ajustado o comportamento do botão de help na tela de seleção de tipo de pagamento, proporcionando melhor experiência ao usuário.

- Refatoração técnica para testes unitários.

- Melhorias no código com foco em modularidade e testabilidade, visando ampliar a cobertura e confiabilidade dos testes unitários.

### Versão das dependências:

- Tap on phone: 1.2.27


- Flui: 1.2.10


- Commons: 1.2.8


- Symbiotic: n/m


- AllowMe: 3.0.2.3


- Versão app demo cielo: 4.9.5

---


# p/o - 1.2.24 - 06/08/2024


### Descrição:

- Refatoração na lógica de compartilhamento do comprovante.

- Removido o uso do FileProvider no processo de compartilhamento do comprovante, simplificando a implementação.

### Versão das dependências:

- Tap on phone: 1.2.24


- Flui: 1.2.8


- Commons: 1.2.6


- Symbiotic: n/m


- AllowMe: 3.0.2.3


- Versão app demo cielo: 4.9.4

---


# p/o - 1.2.20 - 31/07/2024


### Descrição:

- Ajuste na formatação de valores.

- Corrigida a formatação do valor exibido na tela de seleção de tipo de pagamento, garantindo consistência visual e melhor legibilidade para o usuário.

- Melhoria na exibição de mensagens de erro.

- Ajustado o layout da tela de erro para evitar indentação indevida na mensagem retornada pelo autorizador, promovendo uma apresentação mais limpa e precisa das informações.

### Versão das dependências:

- Tap on phone: 1.2.20


- Flui: 1.2.7


- Commons: 1.2.6


- Symbiotic: n/m


- AllowMe: 3.0.2.3


- Versão app demo cielo: 4.9.3
