# Manual de Integração — SDK Cielo TAP PIX (Android)

Manual de integração PIX (Android)

# Manual de integração PIX (Android)

**Documentação do SDK – PIX**

Este guia irá orientá-lo através dos requisitos do SDK, como inicializar a biblioteca, as diferentes jornadas disponíveis, como usar o white label e como realizar transações pix.

**Requisitos do SDK**

| **Android**
|

| Versão mínima do SDK: Android 11 (API 30)
|

| Versão do SDK recomendada: Android 11 (API 30)
|

| Acesso à internet
|

| NFC no Dispositivo
|

**Requisitos do Sistema**

| **Windows**
|

| Android Studio recomendado: Android Studio Giraffe | 2022.3.1 Patch 1
|

**Adicionando o SDK ao seu projeto**

Criar uma pasta no projeto de nome libs, no mesmo nível do src:

*{SEU_DIRETÓRIO}\app\libs*

Ficando da seguinte forma:

![image-20240220-165810.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20240220-165810.png?version=1&modificationDate=1773068350738&cacheVersion=1&api=v2)

Copiar os arquivos enviados para a pasta criada​.

Abrir o arquivo build.gradle da aplicação, normalmente dentro da pasta app​.

Na seção de dependências do seu projeto adicionar:

*IMPORTANTE: o nome específico da dependência e sua respectiva versão é conforme o pacote atual disponibilizado.*

```kotlin
implementation(files("$projectDir/libs/allowme.aar"))
implementation(files("$projectDir/libs/taponphone.aar"))
implementation(files("$projectDir/libs/top-sdk.aar"))
implementation(files("$projectDir/libs/top-sdk-2-core-2.0.3.jar
implementation(files("$projectDir/libs/top-sdk-3-branding-1.0.6.aar"))
implementation(files("$projectDir/libs/top-sdk-3-core-2.0.aar"))
implementation(files("$projectDir/libs/top-sdk-4-core-1.0.18.aar"))
implementation(files("$projectDir/libs/top-sdk-reader-utils.aar"))
implementation(files("$projectDir/libs/top-sdk-utils.aar"))
```

ou (recomendamos adicionar a linha abaixo, como primeira dependência):​

| **Goovy**
| **Kotlin**
|

| ```kotlin
implementation fileTree(dir: "libs", include: ["*.jar", "*.aar"])​
```
| ```kotlin
implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
```
|

Extraia o arquivo abaixo na raiz do projeto

**<SENSEDIA ANEXE O ARQUIVO ZIP ARTEFACTS AQUI>**

Adicionar a seguinte instrução no seu **settings.gradle**:

| **Groovy**
| **Kotlin**
|

| ```kotlin
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    buildscript {
        repositories {
            mavenCentral()
            maven {
                url = uri("https://storage.googleapis.com/r8-releases/raw")
            }
        }
        dependencies {
            classpath("com.android.tools:r8:8.3.37")
            classpath("com.dynatrace.tools.android:gradle-plugin:8.279.1.1002")
        }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        mavenLocal() {
            url uri("${rootDir}/artefacts")
        }
        flatDir {
            dirs 'libs'
        }
    }
}
```
| ```kotlin
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
    buildscript {
        repositories {
            mavenCentral()
            maven {
                url = uri("https://storage.googleapis.com/r8-releases/raw")
            }
        }
        dependencies {
            classpath("com.android.tools:r8:8.3.37")
            classpath("com.dynatrace.tools.android:gradle-plugin:8.279.1.1002")
        }
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        mavenLocal {
            setUrl("${rootDir}/artefacts")
        }
        flatDir {
            dirs("libs")
        }
    }
}
```
|

Abrir o arquivo **build.gradle** da aplicação, normalmente dentro da pasta app​, na seção dependencies adicionar:​

| **Kotlin**
|

| ```kotlin
dependencies {
    implementation fileTree(include: ['*.aar', '*.jar'], dir: 'libs')
    //navite dependencies
    implementation 'androidx.core:core-ktx:1.9.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    //security module dependencies
    implementation 'com.squareup.okhttp3:okhttp:4.11.0'
    implementation 'com.squareup.okhttp3:logging-interceptor:4.11.0'
    implementation 'androidx.camera:camera-camera2:1.4.0'
    implementation 'androidx.camera:camera-lifecycle:1.4.0'
    implementation 'androidx.camera:camera-view:1.4.0'
    implementation 'com.google.mlkit:face-detection:16.1.7'
    implementation 'com.scottyab:rootbeer-lib:0.1.1'
    implementation 'com.google.android.gms:play-services-ads-identifier:18.0.1'
    implementation 'com.google.android.gms:play-services-appset:16.0.2'
    implementation 'com.google.android.gms:play-services-tasks:18.0.2'
    //payment module dependencies
    implementation 'com.google.android.play:integrity:1.2.0'
    implementation 'com.madgag.spongycastle:core:1.58.0.0'
    implementation 'com.madgag.spongycastle:prov:1.58.0.0'
    implementation group: 'org.bouncycastle', name: 'bcprov-jdk18on', version: '1.73'
    implementation "io.reactivex.rxjava2:rxjava:2.2.6"
    implementation "io.reactivex.rxjava2:rxandroid:2.1.1"
    implementation "com.airbnb.android:lottie:6.1.0"
    implementation 'com.android.volley:volley:1.2.1'
    implementation 'net.danlew:android.joda:2.9.9.4'
    implementation 'com.google.guava:guava:31.1-jre'
    implementation 'androidx.databinding:viewbinding:7.1.2'
    implementation 'com.facebook.shimmer:shimmer:0.5.0'
    implementation 'com.discover.sdk:core:COR1.1.4-releaseCandidate'
    implementation 'com.discover.sdk:card-reader:TOOK2.3.2-releaseCandidate'
    implementation 'com.squareup.retrofit2:retrofit:2.9.0'
    implementation 'com.squareup.retrofit2:converter-gson:2.9.0'
    def room_version = "2.5.2"
    implementation "androidx.room:room-runtime:$room_version"
    implementation("androidx.room:room-ktx:$room_version")
    annotationProcessor "androidx.room:room-compiler:$room_version"
    kapt "androidx.room:room-compiler:$room_version"
    testImplementation "androidx.room:room-testing:$room_version"
    api 'io.jsonwebtoken:jjwt-api:0.11.2'
    api(group: "androidx.work", name: "work-runtime") {
        version {
            strictly "2.8.1"
        }
    }
    api(group: "androidx.work", name: "work-runtime-ktx") {
        version {
            strictly "2.8.1"
        }
    }
    runtimeOnly group: 'io.jsonwebtoken', name: 'jjwt-jackson', version: '0.11.2'
    runtimeOnly 'io.jsonwebtoken:jjwt-impl:0.11.2'
    runtimeOnly('io.jsonwebtoken:jjwt-orgjson:0.11.2') {
        exclude group: 'org.json', module: 'json'
    }
    //log module dependencies
    implementation "com.datadoghq:dd-sdk-android-logs:2.11.0"
    implementation "com.datadoghq:dd-sdk-android-okhttp:2.11.0"
    implementation 'com.dynatrace.agent:agent-android:8.279.1.1002'
    //dependencies for the operation of test classes
    testImplementation 'junit:junit:4.13.2'
    androidTestImplementation 'androidx.test.ext:junit:1.1.5'
    androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'
    //Optional - According to the configuration of each project, this dependency may be necessary
    implementation 'androidx.security:security-crypto:1.1.0-alpha03'

    implementation 'com.google.zxing:core:3.5.2'
}

```
|

Outra dependência mandatória para o funcionamento do SDK é AndroidX (Documentação android sobre o assunto:[https://developer.android.com/jetpack/androidx?hl=pt-br](https://developer.android.com/jetpack/androidx?hl=pt-br) ), sendo assim adicione a linha abaixo no seu gradle.properties:

```kotlin
android.enableJetifier=true
```



# Regras de exceção do Proguard

Para gerar artefatos ofuscados é necessário a implementação do proguard no projeto. Isso pode ser feito através da adição das seguintes linhas no arquivo build.gradle:

```kotlin
buildTypes {
    debug {
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        signingConfig signingConfigs.debug
    }
}
```

Também é necessário adicionar as regras de exceção no arquivo [proguard-rules.pro](http://proguard-rules.pro/), uma vez que após a ofuscação o nome de métodos e classes necessários para o funcionamento do sdk são alterados. As regras de exceção são adicionadas como uma forma de previnir que esses métodos e classes tenham a sua referência no código ofuscada e causem erros na execução do sdk.

Verifique o arquivo de regras dentro do zip da versão corrente.

# Aviso ao desenvolvedor

Quanto ao processo de integração, avisamos que a primeira tentativa transacional _**não irá funcionar. **_Existe um bloqueio por parte da Cielo para novos integradores, esse bloqueio avalia a chave _kestore _(debug e release) do aplicativo corrente. A primeira tentativa haverá pela parte do sdk um registro de acesso, o que entenderemos como fraude, o parceiro integrador deve entrar em contato conosco informando o problema através do seguinte e-mail: [posvirtual_mobile@cielo.com.br](mailto:posvirtual_mobile@cielo.com.br). Após nós desbloquearmos irá funcionar o transacional para o aplicativo do parceiro.

Durante o processo de credenciamento certamente será solicitado pela Cielo um bundle id, em projetos de teste geralmente por padrão são _com.example.myapplication, _nosso produto faz a leitura do pacote e exige que o pacote seja o mesmo informado no credenciamento.

# Plugins obrigatórios

Dentro do seu módulo de app, caso não exista a cláusula plugins, crie da seguinte forma e importe os novos plugins (o formato correto pode variar de acordo com a configuração do seu projeto):

```kotlin
plugins {
    id 'com.android.application' (Já deve existir, nativamente, para modulo de app)
    id 'org.jetbrains.kotlin.android' (Novos)
    id 'kotlin-kapt' (Novos)
}
```

# Inicialização

O processo de inicialização pode ser feito dentro da Activity que precede o pagamento ou dentro da Application.  ​

IMPORTANTE: Garanta na sua implementação que os outros métodos do SDK apenas sejam chamados após o retorno do callback.onInitializeSuccess

Exemplo de inicialização:​

```kotlin
val config = ConfigBuilder(context = this)
  .initClient("[CLIEND ID]", "[CLIENT SECRET]")
  .setCNPJ("[CNPJ do contratante]")
  .loadWhiteLabel("wl_custom.json")

val pix = Pix.getInstance()

pix.initialize(
  configuration = InitializePixConfig(
    this,
    config,
    useDefaultLoading = true
  ),
  callback = InitializePixCallback(
    onInitializeStart = {}
    onInitializeSuccess = {}
    onInitializeFailure = {}
  )
)
```

Detalhes dos métodos e respectivos campos:

.**initClient**​

**client id**: id único por cliente disponibilizado pela Cielo na aquisição.​

**client secret**: secret do cliente informado pela Cielo na aquisição.​

**.setCPF ou .setCNPJ​**

**document**: número de documento do contratante seja, CPF ou CNPJ (chamar apenas um dos dois).

O integrador deve garantir que o valor enviado esteja **totalmente sanitizado**, contento **apenas letras e números**, sem pontos, barras, traços ou qualquer outro caractere especial.

Essa alteração é resultado da adequação ao suporte para CNPJs alfanuméricos, que será implementado a partir do próximo ano conforme nova regulamentação da Receita Federal.

​.**loadWhiteLabel**​

filename: nome do arquivo de WhiteLabel com as customizações.​

## **Método Inicialize **

Método responsável por inicializar o SDK e carregar dados iniciais do usuário como chaves de inicialização, executar diversos procedimento de segurança, e validação de parceiro.

Para iniciar o método Initialize, basta seguir o exemplo abaixo:

```kotlin
val pixSdk = Pix.getInstance()
pixSdk.initialize(
  configuration = InitializePixConfig(
    context = this,
    config,
    onLogs = {typeLog, message -> },
    useDefaultLoading = true,
    useFeedbackScreen = true,
  ),
  callback = InitializePixCallback(
    onInitializeStart = {},
    onInitializeSuccess = {},
    onInitializeFailure = {exception -> },
  )
)
```

**Descrição dos parâmetros:**

Objeto **InitializePixConfig**- **context: **context da aplicação​.

-
**config: **Descriminado na inicialização.

-
**onLogs(type: **[**TypeLog**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3446113359/Android+Itens+para+a+nova+vers+o#Enum-do-tipo-de-log%3A)**, message: String)**: Com esse método você pode obter os logs do sdk.
**Observação**: Neste evento retorna os logs de todo o SDK, inclusive logs das demais funções (InitJorney e InitPayment).

Os tipos de logs que temos é:

-
[**TypeLog.INFO**](http://TypeLog.INFO)**: **Log com tipo informação;

-
**TypeLog.WARNING: **Log com tipo aviso;

-
**TypeLog.ERROR: **Log com tipo error;

-
**useDefaultLoading: **Define se uma tela de loading padrão será exibida durante o processo de inicialização. Por padrão, este campo é definido como `true`, o que significa que tanto a tela de carregamento quanto a tela de feedback de erro serão exibidas automaticamente, caso necessário. Se definido como false, a aplicação deverá gerenciar manualmente a exibição de loading e tratamento de alguns erros, assumindo total controle da experiência visual durante a inicialização.

-
**useFeedbackScreen**: Define se a tela de feedback de erro será exibida automaticamente em caso de falha. Por padrão, `true`.

Objeto **InitializePixCallback**- **onInitializeStart: **callback chamado no momento em que o processo de inicialização se inicia​.

-
**onInitializeSuccess: **método chamado quando o processo de inicialização ocorre com sucesso​.

-
**onInitializeFailure(Exception): **método chamado quando ocorre alguma falha no processo de inicialização​.

## **Método initPayment****Responsável por inicializar o fluxo de pagamento PIX**, validando o estado do SDK, prevenindo execuções concorrentes duplicadas, registrando telemetria, disparando callbacks de ciclo de vida e, em caso de sucesso, iniciando a `SDKPixPaymentActivity` para continuidade do pagamento.**Pré-requisitos**

-
O SDK **deve estar inicializado** com sucesso via `initialize(...)`.

-
O valor inicial (`initialValue`) deve ser **informado e válido** (por exemplo, maior que zero).

-
Recomendado executar em **thread principal** quando houver interação com UI.

**Parâmetros**

Referente a classe InitPaymentPixConfig:

-
**context: **Contexto da aplicação ou componente de UI (Activity/Fragment) a partir do qual o fluxo será iniciado.

-
**configBuilder**: Informado na inicialização.

-
**initialValue**: Valor inicial para o pagamento. Obrigatório e válido (por exemplo, maior que zero). É validado por isValid.

-
**timerToOutScreen: **Valor usado para definir se a tela irá fechar automaticamente.

Referente a classe InitPaymentPixCallback:

-
**onPaymentStart**: Chamado após validação básica mas antes da inicialização central. Útil para preparar UI, bloquear inputs ou iniciar métricas.

-
**onPaymentSuccess**: Chamado quando o pagamento é concluído com sucesso. Entrega o recibo/entidade PixReceiptPayment.

-
**onPaymentFailure**: Chamado em qualquer falha: SDK não inicializado, chamada duplicada, parâmetros inválidos, erros internos da inicialização, etc.

-
**onPaymentCanceled**: Chamado quando o usuário cancela o Pix/QrCode gerado.

Referente a classe InitPaymentPixAction:

-
**onNewSale**: Disparado quando a UI de pagamento inicia uma nova venda.

-
**onEnd**: Disparado quando o fluxo é finalizado pelo usuário (fechamento, conclusão etc.).

Tratamento de erros e exceções

-
IllegalStateException("Pix SDK not initialized successfully"): Quando initialize(...) não foi concluído com sucesso.

-
DuplicateCallException: Quando existe outra execução de initPayment em andamento.

-
InvalidRequiredParamsException("Initial Value is required."): Quando initialValue não atende os critérios mínimos.

Todas as exceções acima são também encaminhadas para onPaymentFailure.

Exemplo de uso

```kotlin
val pixSdk = Pix.getInstance()

pixSdk.initPayment(
    config = InitPaymentPixConfig(
        context = this, // Activity ou Fragment (via requireContext())
        configBuilder = ConfigBuilder(), // Exemplo ilustrativo
        initialValue = BigDecimal("125.90"),
    ),
    callback = InitPaymentPixCallback(
        onPaymentStart = {
            // Ex.: desabilite botões, registre telemetria, exiba loading custom se aplicável
        },
        onPaymentSuccess = { receipt: PixReceiptPayment ->
            // Ex.: atualize estado da venda, registre telemetria
        },
        onPaymentFailure = { exception ->
            // Ex.: atualize estado da venda, registre telemetria
        }
    ),
    action = InitPaymentPixAction(
        onNewSale = {
            // Ex.: atualize de estado da venda, limpar campos,
            // Abrir novo fluxo de venda
        },
        onEnd = {
            // Ex.: fechar a Activity atual, ou navegar para a home/relatório
        }
    )
)
```

## **Método initJourney**Responsável por inicializar a jornada da tela de inserção de valor do PIX, validando o estado do SDK, prevenindo execuções concorrentes duplicadas, registrando telemetria e, em caso de sucesso, iniciando a SDKPixInsertValueActivity para que o usuário informe o valor.**Pré-requisitos**

-
O SDK deve estar **inicializado com sucesso** via `initialize(...)`.

-
Recomendado executar em **thread principal** quando houver interação com UI.

-
Caso a aplicação utilize **loading padrão** do SDK, este método **fecha** o loading pendente ao iniciar a jornada.

**Parâmetros**

Referente à classe InitJourneyPixConfig:

-
**context**: Contexto da aplicação ou componente de UI (Activity/Fragment) a partir do qual a jornada será iniciada.

-
**defaultData**: Valor opcional para pré-preencher o campo de valor na tela.

-
null: o campo é exibido em branco.

-
BigDecimal: o valor informado é aplicado como valor inicial do input.

Referente à classe InitJourneyPixCallback:

-
**error**: Chamado quando ocorre qualquer falha na jornada (ex.: SDK não inicializado, chamada duplicada, validações, eventos internos).

-
**endJourney**: Chamado quando o fluxo é finalizado (com ou sem valor):

-
BigDecimal: valor informado pelo usuário.

-
null: jornada finalizada sem valor (ex.: cancelamento).

-
**buttonHelp**: Chamado quando o usuário solicita ajuda na tela (ex.: tocar no ícone de “Ajuda”). Útil para abrir FAQ, central de ajuda, etc.

Tratamento de erros e exceções

-
IllegalStateException("Pix SDK not initialized successfully"): Quando initialize(...) não foi concluído com sucesso.

-
DuplicateCallException: Quando existe outra execução em andamento.

Todos os erros acima são **encaminhados via** `callback.error`.

Em casos de falha **antes** da abertura da tela (ex.: não inicializado, duplicidade), a jornada é **interrompida** e a Activity **não é iniciada**.

Exemplo de uso

```kotlin
val pixSdk = Pix.getInstance()

pixSdk.initJourney(
    configuration = InitJourneyPixConfig(
        context = this, // Activity ou Fragment (via requireContext())
        defaultData = BigDecimal("50.00") // opcional: pré-preenche o campo de valor
    ),
    callback = InitJourneyPixCallback(
        error = { e ->
            // Ex.: exiba mensagem de erro, reabilite UI, registre telemetria
            // e.printStackTrace()
        },
        endJourney = { result: BigDecimal? ->
            when (result) {
                null -> {
                    // Usuário cancelou ou finalizou sem valor
                    // Ex.: voltar para home, reabilitar botões, etc.
                }
                else -> {
                    // Valor informado com sucesso
                    // Ex.: navegue para o resumo/checkout com 'result'
                }
            }
        },
        buttonHelp = {
            // Ex.: abrir FAQ/central de ajuda
        }
    )
)
```

## Método showAgenda

Responsável por exibir a agenda de vendas PIX (histórico/minhas vendas), validando o estado do SDK, prevenindo execuções concorrentes duplicadas, registrando telemetria com atributos e, em caso de sucesso, iniciando a SDKMySalesPixActivity.

### Pré-requisitos

-
O SDK deve estar **inicializado com sucesso** via `initialize(...)`.

-
Caso exista lógica própria para **cancelamento de transação**, utilize o callback `selectedTransactionToCancellation` (na configuração) para receber a transação selecionada pela UI.

**Parâmetros**

Referente à classe ShowAgendaPixConfig:

-
**context**: Contexto da aplicação ou componente de UI (Activity/Fragment) a partir do qual a agenda será exibida.

-
**config**: Configuração (construtor de configuração) usada pelo fluxo de agenda.

-
**selectedTransactionToCancellation**: Callback opcional para tratar a seleção de uma transação que o usuário deseja cancelar na agenda.

-
Recebe uma PaymentTransaction? (pode ser null se a seleção for anulada).

-
Útil para direcionar o app a uma tela de confirmação de cancelamento, ou iniciar um fluxo de estorno/estorno parcial conforme a regra de negócio.

Referente à classe ShowAgendaPixCallback:

-
**onStartDetailsSale**: Disparado quando a agenda inicia a abertura dos detalhes de uma venda.

-
**onSuccessDetailsSale**: Disparado quando a tela de detalhes de uma venda é carregada com sucesso.

-
**onFailure**: Disparado em qualquer falha no processo (pré‑condições, duplicidade, erros do fluxo).

Observação: Todos os callbacks são opcionais. Sempre invoque defensivamente no código de integração.

Tratamento de erros e exceções

-
IllegalStateException("Pix SDK not initialized successfully"): Quando initialize(...) não foi concluído com sucesso.

-
DuplicateCallException: Quando existe outra execução de showAgenda (ou outro fluxo protegido) em andamento.

Todas as falhas são encaminhadas via onFailure. Erros de pré‑condição/duplicidade interrompem a abertura da Activity.

Exemplo de uso

```kotlin
val pixSdk = Pix.getInstance()

pixSdk.showAgenda(
    configuration = ShowAgendaPixConfig(
        context = this,           // Activity ou Fragment (via requireContext())
        config = ConfigBuilder,   // ConfigBuilder/ Client/Secret/Doc/Wl
        selectedTransactionToCancellation = { tx ->
            // Usuário selecionou uma venda para cancelamento
            // Ex.: navegue para a tela de confirmação, ou inicie o fluxo de estorno
            // handleCancellation(tx)
        }
    ),
    callback = ShowAgendaPixCallback(
        onStartDetailsSale = {
            // Ex.: exibir loading ou registrar analytics de abertura de detalhes
        },
        onSuccessDetailsSale = {
            // Ex.: esconder loading, atualizar UI de detalhes
        },
        onFailure = { e ->
            // Ex.: mostrar erro na tela e registrar telemetria
            // showError(e.message ?: "Falha ao abrir a agenda")
        }
    )
)
```

## **Método getSaleList**

Responsável por recuperar uma lista paginada de vendas PIX com base na configuração fornecida, validando o estado do SDK, prevenindo execuções concorrentes duplicadas, registrando telemetria e orquestrando o fluxo de inicialização interno antes de consultar o repositório.

### Pré-requisitos

-
O SDK deve estar **inicializado com sucesso** via `initialize(...)`.

-
Credenciais mínimas devem ser informadas em `configuration.config`:

-
`identifier` **não** pode ser nulo/vazio

-
`clientId` **não** pode ser nulo/vazio

-
`clientSecret` **não** pode ser nulo/vazio

-
**Sem loading padrão**: este método usa `useDefaultLoading = false`, portanto a aplicação **deve** gerenciar a experiência de carregamento (ex.: via `callback.onStart`).

**Parâmetros**

Referente à classe GetSaleListConfig

-
**context**: Contexto da aplicação/componente de UI (Activity/Fragment) a partir do qual a consulta será executada.

-
**config**: Builder opcional que contém as credenciais, ambiente e customizações para a consulta.

Referente à classe GetSaleListCallback

-
**onStart**: Disparado imediatamente antes do processamento (ideal para exibir loading).

-
**onSuccess**: Disparado quando uma página de resultados é retornada com sucesso, contendo:

-
A lista de transações PIX daquela página

-
Metadados de paginação (ex.: número da página, total, próximo cursor etc., conforme seu tipo)

-
Comportamento de paginação:

-
Internamente o controller usa onPage, portanto onSuccess pode ser invocado múltiplas vezes, uma por página retornada. Ajuste sua UI/estado para lidar com múltiplas entregas incrementais.

-
**onFailure**: Disparado em qualquer falha, incluindo:

-
SDK não inicializado

-
Chamada duplicada

-
Parâmetros/credenciais inválidos

-
Falha na inicialização do core

-
Erros do data source/use case/controller

Todos os callbacks são opcionais (nullable). Invoque de forma defensiva no seu código de integração.

Tratamento de erros e exceções

-
IllegalStateException("Pix SDK not initialized successfully"): SDK não inicializado.

-
DuplicateCallException: Execução concorrente detectada.

-
InvalidRequiredParamsException(): Parâmetros/credenciais inválidos (identifier, clientId ou clientSecret ausentes ou vazios).

-
Exceções provenientes do Core ou do controller/use case/data source: Encaminhadas via onFailure.

Todas as falhas são reportadas via onFailure. Nenhum loading padrão é aberto/fechado por este método.

Exemplo de uso

```kotlin
val pixSdk = Pix.getInstance()

val builder = ConfigBuilder().apply {
    identifier = "merchant-123"
    clientId = "your-client-id"
    clientSecret = "your-client-secret"
    whiteLabelContent = /* opcional: conteúdo whitelabel */
    // outros ajustes de ambiente/filtros/paginação conforme seu ConfigBuilder
}

pixSdk.getSaleList(
    configuration = GetSaleListConfig(
        context = this, // Activity ou Fragment (via requireContext())
        config = builder
    ),
    callback = GetSaleListCallback(
        onStart = {
            // Ex.: mostrar loading caso necessário
        },
        onSuccess = { page: SalesListCallbackPix ->
            // Recebe uma página de resultados
            // Ex.: atualizar lista, anexar ao adapter, verificar se há próxima página
        },
        onFailure = { e ->
            // Ex.: ocultar loading, exibir erro e registrar telemetria
            // showError(e.message ?: "Falha ao carregar vendas PIX")
        }
    )
)
``
```

## **Método getSaleDetails**

Responsável por consultar os dados de uma venda/recebimento PIX (detalhes de pagamento) a partir de um identificador de pagamento (paymentId) e da configuração de parceiro/ambiente. O método valida o estado do SDK, previne execuções duplicadas (quando aplicável), registra telemetria e orquestra a consulta, retornando o resultado por meio de callbacks.

### Pré-requisitos

-
O SDK deve estar **inicializado com sucesso** via `initialize(...)`.

-
`configuration.config` deve conter as **credenciais obrigatórias** do parceiro (por exemplo: `identifier`, `clientId`, `clientSecret`) e demais ajustes necessários ao ambiente.

-
`paymentId` deve ser **informado** e **válido** (não nulo/nem vazio e no formato esperado pelo backend).

-
Observação: Dependendo da implementação interna, o método pode não utilizar loading padrão. Utilize onStart para controlar sua UI de carregamento.

**Parâmetros**

Referente à classe GetSaleDetailsPixConfig

-
**context**: Contexto da aplicação/componente de UI (Activity/Fragment) usado para a operação.

-
**config**: Obrigatório. Builder com as credenciais e parâmetros necessários para autenticação/ambiente da consulta (ex.: identifier, clientId, clientSecret, whiteLabelContent).

-
**paymentId**: Chave/identificador da transação a ser consultada (ID do pagamento).

Referente à classe GetSaleDetailsPixCallback

-
**onStart**: Disparado no início da consulta (ideal para exibir loading).

-
**onSuccess**: Disparado quando a consulta é concluída com sucesso.

-
Fornece um PixReceiptPayment? com os detalhes da transação.

-
Pode ser null se sua implementação tratar “não encontrado” como sucesso sem payload (ajuste conforme sua regra).

-
**onFail**: Disparado quando a consulta falha, fornecendo a exceção de causa.

Todos os callbacks são opcionais (nullable). Invoque de forma defensiva no seu código de integração.

Tratamento de erros e exceções

-
IllegalStateException("Pix SDK not initialized successfully"): Quando o SDK não está inicializado.

-
InvalidRequiredParamsException(...): Quando paymentId está vazio/nulo ou credenciais obrigatórias estão ausentes/invalidas.

-
DuplicateCallException: Se houver proteção contra chamadas concorrentes e outra execução do fluxo estiver em andamento.

-
Exceções de domínio/infra: Erros provenientes de inicialização de core, data source ou backend são propagados via onFail.

Exemplo de uso

```kotlin
val pixSdk = Pix.getInstance()

val builder = ConfigBuilder().apply {
    identifier = "merchant-123"
    clientId = "your-client-id"
    clientSecret = "your-client-secret"
    whiteLabelContent = /* opcional */
    // demais ajustes de ambiente/autenticação se necessário
}

pixSdk.getSaleDetails(
    configuration = GetSaleDetailsPixConfig(
        context = this,      // Activity ou Fragment (via requireContext())
        config = builder,    // obrigatório
        paymentId = "pix-payment-id-abc-123" // obrigatório
    ),
    callback = GetSaleDetailsPixCallback(
        onStart = {
            // Ex.: exibir loading
        },
        onSuccess = { receipt: PixReceiptPayment? ->
            // Ex.: atualizar UI, exibir detalhes, persistir dados
            // if (receipt == null) { mostrar "Transação não encontrada" } else { ... }
        },
        onFail = { e ->
            // Ex.: ocultar loading, exibir erro amigável e registrar telemetria
            // showError(e?.message ?: "Falha ao consultar detalhes do PIX")
        }
    )
)

```

TODO: Haverá initCancellation/ShowEducationScreen

# **Customização**

O arquivo JSON contém as customizações visuais aplicáveis ao componente. A forma de armazenamento fica a critério do parceiro, sendo possível na pasta assets, via serviço, dentre outros.

Existe duas formas de aplicar estilo em um componente:​

-
Na primeira forma, o parceiro integrador pode mudar todas as cores dos componentes de uma vez, por exemplo, alterar a cor de todos os textos. Aplicar o estilo a todos os componentes, por exemplo:​

"componentNameDefaultExample": {​

"textButtonColor": "#000000",​

"backgroundButtonColor": "#FFFFFF",​

"borderButtonColor": "#000000"​

}

Abaixo o exemplo de JSON que deve ser informado:

![](79fb06f96638eb9ca9af7dc58e7b193d060e6330b04fcdee32e9221eadd473ae)

Note analisando o JSON, cada componente possui seu nome especifico, e as opções de propriedades que podem alterar a cor, por exemplo:

`"buttonBlock": { "color": "#5C6A7B", "colorDisabled": "#C5CED7", primaryButtonTextColor: "#FFFFFF",whiteButtonTextColor: "#FFFFFF",dangerButtonTextColor: "#0774E7"},`

Neste exemplo, todos os botões terão a mesma cor aplicadas por `color`, `colorDisabled primaryButtonTextColor, whiteButtonTextColor, dangerButtonTextColor`.



-
Outra forma, é aplicar uma cor específica para cada componente da tela, nesse caso o parceiro integrador irá informar uma cor para cada botão. Aplicar o estilo para um item específico:​

”componentNameByScreenExample": {​

"textButtonColor": "#000000",​

"backgroundButtonColor": "#FFFFFF",​

"borderButtonColor": "#000000"​

}​



Importante ressaltar que o nome dos campo não pode ser alterado, apenas as cores hexadecimais.



Para essa segunda forma de implementação, deve ser configurado da seguinte forma:

-
Para customizar o app, temos um arquivo JSON com campos específicos, abaixo descriminado cada campo nas telas:

### Inserir valor

![Inserir valor da venda.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/Inserir%20valor%20da%20venda.png?version=1&modificationDate=1773153238534&cacheVersion=1&api=v2)



1-`insertValueHeaderPix` → `buttonBackColor`

2-`insertValueInputPix` → `labelColor`

3-`insertValueInputPix` → `inputValueColor`

4- `insertValueInputPix` → `currencyColor`

5- `insertValueButtonNextPix` → `textColor` (para mudar a cor do texto dentro do botão) `textColorDisabled` (cor do texto do botão desabilitado),`color`(botão ativo) e `colorDisabled`(botão desativado)

### Comprovante de pagamento



![image-20260310-144545.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20260310-144545.png?version=1&modificationDate=1773153949944&cacheVersion=1&api=v2)



1- `pixReceiptView`→ `backgroundColor, shareBorderColor`

2- `receiptPixTimerText`-> `colorText`

3- `receiptPixTimerProgress`-> `timerProgressColor`, `timerBackgroundColor`

4- `receiptPixCloseButton`-> `color`

5- `receiptPixNewSell`-> `textButtonColor`, `backgroundButtonColor`, `borderButtonColor`

6- `receiptPixShare`-> `color`

### Minhas vendas

![image-20240322-131749.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20240322-131749.png?version=1&modificationDate=1773163700178&cacheVersion=1&api=v2)



1-`mySalesHeaderPix`→ `buttonBackColor`

2-`mySalesHeaderPix`→ `textColor`





![image-20260310-173002.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20260310-173002.png?version=1&modificationDate=1773163806113&cacheVersion=1&api=v2)

1-`mySalesItemStatusPix`→ `colorTextStatusApproved, colorBackgroundApproved, colorTextStatusCanceled, colorBackgroundCanceled, colorTextStatusContested, colorBackgroundContested, colorTextStatusPending, colorBackgroundPending, colorTextStatusExpired, colorBackgroundExpired`

2-`mySalesItemDateOrHourPix`→ `colorText`

3-`mySalesItemAmountPix`→ `colorText`

4-`mySalesItemLabelFluiPix`-> `colorText`

![image-20240322-131826.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20240322-131826.png?version=1&modificationDate=1773164980937&cacheVersion=1&api=v2)



1-`mySalesErrorLabelPix`→ `colorText`

2-`mySalesErrorButtonPix`→ `textButtonColor`

3-`mySalesErrorButtonPix`→ `backgroundButtonColor`

4- `mySalesErrorButtonPix`→ `borderButtonColor`

![image-20240322-131922.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20240322-131922.png?version=1&modificationDate=1773165148376&cacheVersion=1&api=v2)

1-`mySalesEmptyListLabelPix`→ `colorText`

### Comprovante de Cancelamento



![image-20260310-180331.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20260310-180331.png?version=1&modificationDate=1773165815388&cacheVersion=1&api=v2)

1- `pixSaleDetailsHeader` → `buttonBackColor`

2- `pixSaleDetailsHeader` → `buttonShareColor`, para customizar a cor do botão desativado incremente a chave `buttonShareDisabledColor`

`pixSaleDetailsHeader`-> `backgroundColor`

3- `pixSaleDetailsHeader` → `textColor`

4- `pixSaleDetailsLabel`→ `colorText`

5- `pixSaleDetailsValues` → `colorText`

6- `pixSaleDetailsExplanationAmountReceived`→ `colorText`

7- `pixMySalesItemStatus`-> `colorTextStatusApproved`, `colorBackgroundApproved`, `colorTextStatusCanceled`, `colorBackgroundCanceled`, `colorTextStatusContested`, `colorBackgroundContested`, `colorTextStatusPending`, `colorBackgroundPending`, `colorTextStatusExpired`, `colorBackgroundExpired`

### Status Bar em todas as telas

![image-20240815-135857.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20240815-135857.png?version=1&modificationDate=1773166032707&cacheVersion=1&api=v2)



1- `statusBar`→ `backgroundColor`

Utilize o JSON abaixo como exemplo para alterar as cores:

![](04713b5f7eaf587d44ed0be159b440dc44a918d33c12bbb9c60b2ed867b070bf)

## Componente Loading.

No componente de loading é possível realizar a customização de cores, intervalo de troca de textos e textos. Também é possível fazer referência de textos que estão dentro do arquivos de strings.xml, segue exemplo de como é possível fazer a referência.

**strings.xml:**

![](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/Captura%20de%20Tela%202024-01-31%20a%CC%80s%2011.25.25.png?version=1&modificationDate=1773338191374&cacheVersion=1&api=v2)

No json do whitelabel deve ser incluído o “@” como prefixo conforme o exemplo abaixo:

![image-20260312-180936.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/image-20260312-180936.png?version=1&modificationDate=1773338980878&cacheVersion=1&api=v2)

Dessa forma teremos o seguinte resultado:

![Screenshot_20240131_112717.png](https://jiracielo.atlassian.net/wiki/download/attachments/5067735287/Screenshot_20240131_112717.png?version=1&modificationDate=1773338191485&cacheVersion=1&api=v2)



# Tratamento de erros

Durante a integração com o SDK, podem ocorrer falhas caso algum passo não seja executado corretamente — por exemplo, erro na inicialização do SDK, timeouts de rede, indisponibilidade do serviço ou envio de parâmetros inválidos durante uma transação.

É fundamental que a aplicação do parceiro esteja preparada para mapear, classificar e tratar esses erros, registrá‑los para diagnóstico e comunicar o usuário da melhor forma, oferecendo ações de correção quando possível.

### Inicialização do SDK (initialize)

Caso ocorra algum problema durante a inicialização, o callback `onInitializeFailure` será acionado, retornando uma exception com o tipo de falha ocorrido.

A seguir, listamos as possíveis exceptions que podem ser retornadas, divididas em dois grupos: **Com tela** (exibem mensagem padrão ao usuário) e **Sem tela** (devem ser tratadas pela aplicação integradora).

`DeviceIncompatibleException`-> Não possui tela, possíveis incompatibilidades: `DEVICE_WITH_VERSION_OS_INCOMPATIBLE`,`DEVICE_IS_EMULATOR`, `DEVICE_IS_ROOT` e/ou `DEVICE_IS_DEV_MODE`.

`DuplicateCallException`-> Não possui tela, lançado quando parceiro integrador tenta chamar o sdk enquanto há um sessão em execução.

`InvalidRequiredParamsException`-> Não possui tela, lançado quando parceiro integrador não informou corretamente os campos da classe `ConfigBuilder`.

### Pagamento (initPayment)

`IllegalStateException`-> Não possui tela, lançado quando o integrador não chamou o método initialize na primeira sessão.

`DuplicateCallException`-> Não possui tela, lançado quando parceiro integrador tenta chamar o sdk enquanto há um sessão em execução.

`InvalidRequiredParamsException`-> Não possui tela, lançado caso o campo `initialValue` seja nulo ou zero.

### Jornada de captura de valor (initJourney)

`IllegalStateException`-> Não possui tela, lançado quando o integrador não chamou o método initialize na primeira sessão.

`DuplicateCallException`-> Não possui tela, lançado quando parceiro integrador tenta chamar o sdk enquanto há um sessão em execução.

### Listagem de transações (showAgenda)

`IllegalStateException`-> Não possui tela, lançado quando o integrador não chamou o método initialize na primeira sessão.

`DuplicateCallException`-> Não possui tela, lançado quando parceiro integrador tenta chamar o sdk enquanto há um sessão em execução.

### Listagem de transações (getSaleList)

`IllegalStateException`-> Não possui tela, lançado quando o integrador não chamou o método initialize na primeira sessão.

`DuplicateCallException`-> Não possui tela, lançado quando parceiro integrador tenta chamar o sdk enquanto há um sessão em execução.

`InvalidRequiredParamsException`-> Não possui tela, lançado quando parceiro integrador não informou corretamente os campos da classe `ConfigBuilder`.

### Detalhe da transação (getSaleDetails)

`IllegalStateException`-> Não possui tela, lançado quando o integrador não chamou o método initialize na primeira sessão.

`DuplicateCallException`-> Não possui tela, lançado quando parceiro integrador tenta chamar o sdk enquanto há um sessão em execução.

`InvalidRequiredParamsException`-> Não possui tela, lançado quando parceiro integrador não informou corretamente os campos da classe `ConfigBuilder`.

# Logs

Abaixo segue todos os logs disponíveis, esse logs foram obtidos através do evento onLogs do [método initializer](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-Inicialize).



![](059754d1be9dfb07a47079c088369690123b68dd478172c3f3e26aa0a06930aa)

### **Conclusão**

Este guia forneceu uma visão geral dos requisitos do SDK Android e de como pode ser feita a sua inicialização e customização.


