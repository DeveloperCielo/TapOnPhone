# Manual de Integração — SDK Cielo TAP (Android)

Manual de integração (Android)

# Manual de integração (Android)

**Documentação do SDK – Tap on phone**

Este guia irá orientá-lo através dos requisitos do SDK, como inicializar a biblioteca, as diferentes jornadas disponíveis, como usar o white label e como realizar transações.

**Requisitos do SDK**

| ****Android**** 
|


| Versão mínima do SDK: Android 10 (API 29) (Pode variar por versão tap)
|


| Versão do SDK recomendada: Android 10 (API 29) 
|


| Acesso à internet 
|


| Mínimo de espaço livre no dispositivo é 100 mb 
|


| NFC no Dispositivo 
|

**Requisitos do Sistema**

| ****Windows**** 
|


| Android Studio recomendado: Android Studio Giraffe | 2022.3.1 Patch 1 
|

**Projeto de exemplo**

Neste projeto, criamos um exemplo, de implementação do SDK, permitindo que o usuário visualize diferentes cenários da jornada transacional e compreenda a melhor forma de implementá-lo para um funcionamento ideal.

Abaixo o link do projeto:

https://docs.cielo.com.br/conecta/docs/requisitos-android#:~:text=link%20do%20projeto%3A-,Sample,-Aviso%20ao%20desenvolvedor

**Adicionando o SDK ao seu projeto**

Criar uma pasta no projeto de nome libs, no mesmo nível do src:


{SEU_DIRETÓRIO}\app\libs


Ficando da seguinte forma:


![image-20240220-165810.png](images-android/img_21.png)


Copiar os arquivos enviados para a pasta criada​.

Abrir o arquivo build.gradle da aplicação, normalmente dentro da pasta app​.

Na seção de dependências do seu projeto adicionar:


*IMPORTANTE: o nome específico da dependência e sua respectiva versão é conforme o pacote atual disponibilizado.*

```kotlin
implementation(files("$projectDir/libs/allowme.aar"))
implementation(files("$projectDir/libs/taponphone.aar"))
implementation(files("$projectDir/libs/top-sdk.aar"))
implementation(files("$projectDir/libs/top-sdk-2-core-2.0.3.jar
implementation(files("$projectDir/libs/top-sdk-3-branding-1.0.6.aar"))
implementation(files("$projectDir/libs/top-sdk-3-core-2.0.aar"))
implementation(files("$projectDir/libs/top-sdk-4-core-1.0.18.aar"))
implementation(files("$projectDir/libs/top-sdk-reader-utils.aar"))
implementation(files("$projectDir/libs/top-sdk-utils.aar"))
```

ou (recomendamos adicionar a linha abaixo, como primeira dependência):​

| ****Goovy**** 
| ****Kotlin**** 
|


| ```kotlin
implementation fileTree(dir: "libs", include: ["*.jar", "*.aar"])​
``` 
| ```kotlin
implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
``` 
|

Extraia o arquivo abaixo na raiz do projeto

https://github.com/DeveloperCielo/TapOnPhone/raw/main/sdkp-tap-1.7.2.zip

Adicionar a seguinte instrução no seu **settings.gradle**:

| ****Groovy**** 
| ****Kotlin**** 
|


| ```kotlin
pluginManagement {
repositories {
google()
mavenCentral()
gradlePluginPortal()
}
buildscript {
repositories {
mavenCentral()
maven {
url = uri("https://storage.googleapis.com/r8-releases/raw")
}
}
dependencies {
classpath("com.android.tools:r8:8.3.37")
classpath("com.dynatrace.tools.android:gradle-plugin:8.279.1.1002")
}

}
}

dependencyResolutionManagement {
repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
repositories {
google()
mavenCentral()
mavenLocal() {
url uri("${rootDir}/artefacts")
}

flatDir {
dirs 'libs'
}
}
}
``` 
| ```kotlin
pluginManagement {
repositories {
google()
mavenCentral()
gradlePluginPortal()
}
buildscript {
repositories {
mavenCentral()
maven {
url = uri("https://storage.googleapis.com/r8-releases/raw")
}
}
dependencies {
classpath("com.android.tools:r8:8.3.37")
classpath("com.dynatrace.tools.android:gradle-plugin:8.279.1.1002")
}

}
}

dependencyResolutionManagement {
repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
repositories {
google()
mavenCentral()

mavenLocal {
setUrl("${rootDir}/artefacts")
}

flatDir {
dirs("libs")
}
}
}
``` 
|

Abrir o arquivo **build.gradle** da aplicação, normalmente dentro da pasta app​, na seção dependencies adicionar:​

| ****Kotlin**** 
|


| ```kotlin
dependencies {
implementation fileTree(include: ['*.aar', '*.jar'], dir: 'libs')

//navite dependencies
implementation 'androidx.core:core-ktx:1.9.0'
implementation 'androidx.appcompat:appcompat:1.6.1'
implementation 'com.google.android.material:material:1.11.0'
implementation 'androidx.constraintlayout:constraintlayout:2.1.4'

//security module dependencies
implementation 'com.squareup.okhttp3:okhttp:4.12.0'
implementation 'com.squareup.okhttp3:logging-interceptor:4.12.0'

implementation 'androidx.camera:camera-camera2:1.4.0'
implementation 'androidx.camera:camera-lifecycle:1.4.0'
implementation 'androidx.camera:camera-view:1.4.0'
implementation 'com.google.mlkit:face-detection:16.1.7'
implementation 'com.scottyab:rootbeer-lib:0.1.1'

implementation 'com.google.android.gms:play-services-ads-identifier:18.0.1'
implementation 'com.google.android.gms:play-services-appset:16.0.2'
implementation 'com.google.android.gms:play-services-tasks:18.0.2'

//payment module dependencies
implementation 'com.google.android.play:integrity:1.2.0'
implementation 'com.madgag.spongycastle:core:1.58.0.0'
implementation 'com.madgag.spongycastle:prov:1.58.0.0'
implementation group: 'org.bouncycastle', name: 'bcprov-jdk18on', version: '1.78'
implementation "io.reactivex.rxjava2:rxjava:2.2.6"
implementation "io.reactivex.rxjava2:rxandroid:2.1.1"
implementation "com.airbnb.android:lottie:6.7.1"
implementation 'com.android.volley:volley:1.2.1'
implementation 'net.danlew:android.joda:2.9.9.4'
implementation 'com.google.guava:guava:32.0.1-jre'
implementation 'androidx.databinding:viewbinding:7.1.2'
implementation 'com.facebook.shimmer:shimmer:0.5.0'
implementation "com.discover.sdk:core:1.1.6"
implementation "com.discover.sdk:card-reader:2.3.11"
implementation 'com.squareup.retrofit2:retrofit:3.0.0'
implementation 'com.squareup.retrofit2:converter-gson:3.0.0'
implementation "androidx.room:room-runtime:2.7.0"
implementation("androidx.room:room-ktx:2.7.0")
annotationProcessor "androidx.room:room-compiler:2.7.0"
kapt "androidx.room:room-compiler:2.7.0"
testImplementation "androidx.room:room-testing:2.7.0"
api 'io.jsonwebtoken:jjwt-api:0.13.0'
api(group: "androidx.work", name: "work-runtime") {
version {
strictly "2.8.1"
}
}
api(group: "androidx.work", name: "work-runtime-ktx") {
version {
strictly "2.8.1"
}
}
runtimeOnly 'io.jsonwebtoken:jjwt-gson:0.13.0'
runtimeOnly 'io.jsonwebtoken:jjwt-impl:0.13.0'

//log module dependencies
implementation "com.datadoghq:dd-sdk-android-logs:2.11.0"
implementation "com.datadoghq:dd-sdk-android-okhttp:2.11.0"
implementation 'com.dynatrace.agent:agent-android:8.279.1.1002'

//dependencies for the operation of test classes
testImplementation 'junit:junit:4.13.2'
androidTestImplementation 'androidx.test.ext:junit:1.1.5'
androidTestImplementation 'androidx.test.espresso:espresso-core:3.5.1'

//Optional - According to the configuration of each project, this dependency may be necessary
implementation 'androidx.security:security-crypto:1.1.0-alpha03'
}
``` 
|

Outra dependência mandatória para o funcionamento do SDK é AndroidX (Documentação android sobre o assunto:[https://developer.android.com/jetpack/androidx?hl=pt-br](https://developer.android.com/jetpack/androidx?hl=pt-br) ), sendo assim adicione a linha abaixo no seu gradle.properties:

```kotlin
android.enableJetifier=true
```

# Regras de exceção do Proguard

Para gerar artefatos ofuscados é necessário a implementação do proguard no projeto. Isso pode ser feito através da adição das seguintes linhas no arquivo build.gradle:

```kotlin
buildTypes {
debug {
minifyEnabled true
proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
signingConfig signingConfigs.debug
}
}
```

Também é necessário adicionar as regras de exceção no arquivo [proguard-rules.pro](http://proguard-rules.pro), uma vez que após a ofuscação o nome de métodos e classes necessários para o funcionamento do sdk são alterados. As regras de exceção são adicionadas como uma forma de previnir que esses métodos e classes tenham a sua referência no código ofuscada e causem erros na execução do sdk.

Verifique o arquivo de regras dentro do zip da versão corrente.


# Configurações no AndroidManifest.xml

Dependendo da configuração do projeto será necessário a adição das seguintes configurações no seu AndroidManifest.

É importante lembrar que a implementação abaixo é uma sugestão. e pode variar no seu projeto.

Desenvolvedor amplie sua atenção sobre as configurações do seu AndroidManifest, e ao merge de dependências/permissões, é normal que haja um impacto significativo na integração e distribuição na loja do google play.

Por padrão, nossa biblioteca define como TRUE o valor de ***android.hardware.nfc***, porém para a aplicação essa configuração pode impactar nos filtros do Google Play Store.

Por padrão, nossa biblioteca define como TRUE o valor de ***android.hardware.camera***, porém para a aplicação essa configuração pode impactar nos filtros do Google Play Store.

Faça o seguinte complemento (conforme a necessidade):

```kotlin
<uses-permission
android:name="android.permission.NFC" />

<uses-feature
android:name="android.hardware.nfc"
android:required="false"
tools:replace="android:required"/>

<uses-feature
android:name="android.hardware.camera"
android:required="false"
tools:replace="android:required"/>

// Considere adicionar tools:overrideLibrary="br.com.cielo.posvirtual" para versão igual ao superior 1.2.54.
// Os seguintes overrides foram descontinuados na versão 1.2.54: br.com.cielo.taponphone, br.com.cielo.dtf.spsv.flui e br.com.cielo.dtf.spsv.commons.
<uses-sdk tools:overrideLibrary="br.com.cielo.taponphone,
com.symbiotic.taponphone,
com.visa.app.ttpkernel,
com.symbiotic.cardreader,
com.symbiotic.pinonglass,
com.discover.sdk,
com.discover.mpos.sdk,
com.discover.mpos.sdk.core,
androidx.security"/>
```

# Aviso ao desenvolvedor

Quanto ao processo de integração, avisamos que a primeira tentativa transacional ***não irá funcionar. ***Existe um bloqueio por parte da Cielo para novos integradores, esse bloqueio avalia a chave *kestore *(debug e release) do aplicativo corrente. A primeira tentativa haverá pela parte do sdk um registro de acesso, o que entenderemos como fraude, o parceiro integrador deve entrar em contato conosco informando o problema através do seguinte e-mail: [posvirtual_mobile@cielo.com.br](mailto:posvirtual_mobile@cielo.com.br). Após nós desbloquearmos irá funcionar o transacional para o aplicativo do parceiro.

Durante o processo de credenciamento certamente será solicitado pela Cielo um bundle id, em projetos de teste geralmente por padrão são *com.example.myapplication, *nosso produto faz a leitura do pacote e exige que o pacote seja o mesmo informado no credenciamento.


# Plugins obrigatórios

Dentro do seu módulo de app, caso não exista a cláusula plugins, crie da seguinte forma e importe os novos plugins (o formato correto pode variar de acordo com a configuração do seu projeto):

```kotlin
plugins {
id 'com.android.application' (Já deve existir, nativamente, para modulo de app)
id 'org.jetbrains.kotlin.android' (Novos)
id 'kotlin-kapt' (Novos)
}
```

# Inicialização

O processo de inicialização pode ser feito dentro da Activity que precede o pagamento ou dentro da Application. ​

IMPORTANTE: Garanta na sua implementação que os outros métodos do SDK apenas sejam chamados após o initialize:onInitializeSuccess.

Exemplo de inicialização:​

```kotlin
val config = ConfigBuilder(context = this)
.initClient("[CLIEND ID]", "[CLIENT SECRET]")
.setCNPJ("[CNPJ do contratante]")
.loadWhiteLabel("wl_custom.JSON")

val tapOnPhoneSdk = TapOnPhone.getInstance()
tapOnPhoneSdk.initialize(
this, config,
onInitializeSuccess = {},
onInitializeFailure = {},
useDefaultLoading = true,
)
```

Detalhes dos métodos e respectivos campos:

.**initClient**​

**client id**: id único por cliente disponibilizado pela Cielo na aquisição.​

**client secret**: secret do cliente informado pela Cielo na aquisição.​

​.**loadWhiteLabel**​

filename: nome do arquivo de WhiteLabel com as customizações.​

**.setCPF ou .setCNPJ​**

**document**: número de documento do contratante seja, CPF ou CNPJ (chamar apenas um dos dois).

**Atenção!**

A partir da versão 1.5.6, não é mais realizada a remoção automática da máscara dos documentos enviados no initialize.

Portanto o integrador deve garantir que o valor enviado esteja **totalmente sanitizado**, contento **apenas letras e números**, sem pontos, barras, traços ou qualquer outro caractere especial.

Essa alteração é resultado da adequação ao suporte para CNPJs alfanuméricos, que será implementado a partir do próximo ano conforme nova regulamentação da Receita Federal.

✅ Exemplos correto: 29420054080, 11541750000197 e A1B2C3D4E5F699

❌ Exemplos incorretos: 294.200.540-80, 11.541.750/0001-97 e A1.B2C.3D4/E5F6-99

Essa medida visa garantir consistência e evitar falhas no processamento dos dados.

## **JourneyData: Objeto da transação**

Esse é o objeto responsável por armazenar todas as informações da transação.

Descrição dos campos:

- **price**: valor inicial a ser cobrado do cliente.


- **paymentMethod**: tipo de pagamento inicial a ser utilizado. Os tipos de pagamento são:​

- **PaymentMethods.DEBIT**: venda a débito​.


- **PaymentMethods.CREDIT_SINGLE**: venda a crédito à vista​.


- **PaymentMethods.INSTALLMENT_CREDIT**: venda a crédito parcelada​.

- **installments**: quantidade de parcelas, caso o tipo de venda seja venda a crédito parcelada. ​Caso não possua, usar o valor padrão “1”.

A partir dessa instância você terá acesso aos seguintes métodos initJourney e initPayment*.*

Abaixo temos uma explicação de cada método e exemplos de como implementar:


## **Método warmUp **

O método warmUp tem como objetivo otimizar o tempo de execução do método initialize, antecipando verificações de segurança do dispositivo. Ele realiza chamadas a funções específicas do módulo de segurança que não possuem vínculo direto com a funcionalidade de pagamento.

Internamente, o método initialize consome o warmUp antes de iniciar o fluxo transacional, garantindo que as verificações já tenham sido realizadas previamente.

A implementação do warmUp possui um controle interno que evita sua reexecução caso já esteja em andamento, o que contribui para a melhoria de performance do initialize. Por isso, recomenda-se que o warmUp seja chamado o quanto antes, preferencialmente logo após a instância do aplicativo.

**Sugestão de uso:**

Chame o método `warmUp` na `MainActivity` da sua aplicação (ou equivalente), ou durante o processo de onboarding/credenciamento do usuário.

Para iniciar o método warmUp, basta seguir o exemplo abaixo:

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.warmUp(
context = this
)
```

**Descrição dos parâmetros:**

- **context: **context da aplicação​.

## **Método Inicialize **

Método responsável por inicializar o SDK e carregar dados iniciais do usuário como chaves de inicialização, executar diversos procedimento de segurança, e validação de parceiro.

Para iniciar o método Initialize, basta seguir o exemplo abaixo:

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.initialize(
context = this,
config,
onInitializeStart = {},
onInitializeSuccess = {},
onInitializeFailure = {exception -> },
onLogs = {typeLog, message -> },
useDefaultLoading = false,
)
```

**Descrição dos parâmetros:**

- **context: **context da aplicação​.


- **config: **Descriminado na inicialização.** **[**Mais informações.**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#Inicializa%C3%A7%C3%A3o)


- **onInitializeStart: **callback chamado no momento em que o processo de inicialização se inicia​.


- **onInitializeSuccess: **método chamado quando o processo de inicialização ocorre com sucesso​.


- **onInitializeFailure(Exception): **método chamado quando ocorre alguma falha no processo de inicialização​.


- **onLogs(type: **[**TypeLog**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3446113359/Android+Itens+para+a+nova+vers+o#Enum-do-tipo-de-log%3A)**, message: String)**: Com esse método você pode obter os logs do sdk.
**Observação**: Neste evento retorna os logs de todo o SDK, inclusive logs das demais funções (InitJorney e InitPayment).

Os tipos de logs que temos é:

- **TypeLog.INFO: **Log com tipo informação;


- **TypeLog.WARNING: **Log com tipo aviso;


- **TypeLog.ERROR: **Log com tipo error;

- **useDefaultLoading: **Define se uma tela de loading padrão será exibida durante o processo de inicialização. Por padrão, este campo é definido como true, o que significa que tanto a tela de carregamento quanto a tela de feedback de erro serão exibidas automaticamente, caso necessário. Se definido como false, a aplicação deverá gerenciar manualmente a exibição de loading e tratamento de alguns erros, assumindo total controle da experiência visual durante a inicialização.

## **Método initJourney**

Método responsável por receber dados dos usuários e tela de inicialização da jornada White Label, caso não tenha interesse em usar as telas é possível iniciar diretamente initPayment.

Para iniciar a transação com as telas, o código é o seguinte:​

```kotlin
val data: JourneyData = JourneyData(BigDecimal(0.0), PaymentMethodsEnum.CREDIT_SINGLE, 1)​

val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.initJourney(
context = this,
step = TapOnPhone.Step.PAYMENT_METHOD,
defaultData = data,
errorCallback = { exception -> },
errorReturnCallback = {},
endCallback = { data: JourneyData? -> },
showHelpCallback = {},
)​
```

Descrição dos parâmetros:

- **context**: context da aplicação​.


- **step**: tela inicial da jornada. Possui as seguintes opções:​

- **Step.INPUT_PRICE:** inicia a jornada na tela de input de valores​.


- **Step.PAYMENT_METHOD**: inicia a jornada pela tela de seleção de tipo de pagamento​.

- **defaultData (JourneyData)**: dados de inicialização padrão​. [Mais informações.](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#JorneyData%3A-Objeto-da-transa%C3%A7%C3%A3o)


- **errorCallback(Exception)**: método chamado quando existe uma falha na jornada. Sempre é exibida uma tela de erro, mas essa chamada pode executar código adicional a esse processo.​


- **errorReturnCallback**: método chamado quando o usuário clica no botão de retorno na tela de erro exibida, descrita acima. O processo irá fechar a tela e este callback permite executar código adicional a essa ação.


- **endCallback(**[**JorneyData**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#JorneyData%3A-Objeto-da-transa%C3%A7%C3%A3o)**)**: método chamado quando o usuário termina de preencher a jornada de telas. Ele retorna os dados preenchidos dentro do objeto JourneyData. Esses dados servem de input para o método de pagamento.​


- **showHelpCallback: ** método chamado quando usuário clicar no botão de help na tela de selecionar tipo de pagamento. Para controlar a visibilidade desse botão olhe no tópico de customização.

## **Método InitPayment**

Método responsável por iniciar o transacional.

Descrição dos parâmetros:

- **context**: context da aplicação​.


- **logoImageRes**: logo da imagem que pretende colocar na tela transacional, onde solicita aproximação do cartão.


- **initialData (**[**JorneyData**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#JorneyData%3A-Objeto-da-transa%C3%A7%C3%A3o)**)**: dados de pagamento. Pode ser preenchido diretamente ou retornado pelo callback da jornada​.


- **onPaymentStart()**: Esse evento será levantando quando for chamado o método initPayment.


- **onPaymentSuccess(PaymentTransactionReceiptData)**: método chamado quando o pagamento é realizado com sucesso.​​


- **onPaymentFailure (ErrorsPaymentEnum)**: método chamado quando ocorre um erro no pagamento.


- **config: **mesmo parâmetro obrigatório solicitado na função [initialize](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-Inicialize), solicitamos novamente esse parâmetro para inicializar ou não o sdk, caso esteja initializado porém tenha expirado, iremos initializar novamente antes de iniciar o pagamento.


- **onNewSale**: método chamado ao tocar sobre botão nova venda que está na tela de comprovante. **Observação**: Ao tocar sobre o botão nova venda, será emitido um evento e em seguida fecha o TapOnPhone.


- **onEnd**: Esse evento será chamado ao finalizar a jornada de pagamento.

Para iniciar esse método basta seguir o exemplo abaixo:

```kotlin
val data: JourneyData = JourneyData(BigDecimal(10.0), PaymentMethodsEnum.CREDIT_SINGLE, 1)

val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.initPayment(
context = this,
logoImageRes = R.drawable.ic_exemple,
initialData = data,
config = config,
onPaymentStart = { },
onPaymentSuccess = { receiptPayment: PaymentTransaction? -> }, 
onPaymentFailure = { errorsEnum: ErrorsPaymentEnum? -> },
onNewSale = {},
onEnd = {}
)
```

```kotlin
data class PaymentTransaction(
val amount: BigDecimal? = null,
var applicationId: String? = null,
val brand: String? = null,
val cardFirstNumbers: String? = null,
val cardLastDigits: String? = null,
val currencyCode: String? = null,
val date: String? = null,
val rrn: String? = null,
val time: String? = null,
val transactionDate: String? = null,
val transactionId: Int? = null,
val transactionType: String? = null,
var status: PaymentStatus? = null,
var installment: Int? = null,
var dynamicBankDataModel: DynamicBankData? = null
) : Parcelable

data class DynamicBankData(
val paymentId: String? = null,
var receiptInfoModel: ReceiptInfo? = null
): Parcelable

data class ReceiptInfo(
val merchantName: String? = null,
val nomeSocial: String? = null,
val merchantAddress: String? = null,
val merchantCity: String? = null,
val merchantState: String? = null,
val merchantCode: String? = null,
val nsu: String? = null,
val data: String? = null,
val cardNumber: String? = null,
val brand: String? = null,
val transactionType: String? = null,
val authorizationCode: String? = null,
val value: String? = null,
val installment: Int? = null,
val interest: String? = null,
val paymentDateTime: String? = null,
)
```

# **Método initCancelation:**

Método responsável por realizar o cancelamento da transação:

| ```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.initCancellation(
context = Context,
config,
paymentTransaction = PaymentTransaction(),
onStart: (() -> Unit)? = null,
onMySale: (() -> Unit)? = null,
onSuccess: ((paymentData: PaymentTransaction?) -> Unit)? = null,
onError: ((enum: ErrorsPaymentEnum, e: Exception?) -> Unit)? = null,
onCloseReceipt: (() -> Unit)? = null,
)
``` 
|

Descrição dos parâmetros:

- **context: **context da aplicação​.


- **config: **Descriminado na inicialização.** **[**Mais informações.**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#Inicializa%C3%A7%C3%A3o)


- **paymentTransaction**: Dados necessários para realizar o cancelamento da transação. **Obs**: Esses dados podem ser obtidos através do método **getSaleDetails**().


- **onStart**: Ao iniciar o processo será levantando esse callback.


- **onMySale: **Callback de retorno caso o usuário selecione a opção de Minhas vendas na tela de comprovante de cancelamento.


- **onSuccess(paymentTransaction): **Callback de retorno quando ocorrer sucesso no cancelamento da transação.


- **onError(ErrorsPaymentEnum, Exception)**: Callback de retorno quando ocorrer algum error no cancelamento da transação.


- **onCloseReceipt:** Callback chamado quando o usuário seleciona o botão de fechar na tela de comprovante.

# **Método GetSaleList**

Método responsável por pegar a lista de vendas realizadas e fazer a paginação da mesma.

Descrição dos parâmetros:

- **context: **Context da aplicação


- **config: **mesmo parâmetro obrigatório solicitado na função [initialize](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-Inicialize), solicitamos novamente esse parâmetro para inicializar ou não o sdk, caso esteja initializado porém tenha expirado, iremos initializar novamente antes de iniciar o pagamento.** **[**Mais informações.**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#Inicializa%C3%A7%C3%A3o)


- **onStart**: Callback chamado quando iniciado o processo.


- **onFailure: **Método chamado quando ocorre algum erro ao tentar pegar lista, retorna o erro obtido.


- **onSuccess:** Método chamado após concluir, sem nenhum problema, a coleta da lista e paginar os dados, retorna os dados no formato `SalesListCallback`.


Para iniciar o método, bata seguir o exemplo:

```kotlin
val data: JourneyData = JourneyData(BigDecimal(10.0), PaymentMethodsEnum.CREDIT_SINGLE, 1)

val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.getSaleList(
context = this,
config: Config?,
onStart = {},
onFailure = {error: Exception? -> },
onSuccess = {salesList: SalesListCallback? -> }
)
```

```kotlin
data class SalesListCallback(
var datas: List<TransactionEntity>,
var pagination: Pagination,
var loadMore: (() -> Unit)? = null
)

data class Pagination(
var currencyPage: Int,
var pageSize: Int = 0,
)
```

# **Método showAgenda**

Método responsável por listar as transações realizadas pelo usuário, uma tela específica sobre o detalhe da venda e realizar o cancelamento da transação:

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()

tapOnPhoneSdk.showAgenda(
context = Context,
config,
selectedTransactionToCancelation: ((transaction: PaymentTransaction?) -> Unit)? = null,
onStartDetailsSale: (() -> Unit)? = null,
onSuccessDetailsSale: (() -> Unit)? = null,
onFailure: (() -> Unit)? = null
)
```

Descrição dos parâmetros:

- **context: **context da aplicação​.


- **config: **mesmo parâmetro obrigatório solicitado na função [initialize](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-Inicialize), solicitamos novamente esse parâmetro para inicializar ou não o sdk, caso esteja initializado porém tenha expirado, iremos initializar novamente antes de iniciar o pagamento.** **[**Mais informações.**](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#Inicializa%C3%A7%C3%A3o)


- **selectedTransactionToCancelation(transaction): **Quando o usuário selecionar uma transação (tela detalhe da venda, botão “Cancelar Venda”) para cancelar esse *callback *será invocado. Recomendamos que seja invocado a função *initCancelation *com esse parâmetro. Caso tenha interesse em obter uma transação para cancelar, sem utilizar a jornada de telas, veja a função *getSaleDetails*.


- **onStartDetailsSale: **Callback quando o usuário seleciona uma transação e inicia a consulta aos detalhes dela. Obs. quando utilizado useDefaultLoading deve ser mostrado tela de loading neste callback neste callback.


- **onSuccessDetailsSale: **Callback de retorno quando conclui com sucesso a consulta aos detalhes da transação.


- **onFailure**: Callback de retorno quando ocorrer algum erro na listagem de transações.

# **Método getSaleDetails:**

Método responsável por consultar as informações de uma venda realizada anteriormente através de seu identificador (paymentId).

Descrição dos parâmetros:

- **context: **context da aplicação​.


- **config: **mesmo parâmetro obrigatório solicitado na função [initialize](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-Inicialize), solicitamos novamente esse parâmetro para inicializar ou não o sdk, caso esteja inicializado porém tenha expirado, iremos inicializar novamente antes de iniciar o pagamento.


- **paymentId: **Dado utilizado como chave para consultar as informações de venda.


- **onStart**: Callback levantado quando iniciado o processo.


- **onSuccess(PaymentTransaction): **Callback chamado quando o a consulta de informações é realizado com sucesso.​​


- **onFail(Exception)**: Callback chamado quando ocorre um erro durante o fluxo.


Para iniciar esse método basta seguir o exemplo abaixo:

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()
val paymentId = "PAYMENT_ID"
tapOnPhoneSdk.getSaleDetails(this, config, paymentId, onStart = {}, onSuccess = {}, onFail = {})
```

# **Método ShowEducationScreen:**

Método responsável por mostrar uma sequência de telas educacionais com o objetivo de informar o usuário sobre o funcionamento do produto.

Para iniciar o método showEducationScreen, basta seguir o exemplo abaixo:

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()
tapOnPhoneSdk..showEducationScreen(
this,
onEnd = {},
onFailure = {}
)
```

**Descrição dos parâmetros:**

- **context: **context da aplicação​.


- **onEnd: **Esse evento será chamado ao finalizar a jornada do educacional.


- **onFailure(Exception): **método chamado quando ocorre alguma falha no processo de mostrar o educacional.

# **Customização**

O arquivo JSON contém as customizações visuais aplicáveis ao componente. A forma de armazenamento fica a critério do parceiro, sendo possível na pasta assets, via serviço, dentre outros.

Existe duas formas de aplicar estilo em um componente:​

- Na primeira forma, o parceiro integrador pode mudar todas as cores dos componentes de uma vez, por exemplo, alterar a cor de todos os textos. Aplicar o estilo a todos os componentes, por exemplo:​


"componentNameDefaultExample": {​

"textButtonColor": "#000000",​

"backgroundButtonColor": "#FFFFFF",​

"borderButtonColor": "#000000"​

}

Abaixo o exemplo de JSON que deve ser informado:

Note analisando o JSON, cada componente possui seu nome especifico, e as opções de propriedades que podem alterar a cor, por exemplo:

`"buttonBlock": { "color": "#5C6A7B", "colorDisabled": "#C5CED7", primaryButtonTextColor: "#FFFFFF",whiteButtonTextColor: "#FFFFFF",dangerButtonTextColor: "#0774E7"},`

Neste exemplo, todos os botões terão a mesma cor aplicadas por `color`, `colorDisabled primaryButtonTextColor, whiteButtonTextColor, dangerButtonTextColor`.

- Outra forma, é aplicar uma cor específica para cada componente da tela, nesse caso o parceiro integrador irá informar uma cor para cada botão. Aplicar o estilo para um item específico:​


”componentNameByScreenExample": {​

"textButtonColor": "#000000",​

"backgroundButtonColor": "#FFFFFF",​

"borderButtonColor": "#000000"​

}​

Importante ressaltar que o nome dos campo não pode ser alterado, apenas as cores hexadecimais.

Para essa segunda forma de implementação, deve ser configurado da seguinte forma:

- Para customizar o app, temos um arquivo JSON com campos específicos, abaixo descriminado cada campo nas telas:

### Inserir valor

![Inserir valor da venda.png](images-android/img_22.png)

1-`insertValueHeader` → `buttonBackColor`

2-`insertValueInput` → `labelColor`

3-`insertValueInput` → `inputValueColor`

4- `insertValueInput` → `currencyColor`

5- `insertValueButtonNext` → `textColor` (para mudar a cor do texto dentro do botão) `textColorDisabled` (cor do texto do botão desabilitado),`color`(botão ativo) e `colorDisabled`(botão desativado)

### Selecionar forma de pagamento

1- `selectPaymentTypeHeader` → `buttonBackColor`

2- `selectPaymentTypeHeader` → `buttonHelpColor`

2.a- Para controlar a visibilidade deste botão adicione a chave `selectPaymentTypeHeader` → `buttonHelpVisibility` para os valores true ou false.

3- `selectPaymentTypeHeader` → `textColor`

4- `selectPaymentTypeTextAmount` → `colorText`

5- `selectPaymentTypeAmount` → `colorText`

6- `selectPaymentTypeTitleOptions` → `colorText`

7- `selectPaymentTypeOptionsItem` → `borderColor` (item não selecionado) e `borderSelectedColor` (item selecionado)

8- `selectPaymentTypeOptionsItem` → `itemTextColor` (item não selecionado) e `itemTextSelectedColor` (item selecionado)

9- `selectPaymentTypeOptionsItem` → `itemRadioColor`(item não selecionado) e `itemRadioSelectedColor` (item selecionado)

10-`selectPaymentItemTitleInstallments` → `colorText`

11- `selectPaymentItemTitleInstallmentsIcon` → `color`

12- `selectPaymentItemTitleInstallmentsValues` → `colorText`

13- `selectPaymentItemTitleInstallmentsOpen` → `color`

14- `selectPaymentTypeButtonPayment` → `textColor` (para mudar a cor do texto dentro do botão) `textColorDisabled` (cor do texto do botão desabilitado),`color`(botão ativo) e `colorDisabled`(botão desativado)

15- `selectPaymentTypeItemInstallments` → `backgroundColor`

### Modal Parcelas

1- `selectPaymentTypeParcelOptions` → `titleBottomSheetColor`

2- `selectPaymentTypeParcelOptions` → `itemsTextColor` (parcela não selecionada) e `itemsTextSelectedColor` (parcela selecionada)

3- `selectPaymentTypeParcelOptions` → `buttonColor` (botão ativo) e `buttonDisabledColor` (botão desativado), `buttonEnableTextColor` (cor do texto habilitado) e `buttonDisableTextColor` (cor do texto do botão desabilitado)

4- `selectPaymentTypeParcelOptions` → `closeIconColor`

5- `selectPaymentTypeParcelOptions` → `itemsRadioColor` (parcela não selecionada) e `itemsRadioSelectedColor` (parcela selecionada)

### Leitura do cartão

1- `payment` → no método logoImageRes do [initPayment](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-InitPayment)

2- `payment` → `textColor`

3- `payment` → `backgroundColor (aplicado para alterar background, no momento cinza)`

### Comprovante de pagamento/cancelamento

1- `receiptView`→ `backgroundColor`

2- `receiptShareButton`→ `textButtonColor`

3- `receiptShareButton`→ `backgroundButtonColor`

4- `receiptShareButton`→ `borderButtonColor`

5- `receiptNewPaymentMySalesButton`→ `textButtonColor`

6- `receiptNewPaymentMySalesButton`→ `backgroundButtonColor`

7- `receiptNewPaymentMySalesButton`→ `borderButtonColor`

8- `receiptCloseButton` → `color`

### Tela de Erro na initialização

1- `initialize_feedback_error`→ `textColor`

2- `initialize_feedback_error`→ `textColorSubtitle`

3- `initialize_feedback_error`→ `textColorMoreInformation`

4- `initialize_feedback_error`→ `buttonTextColor, buttonBackgroundColor`

**Tela de feedback do pagamento ( error / sucesso)**

1 - `paymentFeedback`→ `textColorDescription`

2 - `paymentFeedback`→ `textColorSubDescription`

3 - `paymentFeedback`→ `textColor`

4 - `paymentFeedback`→ `textColorSubtitle`

5 - `paymentFeedback`→ `buttonTextColor`

6 - `paymentFeedback`→ `buttonBackgroundColor`

### Minhas vendas

1-`mySalesHeader`→ `buttonBackColor`

2-`mySalesHeader`→ `textColor`

1-`mySalesItemStatus`→ `colorTextStatusApproved, colorBackgroundApproved, colorTextStatusCanceled, colorBackgroundCanceled, colorTextStatusContested, colorBackgroundContested`

2-`mySalesItemDateOrHour`→ `colorText`

3-`mySalesItemPaymentType`→ `colorText`

4-`mySalesItemAmount`→ `colorText`

1-`mySalesErrorLabel`→ `colorText`

2-`mySalesErrorButton`→ `textButtonColor`

3-`mySalesErrorButton`→ `backgroundButtonColor`

4- `mySalesErrorButton`→ `borderButtonColor`

1-`mySalesEmptyListLabel`→ `colorText`

### Comprovante de Cancelamento

1- `saleDetailsHeader` → `buttonBackColor`

2- `saleDetailsHeader` → `buttonShareColor`, para customizar a cor do botão desativado incremente a chave `buttonShareDisabledColor`

3- `saleDetailsHeader` → `textColor`

4- `saleDetailsLabel`→ `colorText`

5- `saleDetailsValues` → `colorText`

6- `saleDetailsExplanationAmountReceived`→ `colorText`

7- `saleDetailsCancelSaleButton` → `textButtonColor`

8-`saleDetailsCancelSaleButton` → `borderButtonColor`

### Modal cancelamento de venda

![image-20240816-174856.png](images-android/img_18.png)

1- `wantCancelTitle`→ `colorText`

2- `wantCancelDescription`→ `colorText`

3- `wantCancelButtonConfirmCancel`→ `textColor`

4- `wantCancelButtonConfirmCancel`→ `color`

5- `wantCancelButtonBack`→ `textColor`

6- `wantCancelButtonBack`→ `color`

### Status Bar em todas as telas

![image-20240815-135857.png](images-android/img_26.png)

1- `statusBar`→ `backgroundColor`

### Educacional

1- `educationCloseButton`→ `color`

2- `educationTitle`→ `colorText`

3- `educationDescription`→ `colorText`

4- `educationPreviousPageButton`→ `backgroundButtonColor`, `borderButtonColor` e `iconColorButton`

5- `navigationDotsIndicator`→ `dotColorActive` e `dotColorInactive`

6- `educationNextPageButton`→ `backgroundButtonColor`, `borderButtonColor` e `iconColorButton`

7- `educationFinishButton`→ `textButtonColor`, `backgroundButtonColor`, `borderButtonColor`

8- `educationIcons`→ `imageBackgroundLayer1`, `imageBackgroundLayer2` e `imageBackgroundLayer3`

Utilize o JSON abaixo como exemplo para alterar as cores:

## Componente Loading.

No componente de loading é possível realizar a customização de cores, intervalo de troca de textos e textos. Também é possível fazer referência de textos que estão dentro do arquivos de strings.xml, segue exemplo de como é possível fazer a referência.

**strings.xml:**

No json do whitelabel deve ser incluído o “@” como prefixo conforme o exemplo abaixo:

Dessa forma teremos o seguinte resultado:

# Tratamento de erros

Durante a integração do Tap on Phone, **podem ocorrer erros** caso algum passo não seja executado corretamente, por exemplo, falha na inicialização do SDK ou envio de valores inválidos para uma transação.

É importante que o parceiro integrador prepare sua aplicação para mapear esses erros e notificar o usuário da melhor forma possível.

### 1 - Exibição de telas de erro

Em vista disso, para tornar mais claro ao usuário o motivo do erro ocorrido, o SDK do Tap on Phone conta com telas de erro padronizadas.

Essas telas seguem o mesmo padrão visual e de usabilidade, alterando apenas o conteúdo exibido, conforme o tipo de erro identificado.

A estrutura da tela é composta pelos seguintes elementos:


![image-20251106-141231.png](images-android/img_25.png)

### 2 - Inicialização do SDK

O código de inicialização segue o padrão abaixo:

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()
tapOnPhoneSdk.initialize(
context = this,
config,
onInitializeStart = {},
onInitializeSuccess = {},
onInitializeFailure = {exception -> },
useDefaultLoading = false,
)
```

Caso ocorra algum problema durante a inicialização, o callback `onInitializeFailure` será acionado, retornando uma exception com o tipo de falha ocorrido.

A seguir, listamos as possíveis exceptions que podem ser retornadas, divididas em dois grupos: **Com tela** (exibem mensagem padrão ao usuário) e **Sem tela** (devem ser tratadas pela aplicação integradora).

### 3 - Exceptions da inicialização

### Exceptions com tela:

Essas exceptions disparam automaticamente uma tela informativa padrão ao usuário final.

**Exceptions**

**ProblemToInitializerException**

**Descrição**

Usado quando o método initialize é chamado e pelos seguintes motivos houve um erro (com mensagem genérica para usuário do app):

- Regras diversas do servidor (Ex: Segurança, Validação de cliente, Validação de versão, Integração com terceiros Cielo).

---

### Exceptions sem tela:

Essas exceptions não exibem interface automaticamente.

Cabe à aplicação integradora interceptar e tratar o erro, apresentando a mensagem ou ação adequada ao usuário.

**Exceptions**

**DeviceIncompatibleException**

**Descrição**

Quando o dispositivo não é compatível com as regras do SDK. Segue abaixo um enum do que poderá ser retornado pela exception:

```kotlin
enum class DeviceIncompatibleEnum {
DEVICE_IS_EMULATOR, //O dispositivo usado é um emulador
DEVICE_IS_ROOT, //O dispositivo está com root
DEVICE_IS_DEV_MODE, //O dispositivo está com o modo de desenvolvimento ativo
DEVICE_PROBLEM_WITH_NFC, //Ocorreu um problema com o NFC 
DEVICE_WITH_VERSION_OS_INCOMPATIBLE, //O dispositivo está com o SO android inferior ao mínimo
}
```

---

**CheckIsTerminalActiveException**

Quando o método `initialize` é chamado, e durante o processo de ativação do terminal houver algum erro para verificar ou criar o terminar para o pagamento.

---

**SecurityCheckException**

Usado quando ocorre falha na coleta de informações de segurança. Esse item pode ser emitido em todos os métodos menos no `initJourney`.

---

**VersionInvalidException**

Usado quando a versão usada do SDK não é mais válida, sendo necessário realizar a atualização do SDK.

---

**WhiteLabelException**

Quando ocorre alguma falha no whiteLabel, algum dos exemplos seriam a falha ao encontrar o arquivo json, falha na sintaxe do arquivo, etc.

---

### 4 - Erros no transacional

Após o `initialize` do SDK, o parceiro pode iniciar o fluxo de pagamento por meio da função `initPayment` ou cancelamento através de `initCancellation`.

```kotlin
val tapOnPhoneSdk = TapOnPhone.getInstance()
tapOnPhoneSdk.initPayment(
context = this,
config,
onPaymentStart = {},
onPaymentSuccess = {},
onPaymentFailure = {callback, exception -> },
onNewSale = {}
)
```

Caso a função `initPayment` seja chamada sem informar corretamente os valores no parâmetro initialData, como price, paymentMethod ou installments, será lançada a seguinte **exception** em **onPaymentFailure**.

**Exception**

**InitialDataInvalidException **

**Descrição**

Valores do initialData informados incorretamente.

---

Durante a inicialização da transação `initPayment`, se ocorrer qualquer falha na operação financeira, o parceiro será notificado por meio do **callback **em **onPaymentFailure**.

Esse callback retorna um dos erros listados no enum ErrorsPaymentEnum, representando o tipo de falha identificada durante o processo.

### 5 - Callbacks do transacional

Os erros retornados pelo onPaymentFailure podem ser divididos entre callbacks com tela implementada (o SDK exibe mensagem padrão ao usuário) e callbacks sem tela (devem ser tratados pela aplicação integradora).

### Callbacks com tela:

Essas exceptions disparam automaticamente uma tela informativa padrão ao usuário final.

**Callbacks**

**PAYMENT_CANCEL**

**Descrição**

Ocorre quando o usuário cancela a transação durante a etapa de aproximação do cartão, resultando na interrupção do fluxo e na invalidação do pagamento

---

**TIME_EXPIRED**

Ocorre quando o tempo limite para concluir o pagamento é atingido durante a etapa de aproximação do cartão.

---

**WITHOUT_SPACE_IN_DISK**

Quando não há espaço livre para o armazenamento da transação no `initPayment`.

---

**PROBLEM_GENERIC**

Será invocado quando houver falha não especificada durante a tentativa de concluir o pagamento.

---

**PROBLEM_TO_MAKE_TRANSACTION**

Será invocado quando houver algum erro não esperado ao iniciar a tentativa de concluir o pagamento.

---

### Callbacks sem tela:

Esses callbacks não exibem interface automaticamente.

É responsabilidade da aplicação integradora capturar o evento e definir como informar o usuário ou registrar o erro internamente.

**Callbacks**

**PROBLEM_TO_INITIALIZER**

**Descrição**

Quando a função `initPayment` ou `initCancellation` é chamada, e houve um erro na inicialização.

---

**TRANSACTION_BIGGER_OR_EQUALS_THEN_45_DAYS**

Ocorre quando é solicitado o cancelamento de uma transação cuja data ultrapassa o limite de 45 dias.

---

**TRANSACTION_WITH_STATUS_DIFFERENT_OF_APPROVED**

Quando o cancelamento é chamado mas o status do pagamento é diferente de aprovado.

---

**FAIL_TO_SAVE_LOCAL**

Quando ocorrer um falha no salvamento local.

A transação é cancelada com sucesso, porém houve erro para atualizar o status (haverá tentativa de atualizar localmente na próxima consulta).

---

**DUPLICATE_CALL_SDK**

Bloqueio de chamadas duplicadas.

Quando uma chamada está em andamento, novas chamadas são temporariamente bloqueadas para evitar duplicidade. Assim que a chamada atual for concluída, o sistema libera a execução de novas chamadas.

---


# Logs

Abaixo segue todos os logs disponíveis, esse logs foram obtidos através do evento onLogs do [método initializer](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/3354656955/Manual+de+integra+o+Android#M%C3%A9todo-Inicialize).

### **Conclusão**

Este guia forneceu uma visão geral dos requisitos do SDK Android e de como pode ser feita a sua inicialização e customização.
