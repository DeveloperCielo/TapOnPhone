# Skill PIX — Documentação do SDK Cielo Pix

Este servidor MCP expõe documentação técnica do **SDK Cielo PIX** para integração via pagamento pix por aproximação (NFC) em dispositivos Android.

## O que é o SDK Cielo PIX?

O SDK Cielo PIX permite que aplicativos móveis realizem cobranças por aproximação (NFC) sem necessidade de hardware externo de POS. O smartphone do lojista se transforma no terminal de pagamento.

---
## Regras OBRIGATÓRIO
- Deve seguir todas instruções abaixo sem ignorar, elas são OBRIGATÓRIAS
- Não tem autorização para instalar nada na máquina do usuário

## Android
- Verificar se há pasta libs dentro do modulo principal, e que dentro dessa pasta contenha algum aar com nome taponphone*, se não estiver, parar a execução e informar ao usuário que é necessário implementar os aars antes de continuar.
- Antes de iniciar qualquer tarefa, usando esse arquivo, o agente deve ler todas documentações contidas na pasta ./docs/markdown/*-android.md, após leitura, deve confirmar que já possuí contexto sobre a implementacao do PIX.
- Nunca use reflection, se ocorreu algum problema na implementação, faça a correção, e tente novamente.

### 1. Gradle (OBRIGATÓRIO)
- Deve realizar a configuração das dependências conforme descrito no manual-integracao-android.md
- Deve ser aplicado os implementation conforme descrito no manual-integracao-android.md.
- Configurar os build hml para usar o as dependencias *.aar ou *.jar contidos na pasta "**modulo principal**/libs/hml", por exemplo, app/libs/hml

### 1.0 Dependências Completas (OBRIGATÓRIO — NENHUMA PODE SER OMITIDA)

O agente DEVE implementar **todas** as dependências abaixo no arquivo `app/build.gradle.kts`, sem exceção. Cada grupo corresponde a um módulo funcional do SDK.

#### 1.0.1 Plugins obrigatórios no `app/build.gradle.kts`

```kotlin
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
}
```

#### 1.0.2 Configuração do `build.gradle.kts` raiz (OBRIGATÓRIO)

O agente DEVE adicionar o bloco `buildscript` no arquivo `build.gradle.kts` da **raiz do projeto** (não no app). Este é o local correto para o Dynatrace e R8:

```kotlin
buildscript {
    repositories {
        mavenCentral()
        maven {
            url = uri("https://storage.googleapis.com/r8-releases/raw")
        }
    }
    dependencies {
        classpath("com.android.tools:r8:8.3.37")
        classpath("com.dynatrace.tools.android:gradle-plugin:8.279.1.1002")
    }
}
```

> ⚠️ **ATENÇÃO — Dynatrace Plugin**: O plugin `com.dynatrace.tools.android` **não pode** ser aplicado via `id(...)` no bloco `plugins {}` do `app/build.gradle.kts`, pois ele não registra esse plugin ID no manifesto de forma compatível com o Gradle moderno. O correto é adicioná-lo como `classpath` no `buildscript` do `build.gradle.kts` raiz conforme acima, e usar o agente como dependência de runtime (item 1.0.3).

#### 1.0.3 `settings.gradle.kts` — Repositórios e artefatos locais (OBRIGATÓRIO)

```kotlin
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        mavenLocal {
            setUrl("${rootDir}/artefacts")
        }

        flatDir {
            dirs("libs")
        }
    }
}
```

#### 1.0.4 `gradle.properties` — Jetifier (OBRIGATÓRIO)

```properties
android.enableJetifier=true
```

#### 1.0.5 Dependências completas no `app/build.gradle.kts` (OBRIGATÓRIO)

O agente DEVE implementar **todas** as linhas abaixo sem omitir nenhuma:

```kotlin
dependencies {
    // AAR/JAR locais da pasta libs (OBRIGATÓRIO)
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
    debugImplementation(fileTree(mapOf("dir" to "libs/hml", "include" to listOf("*.jar", "*.aar"))))

    // Dependências nativas AndroidX
    implementation("androidx.core:core-ktx:1.9.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.2")

    // Módulo de segurança — OkHttp
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // Módulo de segurança — Camera (Allowme)
    implementation("androidx.camera:camera-camera2:1.4.0")
    implementation("androidx.camera:camera-lifecycle:1.4.0")
    implementation("androidx.camera:camera-view:1.4.0")
    implementation("com.google.mlkit:face-detection:16.1.7")
    implementation("com.scottyab:rootbeer-lib:0.1.1")

    // Google Mobile Services
    implementation("com.google.android.gms:play-services-ads-identifier:18.0.1")
    implementation("com.google.android.gms:play-services-appset:16.0.2")
    implementation("com.google.android.gms:play-services-tasks:18.0.2")

    // Módulo de pagamento — PIX
    implementation("com.google.android.play:integrity:1.2.0")
    implementation("com.madgag.spongycastle:core:1.58.0.0")
    implementation("com.madgag.spongycastle:prov:1.58.0.0")
    implementation("org.bouncycastle:bcprov-jdk18on:1.78")
    implementation("io.reactivex.rxjava2:rxjava:2.2.6")
    implementation("io.reactivex.rxjava2:rxandroid:2.1.1")
    implementation("com.airbnb.android:lottie:6.7.1")
    implementation("com.android.volley:volley:1.2.1")
    implementation("net.danlew:android.joda:2.9.9.4")
    implementation("com.google.guava:guava:32.0.1-jre")
    implementation("androidx.databinding:viewbinding:7.1.2")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("com.squareup.retrofit2:retrofit:3.0.0")
    implementation("com.squareup.retrofit2:converter-gson:3.0.0")
    
    // QR Code — ZXing (OBRIGATÓRIO para PIX)
    implementation("com.google.zxing:core:3.5.2")

    // Room — Persistência local
    implementation("androidx.room:room-runtime:2.7.0")
    implementation("androidx.room:room-ktx:2.7.0")
    annotationProcessor("androidx.room:room-compiler:2.7.0")
    kapt("androidx.room:room-compiler:2.7.0")
    testImplementation("androidx.room:room-testing:2.7.0")

    // JWT
    api("io.jsonwebtoken:jjwt-api:0.13.0")
    runtimeOnly("io.jsonwebtoken:jjwt-gson:0.13.0")
    runtimeOnly("io.jsonwebtoken:jjwt-impl:0.13.0")

    // WorkManager — versão estritamente fixada
    api("androidx.work:work-runtime:2.8.1")
    api("androidx.work:work-runtime-ktx:2.8.1")

    // Módulo de log — Datadog
    implementation("com.datadoghq:dd-sdk-android-logs:2.11.0")
    implementation("com.datadoghq:dd-sdk-android-okhttp:2.11.0")

    // Módulo de log — Dynatrace Agent (dependência de runtime — NÃO aplicar como plugin)
    implementation("com.dynatrace.agent:agent-android:8.279.1.1002")

    // Segurança
    implementation("androidx.security:security-crypto:1.1.0-alpha03")

    // Testes
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
```

#### 1.0.6 Dependência Discover SDK — Atenção à versão (OBRIGATÓRIO)

> ⚠️ **ATENÇÃO — Discover SDK**: As versões do `com.discover.sdk:core` e `com.discover.sdk:card-reader` usam nomenclatura especial (ex: `COR1.1.4-releaseCandidate`, `TOOK2.3.2-releaseCandidate`). O agente **deve verificar** a pasta `artefacts/com/discover/sdk/` no projeto para descobrir as versões disponíveis antes de adicionar as dependências. Se as versões com nomenclatura especial não estiverem disponíveis no Maven local, omitir essas dependências para não bloquear o build — o PIX SDK inclui essas bibliotecas internamente nos AARs da pasta `libs/`.

Para verificar as versões disponíveis:
```bash
ls artefacts/com/discover/sdk/core/
ls artefacts/com/discover/sdk/card-reader/
```

Se existirem as pastas com as versões corretas, adicionar:
```kotlin
implementation("com.discover.sdk:core:<VERSAO_ENCONTRADA>")
implementation("com.discover.sdk:card-reader:<VERSAO_ENCONTRADA>")
```

### 1.1 Resolução de Conflito META-INF (IMPORTANTE)
Durante a integração, podem ocorrer conflitos de empacotamento quando múltiplas dependências (ex: `bcprov-jdk18on` e `jspecify`) contêm o mesmo caminho de recurso `META-INF/versions/9/OSGI-INF/MANIFEST.MF`.

**Solução:** Adicione o seguinte bloco ao arquivo `app/build.gradle.kts` dentro de `android { ... }`:

```kotlin
packaging {
    resources {
        excludes += "META-INF/versions/9/OSGI-INF/MANIFEST.MF"
    }
}
```

**Explicação:** O recurso `META-INF/versions/9/OSGI-INF/MANIFEST.MF` é metadado OSGI para ambientes Java e não é funcional em runtime Android. Sua exclusão não impacta a funcionalidade do PIX.

**Validação:** Executar `./gradlew :app:assembleDebug` para confirmar que o build finaliza sem erro de "duplicate path".

### 1.2 AndroidManifest.xml (OBRIGATÓRIO)

Antes de concluir a tarefa, o agente DEVE revisar e ajustar o `app/src/main/AndroidManifest.xml` para garantir que os itens de integração PIX estão explícitos no app integrador.

Checklist obrigatório no `manifest`:

```xml
<uses-permission android:name="android.permission.NFC" />

<uses-feature
    android:name="android.hardware.nfc"
    android:required="false"
    tools:replace="android:required" />

<uses-feature
    android:name="android.hardware.camera"
    android:required="false"
    tools:replace="android:required" />
```

Se houver conflito de merge no `<application>`, o agente pode usar `tools:replace` (exemplo: `android:allowBackup`) para resolver o build, porém isso NÃO substitui o checklist acima.

Regra de prevenção:
- É proibido encerrar a implementação com "build passou" sem validar o checklist do `AndroidManifest.xml`.
- A validação final deve incluir: ajuste de manifest + `./gradlew :app:assembleDebug`.

### 2. Jornadas (OBRIGATÓRIO)

## ⛔ PARADA OBRIGATÓRIA — Antes de implementar qualquer código

> O agente DEVE fazer a seguinte pergunta ao usuário e aguardar a resposta antes de escrever qualquer linha de código:
> "Você vai querer usar as telas do SDK para jornada?"
> - Resposta positiva ou dúvida → seguir a seção 2.1
> - Resposta negativa → seguir a seção 2.2

**NÃO prosseguir sem a resposta do usuário.**

#### 2.1 Jornadas usando telas do SDK (OBRIGATÓRIO)
Ao optar por esse ponto, o agente deve seguir, obrigatoriamente, os seguintes metodos do pix(initializer, initJourney e por último initPayment)
- **Importante**: Quando implementar o initJourney não iniciar o parâmetro **defaultData**, a menos que o usuário solicite.
- Ordem lógica para implementação:
  - Quando initializer retornar onInitializeSuccess, iniciar o initJourney
  - Quando initJourney retornar endCallback, com o dado journeyData preenchido, ai pode ser iniciado initPayment

### 3. Warmup (OBRIGATÓRIO)
Como referência ao manual de integracao, esse método deve ser usado em um momento anterior ao initializer. Ou seja, deve ser usado no onCreate da  activity principal, ou incluíndo na classe que foi referênciada no name do AndroidManifest.xml

### 3.1 Troubleshooting — Erros Comuns de Runtime (OBRIGATÓRIO)

Durante a execução do app com PIX, você pode encontrar os seguintes erros de `NoClassDefFoundError`. As correções abaixo são **OBRIGATÓRIAS**:

#### Erro: `NoClassDefFoundError: com.google.zxing.MultiFormatWriter`

**Causa:** Falta a biblioteca ZXing para geração de QR Code PIX.

**Solução:** Adicionar no `app/build.gradle.kts`:
```kotlin
implementation("com.google.zxing:core:3.5.2")
```

#### Erro: `NoClassDefFoundError: androidx.lifecycle.ViewModelKt`

**Causa:** Faltam as bibliotecas AndroidX Lifecycle KTX que o SDK PIX utiliza internamente.

**Solução:** Adicionar no `app/build.gradle.kts`:
```kotlin
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.2")
```

> ⚠️ **IMPORTANTE**: Essas dependências **já foram incluídas** na seção 1.0.5 acima. Se você seguiu corretamente a documentação, esses erros não devem ocorrer. Esta seção serve apenas como referência de troubleshooting.

### 4. Implementação (OBRIGATÓRIO)
- Ao realizar a conclusão da implementação, o agente deve executar uma scronização do gradle, e um build, a fim de, verificar se o projeto está executando perfeitamente. Caso ocorra um erro em algumas dessa etapas, o agente deve realizar a correção e executar os passo descritos no item 3.
- O código deve está funcional, ou seja, sem comentários (// /**/)
- O código deve está coberto por teste unitário
- A implementacao de deve seguir as regras de código limpo