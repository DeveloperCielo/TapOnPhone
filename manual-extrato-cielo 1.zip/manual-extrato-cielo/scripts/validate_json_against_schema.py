import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser(description="Valida JSON contra JSON Schema")
    parser.add_argument("--schema", required=True, help="Arquivo schema JSON")
    parser.add_argument("--data", required=True, help="Arquivo JSON de dados")
    args = parser.parse_args()

    try:
        import jsonschema  # type: ignore
    except Exception:
        print(json.dumps({"status": "error", "error": "missing_dependency:jsonschema"}, ensure_ascii=False, indent=2))
        return 1

    schema_path = Path(args.schema)
    data_path = Path(args.data)

    if not schema_path.exists() or not data_path.exists():
        print(json.dumps({"status": "error", "error": "missing_input_file"}, ensure_ascii=False, indent=2))
        return 1

    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    data = json.loads(data_path.read_text(encoding="utf-8"))

    try:
        jsonschema.validate(instance=data, schema=schema)
    except Exception as exc:
        print(json.dumps({"status": "error", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1

    print(json.dumps({"status": "ok", "schema": str(schema_path), "data": str(data_path)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
