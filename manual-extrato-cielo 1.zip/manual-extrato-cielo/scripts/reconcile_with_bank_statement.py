import argparse
import csv
import json
from pathlib import Path


def _to_float(raw: str) -> float | None:
    if raw is None:
        return None
    value = raw.strip().replace(".", "").replace(",", ".")
    # If already decimal with dot, previous replace can break thousands; fallback plain parse.
    try:
        return float(raw.strip().replace(",", "."))
    except Exception:
        try:
            return float(value)
        except Exception:
            return None


def _amount_cents(v: float) -> int:
    return int(round(v * 100))


def _load_bank_csv(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for i, row in enumerate(reader, start=1):
            amount = _to_float(row.get("valor", ""))
            if amount is None:
                continue
            rows.append(
                {
                    "line": i,
                    "data_movimento": (row.get("data_movimento") or "").strip(),
                    "valor": amount,
                    "valor_centavos": _amount_cents(amount),
                    "descricao": (row.get("descricao") or "").strip(),
                    "documento": (row.get("documento") or "").strip(),
                }
            )
    return rows


def _load_reconciliation(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _index_edi_amounts(recon: dict) -> dict:
    idx = {}

    # Bank validation scope from manual:
    # - CIELO04 (represented in sales/payment cycle)
    # - CIELO16 (represented in Pix cycle)
    # - CIELO03 only for TC D0 (operationally treated via scope/configuration)
    # NRC negotiation tracks (CIELO15) are intentionally excluded from direct bank validation index.
    for item in recon.get("ciclo_venda_pagamento", []):
        val = int(item.get("valor_liquido_d_total", 0))
        idx.setdefault(val, []).append({"source": "ciclo_venda_pagamento", "key": item.get("chave_conciliacao", "")})

    for item in recon.get("ciclo_pix", []):
        val = int(item.get("valor_liquido_total", 0))
        idx.setdefault(val, []).append({"source": "ciclo_pix", "key": item.get("id_pix", "")})

    return idx


def reconcile_bank(recon: dict, bank_rows: list[dict], tolerance_cents: int = 1) -> dict:
    edi_index = _index_edi_amounts(recon)
    matched = []
    unmatched_bank = []
    used = set()

    for row in bank_rows:
        cent = row["valor_centavos"]
        found = None
        for delta in range(-tolerance_cents, tolerance_cents + 1):
            candidates = edi_index.get(cent + delta, [])
            for cand in candidates:
                ref = (cand["source"], cand["key"], cent + delta)
                if ref not in used:
                    used.add(ref)
                    found = {"edi": cand, "amount_centavos": cent + delta}
                    break
            if found:
                break

        if found:
            matched.append(
                {
                    "bank": row,
                    "edi_source": found["edi"]["source"],
                    "edi_key": found["edi"]["key"],
                    "edi_amount_centavos": found["amount_centavos"],
                }
            )
        else:
            unmatched_bank.append(row)

    all_edi_refs = []
    for amount, candidates in edi_index.items():
        for cand in candidates:
            all_edi_refs.append((cand["source"], cand["key"], amount))

    unmatched_edi = [
        {"source": source, "key": key, "amount_centavos": amount}
        for (source, key, amount) in all_edi_refs
        if (source, key, amount) not in used
    ]

    return {
        "summary": {
            "bank_rows": len(bank_rows),
            "matched": len(matched),
            "unmatched_bank": len(unmatched_bank),
            "unmatched_edi": len(unmatched_edi),
            "tolerance_cents": tolerance_cents,
        },
        "matched": matched,
        "unmatched_bank": unmatched_bank,
        "unmatched_edi": unmatched_edi,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Concilia resultado EDI canonico com extrato bancario CSV")
    parser.add_argument("--recon", required=True, help="Arquivo JSON de resultado de conciliacao canonica")
    parser.add_argument("--bank-csv", required=True, help="Arquivo CSV bancario com colunas data_movimento,valor")
    parser.add_argument("--out", required=True, help="Arquivo de saida JSON")
    parser.add_argument("--tolerance-cents", type=int, default=1, help="Tolerancia em centavos para matching por valor")
    args = parser.parse_args()

    recon_path = Path(args.recon)
    bank_path = Path(args.bank_csv)
    out_path = Path(args.out)

    if not recon_path.exists() or not bank_path.exists():
        print(json.dumps({"status": "error", "error": "missing_input_file"}, ensure_ascii=False, indent=2))
        return 1

    recon = _load_reconciliation(recon_path)
    bank_rows = _load_bank_csv(bank_path)
    result = reconcile_bank(recon, bank_rows, args.tolerance_cents)

    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": "ok", "out": str(out_path), "summary": result["summary"]}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
