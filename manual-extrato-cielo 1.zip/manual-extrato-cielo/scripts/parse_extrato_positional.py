import argparse
import json
import re
from pathlib import Path


FILENAME_PATTERN = re.compile(r"^CIELO(?P<tipo>03|04|09|15|16)D_")


def _slice(line: str, ini: int, fim: int) -> str:
    return line[ini - 1 : fim]


def _to_int(value: str) -> int | None:
    raw = value.strip()
    if not raw.isdigit():
        return None
    return int(raw)


def _to_signed_int(sign: str, value: str) -> int | None:
    base = _to_int(value)
    if base is None:
        return None
    return -base if sign.strip() == "-" else base


def _detect_file_type(path: Path, header_line: str) -> str:
    by_name = ""
    m = FILENAME_PATTERN.match(path.name)
    if m:
        by_name = f"CIELO{m.group('tipo')}"

    by_header = ""
    m2 = re.search(r"CIELO(?P<tipo>\d{2})", header_line)
    if m2:
        by_header = f"CIELO{m2.group('tipo')}"

    return by_header or by_name


def _parse_record_0(line: str) -> dict:
    return {
        "record_type": "0",
        "estabelecimento_matriz": _slice(line, 2, 11).strip(),
        "data_processamento": _slice(line, 12, 19).strip(),
        "periodo_inicial": _slice(line, 20, 27).strip(),
        "periodo_final": _slice(line, 28, 35).strip(),
        "sequencia": _slice(line, 36, 42).strip(),
    }


def _parse_record_d(line: str) -> dict:
    return {
        "record_type": "D",
        "tipo_lancamento": _slice(line, 150, 151),
        "chave_ur": _slice(line, 152, 251).strip(),
        "valor_liquido": _to_signed_int(_slice(line, 100, 100), _slice(line, 101, 113)),
        "status_pagamento": _slice(line, 70, 71),
    }


def _parse_record_e(line: str) -> dict:
    return {
        "record_type": "E",
        "tipo_lancamento": _slice(line, 28, 29),
        "chave_ur": _slice(line, 30, 129).strip(),
        "codigo_ajuste": _slice(line, 152, 155).strip(),
        "codigo_transacao_recebida": _slice(line, 130, 151).strip(),
        "numero_transacao_processada": _slice(line, 605, 626).strip() if len(line) >= 626 else "",
        "valor_liquido": _to_signed_int(_slice(line, 275, 275), _slice(line, 276, 288)) if len(line) >= 288 else None,
    }


def _parse_record_8(line: str) -> dict:
    return {
        "record_type": "8",
        "tipo_transacao": _slice(line, 12, 13),
        "id_pix": _slice(line, 26, 61).strip(),
        "id_pix_original": _slice(line, 182, 217).strip() if len(line) >= 217 else "",
        "origem_ajuste": _slice(line, 220, 221).strip() if len(line) >= 221 else "",
        "status_transferencia": _slice(line, 223, 224).strip() if len(line) >= 224 else "",
        "valor_liquido": _to_signed_int(_slice(line, 102, 102), _slice(line, 103, 115)) if len(line) >= 115 else None,
    }


def _parse_record_a(line: str) -> dict:
    return {
        "record_type": "A",
        "data_negociacao": _slice(line, 2, 7),
        "data_pagamento": _slice(line, 8, 13),
        "cpf_cnpj": _slice(line, 14, 27).strip(),
        "numero_negociacao_registradora": _slice(line, 64, 83).strip(),
        "valor_bruto": _to_signed_int(_slice(line, 36, 36), _slice(line, 37, 49)),
        "valor_liquido": _to_signed_int(_slice(line, 50, 50), _slice(line, 51, 63)),
    }


def _parse_record_b(line: str) -> dict:
    return {
        "record_type": "B",
        "data_negociacao": _slice(line, 2, 7),
        "data_vencimento_original": _slice(line, 8, 13),
        "cpf_cnpj": _slice(line, 14, 27).strip(),
        "bandeira": _slice(line, 28, 30),
        "tipo_liquidacao": _slice(line, 31, 33),
        "valor_bruto": _to_signed_int(_slice(line, 34, 34), _slice(line, 35, 47)),
        "valor_liquido": _to_signed_int(_slice(line, 48, 48), _slice(line, 49, 61)),
        "numero_estabelecimento": _slice(line, 117, 126).strip(),
        "valor_desconto": _to_signed_int(_slice(line, 127, 127), _slice(line, 128, 140)),
    }


def _parse_record_c(line: str) -> dict:
    return {
        "record_type": "C",
        "banco": _slice(line, 2, 5),
        "agencia": _slice(line, 6, 10).strip(),
        "conta": _slice(line, 11, 30).strip(),
        "valor_depositado": _to_signed_int(_slice(line, 31, 31), _slice(line, 32, 44)),
    }


def _parse_record_9(line: str) -> dict:
    return {
        "record_type": "9",
        "total_registros_detalhe": _to_int(_slice(line, 2, 12)),
        "valor_liquido_total": _to_signed_int(_slice(line, 13, 13), _slice(line, 14, 30)),
        "quantidade_registros_e": _to_int(_slice(line, 31, 41)),
    }


def _parse_generic(record_type: str, line: str) -> dict:
    return {
        "record_type": record_type,
        "raw_length": len(line),
        "raw_preview": line[:80],
    }


def parse_extrato(path: Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    if not lines:
        return {"status": "error", "error": "empty_file", "file": str(path)}

    file_type = _detect_file_type(path, lines[0])

    records = []
    counts = {}
    for idx, line in enumerate(lines, start=1):
        rec = line[:1] if line else ""
        counts[rec] = counts.get(rec, 0) + 1

        if rec == "0":
            parsed = _parse_record_0(line)
        elif rec == "D":
            parsed = _parse_record_d(line)
        elif rec == "E":
            parsed = _parse_record_e(line)
        elif rec == "8":
            parsed = _parse_record_8(line)
        elif rec == "A":
            parsed = _parse_record_a(line)
        elif rec == "B":
            parsed = _parse_record_b(line)
        elif rec == "C":
            parsed = _parse_record_c(line)
        elif rec == "9":
            parsed = _parse_record_9(line)
        else:
            parsed = _parse_generic(rec, line)

        parsed["line"] = idx
        records.append(parsed)

    return {
        "status": "ok",
        "file": str(path),
        "file_type": file_type,
        "line_count": len(lines),
        "record_counts": counts,
        "records": records,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Parser posicional simplificado do Extrato Eletronico Cielo")
    parser.add_argument("--file", required=True, help="Caminho do arquivo .TXT")
    parser.add_argument("--out", help="Arquivo de saida JSON (opcional)")
    args = parser.parse_args()

    path = Path(args.file)
    if not path.exists():
        print(json.dumps({"status": "error", "error": f"file_not_found:{path}"}, ensure_ascii=False, indent=2))
        return 1

    result = parse_extrato(path)

    if args.out:
        out_path = Path(args.out)
        out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"status": result.get("status"), "out": str(out_path)}, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))

    return 0 if result.get("status") == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
