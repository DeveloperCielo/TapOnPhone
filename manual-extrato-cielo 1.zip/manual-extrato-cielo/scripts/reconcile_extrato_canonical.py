import argparse
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from parse_extrato_positional import parse_extrato


ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = ROOT / "exemplos"


def _coalesce_int(value: int | None) -> int:
    return int(value) if isinstance(value, int) else 0


def _concat_key(chave_ur: str, tipo_lancamento: str) -> str:
    return f"{chave_ur}|{tipo_lancamento}"


def _build_sales_payment_tracks(parsed_reports: list[dict]) -> tuple[list[dict], list[dict]]:
    d_totals = defaultdict(lambda: {"d": 0, "e": 0, "qd": 0, "qe": 0, "chave_ur": "", "tipo": ""})
    pending = []

    for report in parsed_reports:
        for rec in report.get("records", []):
            if rec.get("record_type") == "D":
                key = _concat_key(rec.get("chave_ur", ""), rec.get("tipo_lancamento", ""))
                agg = d_totals[key]
                agg["d"] += _coalesce_int(rec.get("valor_liquido"))
                agg["qd"] += 1
                agg["chave_ur"] = rec.get("chave_ur", "")
                agg["tipo"] = rec.get("tipo_lancamento", "")
            elif rec.get("record_type") == "E":
                key = _concat_key(rec.get("chave_ur", ""), rec.get("tipo_lancamento", ""))
                agg = d_totals[key]
                agg["e"] += _coalesce_int(rec.get("valor_liquido"))
                agg["qe"] += 1
                agg["chave_ur"] = rec.get("chave_ur", "")
                agg["tipo"] = rec.get("tipo_lancamento", "")

    tracks = []
    for key, agg in sorted(d_totals.items()):
        diff = agg["d"] - agg["e"]
        status = "ok"
        if agg["qd"] == 0 or agg["qe"] == 0:
            status = "parcial"
        elif diff != 0:
            status = "divergente"

        tracks.append(
            {
                "chave_conciliacao": key,
                "chave_ur": agg["chave_ur"],
                "tipo_lancamento": agg["tipo"],
                "valor_liquido_d_total": agg["d"],
                "valor_liquido_e_total": agg["e"],
                "divergencia": diff,
                "status": status,
                "qtd_registros_d": agg["qd"],
                "qtd_registros_e": agg["qe"],
            }
        )

        if status != "ok":
            sev = "high" if status == "divergente" else "medium"
            pending.append(
                {
                    "tipo": "ciclo_venda_pagamento",
                    "chave": key,
                    "descricao": f"status={status}; d={agg['d']}; e={agg['e']}",
                    "severidade": sev,
                }
            )

    return tracks, pending


def _build_pix_tracks(parsed_reports: list[dict]) -> tuple[list[dict], list[dict]]:
    by_id = defaultdict(lambda: {"sum": 0, "events": 0, "adj": 0, "origins": set()})
    pending = []

    for report in parsed_reports:
        for rec in report.get("records", []):
            if rec.get("record_type") != "8":
                continue
            id_pix = rec.get("id_pix", "")
            if not id_pix:
                continue
            agg = by_id[id_pix]
            agg["sum"] += _coalesce_int(rec.get("valor_liquido"))
            agg["events"] += 1
            if rec.get("tipo_transacao") in {"02", "03"}:
                agg["adj"] += 1
                origin = rec.get("id_pix_original", "")
                if origin:
                    agg["origins"].add(origin)

    tracks = []
    for id_pix, agg in sorted(by_id.items()):
        status = "ok"
        if agg["adj"] > 0 and not agg["origins"]:
            status = "incompleto"

        tracks.append(
            {
                "id_pix": id_pix,
                "valor_liquido_total": agg["sum"],
                "qtd_eventos": agg["events"],
                "qtd_ajustes": agg["adj"],
                "status": status,
                "ids_pix_origem": sorted(agg["origins"]),
            }
        )

        if status != "ok":
            pending.append(
                {
                    "tipo": "ciclo_pix",
                    "chave": id_pix,
                    "descricao": "ajuste Pix sem id_pix_original associado",
                    "severidade": "high",
                }
            )

    return tracks, pending


def _build_negotiation_tracks(parsed_reports: list[dict]) -> tuple[list[dict], list[dict]]:
    by_key = defaultdict(lambda: {"sum": 0, "qtd": 0, "numero": ""})

    for report in parsed_reports:
        for rec in report.get("records", []):
            rtype = rec.get("record_type")
            if rtype not in {"A", "B", "C"}:
                continue

            num_neg = rec.get("numero_negociacao_registradora", "")
            cpf_cnpj = rec.get("cpf_cnpj", "")
            data_neg = rec.get("data_negociacao", "")
            key = num_neg or f"{rtype}|{cpf_cnpj}|{data_neg}"
            agg = by_key[key]
            agg["qtd"] += 1
            agg["numero"] = num_neg
            if rtype == "A":
                agg["sum"] += _coalesce_int(rec.get("valor_liquido"))
            elif rtype == "B":
                agg["sum"] += _coalesce_int(rec.get("valor_liquido"))
            elif rtype == "C":
                agg["sum"] += _coalesce_int(rec.get("valor_depositado"))

    tracks = []
    pending = []
    for key, agg in sorted(by_key.items()):
        status = "ok" if agg["qtd"] > 1 else "parcial"
        tracks.append(
            {
                "chave_negociacao": key,
                "numero_negociacao_registradora": agg["numero"],
                "valor_liquido_total": agg["sum"],
                "qtd_registros": agg["qtd"],
                "status": status,
            }
        )
        if status != "ok":
            pending.append(
                {
                    "tipo": "ciclo_negociacao",
                    "chave": key,
                    "descricao": "trilha de negociacao parcial (poucos eventos correlacionados)",
                    "severidade": "low",
                }
            )

    return tracks, pending


def reconcile(files: list[Path]) -> dict:
    parsed = []
    arquivos_processados = []

    for file_path in files:
        report = parse_extrato(file_path)
        if report.get("status") != "ok":
            continue
        parsed.append(report)
        arquivos_processados.append(
            {
                "arquivo": file_path.name,
                "file_type": report.get("file_type", ""),
                "line_count": report.get("line_count", 0),
                "record_counts": report.get("record_counts", {}),
            }
        )

    ciclo_venda_pagamento, pend_venda = _build_sales_payment_tracks(parsed)
    ciclo_pix, pend_pix = _build_pix_tracks(parsed)
    ciclo_negociacao, pend_neg = _build_negotiation_tracks(parsed)

    pendencias = pend_venda + pend_pix + pend_neg

    return {
        "metadata": {
            "layout_version": "15.15",
            "gerado_em": datetime.now().isoformat(),
            "timezone": "America/Sao_Paulo",
            "fonte": "manual-extrato-cielo",
        },
        "arquivos_processados": arquivos_processados,
        "resumo": {
            "trilhas_venda_pagamento": len(ciclo_venda_pagamento),
            "trilhas_pix": len(ciclo_pix),
            "trilhas_negociacao": len(ciclo_negociacao),
            "pendencias_total": len(pendencias),
        },
        "ciclo_venda_pagamento": ciclo_venda_pagamento,
        "ciclo_pix": ciclo_pix,
        "ciclo_negociacao": ciclo_negociacao,
        "pendencias": pendencias,
    }


def _collect_input_files(input_paths: list[str], baseline: bool) -> list[Path]:
    if baseline:
        return sorted(EXAMPLES_DIR.glob("CIELO*.TXT"))

    out = []
    for raw in input_paths:
        p = Path(raw)
        if p.is_dir():
            out.extend(sorted(p.glob("CIELO*.TXT")))
        elif p.exists() and p.suffix.upper() == ".TXT":
            out.append(p)
    return out


def main() -> int:
    parser = argparse.ArgumentParser(description="Reconciliacao canonica do Extrato Eletronico Cielo")
    parser.add_argument("--inputs", nargs="*", default=[], help="Arquivos ou diretorios .TXT")
    parser.add_argument("--baseline", action="store_true", help="Usa exemplos baseline em exemplos/")
    parser.add_argument("--out", required=True, help="Arquivo de saida JSON")
    args = parser.parse_args()

    files = _collect_input_files(args.inputs, args.baseline)
    if not files:
        print(json.dumps({"status": "error", "error": "no_input_files_found"}, ensure_ascii=False, indent=2))
        return 1

    result = reconcile(files)
    out_path = Path(args.out)
    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(
        json.dumps(
            {
                "status": "ok",
                "out": str(out_path),
                "summary": result["resumo"],
                "input_count": len(files),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
