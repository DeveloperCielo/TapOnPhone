import hashlib
import json
import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = ROOT / "exemplos"
OUT_DIR = EXAMPLES_DIR / "snapshots"
NAME_RE = re.compile(r"CIELO(?P<tipo>\d{2})")


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _detect_file_type(header_line: str) -> str:
    match = NAME_RE.search(header_line)
    if not match:
        return ""
    return f"CIELO{match.group('tipo')}"


def _build_snapshot(path: Path) -> dict:
    lines = path.read_text(encoding="utf-8").splitlines()
    record_counts = {}
    for line in lines:
        rec = line[:1] if line else ""
        record_counts[rec] = record_counts.get(rec, 0) + 1

    details = [line for line in lines if line and line[:1] not in {"0", "9"}]
    sample_hashes = [_sha256(line) for line in details[:5]]

    return {
        "file": path.name,
        "file_type": _detect_file_type(lines[0] if lines else ""),
        "line_count": len(lines),
        "record_counts": record_counts,
        "content_sha256": _sha256("\n".join(lines) + "\n"),
        "first_5_detail_line_hashes": sample_hashes,
    }


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    files = sorted(EXAMPLES_DIR.glob("CIELO*.TXT"))
    if not files:
        print(json.dumps({"status": "error", "error": "no_baseline_examples_found"}, ensure_ascii=False, indent=2))
        return 1

    index = {
        "generated_at": "2026-07-17",
        "source_dir": str(EXAMPLES_DIR),
        "snapshots": [],
    }

    for path in files:
        snapshot = _build_snapshot(path)
        out_path = OUT_DIR / f"{path.stem}.snapshot.json"
        out_path.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
        index["snapshots"].append({"input": path.name, "snapshot": out_path.name})

    index_path = OUT_DIR / "index.json"
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({"status": "ok", "out_dir": str(OUT_DIR), "index": str(index_path)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
