import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXAMPLES_DIR = ROOT / "exemplos"
OUT_DIR = EXAMPLES_DIR / "mutantes"

BASE = {
    "CIELO03": EXAMPLES_DIR / "CIELO03D_1234567890_20260701_20260701_20260701.TXT",
    "CIELO04": EXAMPLES_DIR / "CIELO04D_1234567890_20260701_20260701_20260701.TXT",
    "CIELO16": EXAMPLES_DIR / "CIELO16D_1234567890_20260701_20260701_20260701.TXT",
}


def _read_lines(path: Path) -> list[str]:
    return path.read_text(encoding="utf-8").splitlines()


def _write_lines(path: Path, lines: list[str]) -> None:
    text = "\n".join(lines) + "\n"
    path.write_text(text, encoding="utf-8")


def _replace_char(line: str, idx: int, value: str) -> str:
    if idx < 0 or idx >= len(line):
        return line
    return line[:idx] + value + line[idx + 1 :]


def _replace_slice(line: str, start: int, end: int, value: str) -> str:
    if start < 0:
        start = 0
    if end > len(line):
        end = len(line)
    return line[:start] + value + line[end:]


def _first_idx(lines: list[str], record_type: str) -> int:
    for idx, line in enumerate(lines):
        if line.startswith(record_type):
            return idx
    return -1


def generate_mutants() -> dict:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    manifest = {
        "generated_at": "2026-07-17",
        "base_dir": str(EXAMPLES_DIR),
        "mutants": [],
    }

    # N01 - registro invalido por tipo de arquivo (inserir tipo 8 em CIELO04)
    lines = _read_lines(BASE["CIELO04"])
    invalid_8 = "8" + ("N01_INVALID_RECORD_IN_CIELO04".ljust(max(len(lines[0]) - 1, 1), " "))
    out = OUT_DIR / "N01-registro-invalido-tipo-8-em-cielo04.TXT"
    _write_lines(out, lines[:-1] + [invalid_8] + [lines[-1]])
    manifest["mutants"].append({"id": "N01", "file": str(out), "mutation": "insert_record_8_before_trailer"})

    # N02 - ausencia de header
    lines = _read_lines(BASE["CIELO04"])
    out = OUT_DIR / "N02-ausencia-header.TXT"
    _write_lines(out, lines[1:])
    manifest["mutants"].append({"id": "N02", "file": str(out), "mutation": "remove_first_header_line"})

    # N03 - ausencia de trailer
    lines = _read_lines(BASE["CIELO04"])
    out = OUT_DIR / "N03-ausencia-trailer.TXT"
    _write_lines(out, lines[:-1])
    manifest["mutants"].append({"id": "N03", "file": str(out), "mutation": "remove_last_trailer_line"})

    # N04 - linha truncada (primeiro E)
    lines = _read_lines(BASE["CIELO04"])
    idx_e = _first_idx(lines, "E")
    if idx_e != -1:
        lines[idx_e] = lines[idx_e][:120]
    out = OUT_DIR / "N04-linha-truncada-registro-E.TXT"
    _write_lines(out, lines)
    manifest["mutants"].append({"id": "N04", "file": str(out), "mutation": "truncate_first_E_record"})

    # N05 - valor numerico invalido (injeta letra em tipo de lancamento do registro E)
    lines = _read_lines(BASE["CIELO04"])
    idx_e = _first_idx(lines, "E")
    if idx_e != -1:
        lines[idx_e] = _replace_char(lines[idx_e], 27, "X")
    out = OUT_DIR / "N05-valor-numerico-invalido.TXT"
    _write_lines(out, lines)
    manifest["mutants"].append({"id": "N05", "file": str(out), "mutation": "inject_alpha_in_numeric_field"})

    # N06 - divergencia D x E (altera valor liquido de um registro E sem rebalancear D)
    lines = _read_lines(BASE["CIELO04"])
    idx_e = _first_idx(lines, "E")
    if idx_e != -1:
        lines[idx_e] = _replace_slice(lines[idx_e], 275, 288, "9999999999999")
    out = OUT_DIR / "N06-divergencia-DxE.TXT"
    _write_lines(out, lines)
    manifest["mutants"].append({"id": "N06", "file": str(out), "mutation": "mutate_detail_value_without_rebalancing_D"})

    # N07 - pix ajuste sem id_pix_original
    lines = _read_lines(BASE["CIELO16"])
    idx_8 = _first_idx(lines, "8")
    if idx_8 != -1:
        # Tipo de transacao (12-13) = 02 (ajuste)
        lines[idx_8] = _replace_slice(lines[idx_8], 11, 13, "02")
        # ID Pix original (182-217) vazio/zeros
        lines[idx_8] = _replace_slice(lines[idx_8], 181, 217, "0" * 36)
    out = OUT_DIR / "N07-pix-ajuste-sem-id-pix-original.TXT"
    _write_lines(out, lines)
    manifest["mutants"].append({"id": "N07", "file": str(out), "mutation": "blank_out_id_pix_original_segment"})

    # N08 - codigo de dominio desconhecido (tipo de transacao Pix fora do dominio)
    lines = _read_lines(BASE["CIELO16"])
    idx_8 = _first_idx(lines, "8")
    if idx_8 != -1:
        lines[idx_8] = _replace_slice(lines[idx_8], 11, 13, "99")
    out = OUT_DIR / "N08-codigo-dominio-desconhecido.TXT"
    _write_lines(out, lines)
    manifest["mutants"].append({"id": "N08", "file": str(out), "mutation": "replace_tipo_transacao_with_unknown_99"})

    return manifest


def main() -> int:
    missing = [str(path) for path in BASE.values() if not path.exists()]
    if missing:
        print(json.dumps({"status": "error", "missing_base_files": missing}, ensure_ascii=False, indent=2))
        return 1

    manifest = generate_mutants()
    manifest_path = OUT_DIR / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({"status": "ok", "out_dir": str(OUT_DIR), "manifest": str(manifest_path)}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
