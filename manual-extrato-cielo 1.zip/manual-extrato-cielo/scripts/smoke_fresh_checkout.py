import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _run(label: str, args: list[str]) -> dict:
    proc = subprocess.run(args, cwd=ROOT, text=True, capture_output=True)
    return {
        "label": label,
        "command": " ".join(args),
        "exit_code": proc.returncode,
        "stdout": proc.stdout.strip(),
        "stderr": proc.stderr.strip(),
        "status": "ok" if proc.returncode == 0 else "error",
    }


def main() -> int:
    example_file = "exemplos/CIELO04D_1234567890_20260701_20260701_20260701.TXT"
    parse_out = "exemplos/snapshots/parse-cielo04-smoke.json"
    recon_out = "exemplos/snapshots/resultado-conciliacao-smoke.json"

    steps = [
        ("validate_package", [sys.executable, "scripts/validate_manual_package.py"]),
        (
            "parse_file",
            [
                sys.executable,
                "scripts/parse_extrato_positional.py",
                "--file",
                example_file,
                "--out",
                parse_out,
            ],
        ),
        (
            "validate_file",
            [
                sys.executable,
                "scripts/validate_extrato_file.py",
                "--file",
                example_file,
            ],
        ),
        (
            "reconcile_baseline",
            [
                sys.executable,
                "scripts/reconcile_extrato_canonical.py",
                "--baseline",
                "--out",
                recon_out,
            ],
        ),
    ]

    results = []
    for label, command in steps:
        result = _run(label, command)
        results.append(result)
        if result["status"] != "ok":
            break

    all_ok = all(item["status"] == "ok" for item in results) and len(results) == len(steps)
    report = {
        "status": "ok" if all_ok else "error",
        "root": str(ROOT),
        "steps_total": len(steps),
        "steps_executed": len(results),
        "steps": results,
    }

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if all_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
