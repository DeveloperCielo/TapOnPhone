import json
from datetime import date
from pathlib import Path

from parse_extrato_positional import parse_extrato
from validate_extrato_file import validate_extrato


ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "exemplos"
MUTANTS = EXAMPLES / "mutantes"


BASELINES = [
    "CIELO03D_1234567890_20260701_20260701_20260701.TXT",
    "CIELO04D_1234567890_20260701_20260701_20260701.TXT",
    "CIELO09D_1234567890_20260701_20260701_20260701.TXT",
    "CIELO15D_1234567890_20260701_20260701_20260701.TXT",
    "CIELO16D_1234567890_20260701_20260701_20260701.TXT",
]


MUTANT_EXPECTATIONS = {
    "N01-registro-invalido-tipo-8-em-cielo04.TXT": {
        "kind": "error_contains",
        "token": "record_not_allowed_for_file_type",
    },
    "N02-ausencia-header.TXT": {
        "kind": "error_contains",
        "token": "first_record_must_be_header_0",
    },
    "N03-ausencia-trailer.TXT": {
        "kind": "error_contains",
        "token": "last_record_must_be_trailer_9",
    },
    "N04-linha-truncada-registro-E.TXT": {
        "kind": "error_contains",
        "token": "line_too_short_for_record_schema",
    },
    "N05-valor-numerico-invalido.TXT": {
        "kind": "error_contains",
        "token": "numeric_field_invalid",
    },
    "N06-divergencia-DxE.TXT": {
        "kind": "error_contains",
        "token": "R001_D_E_NET_MATCH",
    },
    "N07-pix-ajuste-sem-id-pix-original.TXT": {
        "kind": "error_contains",
        "token": "R002_PIX_ADJUSTMENT_MUST_LINK_SALE",
    },
    "N08-codigo-dominio-desconhecido.TXT": {
        "kind": "warning_contains",
        "token": "unknown_domain_code",
    },
}


def _contains(values: list[str], token: str) -> bool:
    return any(token in item for item in values)


def _eval_expectation(report: dict, expected: dict) -> tuple[bool, str]:
    kind = expected["kind"]
    token = expected["token"]

    errors = report.get("errors", [])
    warnings = report.get("warnings", [])

    if kind == "error_contains":
        ok = _contains(errors, token)
        return ok, f"expected error containing '{token}'"

    if kind == "warning_contains":
        ok = _contains(warnings, token)
        return ok, f"expected warning containing '{token}'"

    return False, f"unknown expectation kind:{kind}"


def run_suite() -> dict:
    results = {
        "metadata": {
            "date": str(date.today()),
            "baseline_count": len(BASELINES),
            "negative_count": len(MUTANT_EXPECTATIONS),
        },
        "baseline": [],
        "negative": [],
        "summary": {},
    }

    baseline_pass = 0
    for filename in BASELINES:
        path = EXAMPLES / filename
        _, report = validate_extrato(path)
        parser_report = parse_extrato(path)
        ok = report.get("status") == "ok" and parser_report.get("status") == "ok"
        if ok:
            baseline_pass += 1
        results["baseline"].append(
            {
                "file": filename,
                "passed": ok,
                "errors": report.get("errors", []),
                "warnings": report.get("warnings", []),
                "parser_file_type": parser_report.get("file_type"),
                "parser_record_counts": parser_report.get("record_counts", {}),
            }
        )

    negative_pass = 0
    for filename, expected in MUTANT_EXPECTATIONS.items():
        path = MUTANTS / filename
        _, report = validate_extrato(path)
        ok, reason = _eval_expectation(report, expected)
        if ok:
            negative_pass += 1
        results["negative"].append(
            {
                "file": filename,
                "passed": ok,
                "expectation": reason,
                "errors": report.get("errors", []),
                "warnings": report.get("warnings", []),
            }
        )

    total = len(BASELINES) + len(MUTANT_EXPECTATIONS)
    passed = baseline_pass + negative_pass
    results["summary"] = {
        "total": total,
        "passed": passed,
        "failed": total - passed,
        "baseline_passed": baseline_pass,
        "negative_passed": negative_pass,
        "status": "ok" if passed == total else "error",
    }
    return results


def main() -> int:
    out_file = EXAMPLES / f"homologation-suite-{date.today().strftime('%Y%m%d')}.json"

    result = run_suite()
    out_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"status": result["summary"]["status"], "report": str(out_file), "summary": result["summary"]}, ensure_ascii=False, indent=2))
    return 0 if result["summary"]["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
