# Orquestrador Inicial do Toolkit EDI Cielo

Este arquivo e o ponto de entrada unico para leitura da documentacao em Markdown.

## Objetivo

Guiar a execucao e o consumo dos documentos em ordem clara, sem depender de conhecimento tacito.

## Ordem oficial de leitura e execucao

1. Contexto geral
- `README.md`

2. Fluxo oficial de implantacao
- `docs/operacao/quickstart-implantacao.md`

3. Base tecnica para implementacao
- `docs/operacao/1.toolkit-uso-em-ia.md`
- `docs/prompts/7.prompt-implantacao-ai.md`

4. Contratos e referencia de dominio
- `2.manual-extrato-v15.15.schema.json`
- `3.schemas/`
- `4.tabelas/`
- `docs/core/5.manual-completo.md`
- `docs/core/6.glossario.md`

5. Operacao e suporte
- `docs/operacao/8.onboarding-operacional-cliente.md`
- `docs/operacao/integracao-bancaria-interface.md`
- `docs/operacao/troubleshooting-operacional.md`

6. Evidencias e testes
- `exemplos/README.md`
- `exemplos/cenarios-homologacao-leitor-edi.md`

## Sequencia de comandos recomendada

1. Validar estrutura:

```bash
python scripts/validate_manual_package.py
```

2. Validar consistencia documental:

```bash
python scripts/check_documentation_consistency.py
```

3. Rodar smoke tecnico:

```bash
python scripts/smoke_fresh_checkout.py
```

4. Rodar homologacao:

```bash
python scripts/run_homologation_suite.py
```

## Regra de uso

Toda nova documentacao `.md` deve:

1. Ser colocada dentro de `docs/` (ou `exemplos/` quando for evidencia de exemplo).
2. Ser adicionada nesta orquestracao com objetivo e ordem de leitura.
3. Ter paths validados por `check_documentation_consistency.py`.
