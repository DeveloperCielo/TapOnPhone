---
secao: "Registro E - Detalhe do Lancamento"
arquivos_aplicaveis: ["CIELO03", "CIELO04"]
versao_layout: "15.15"
campos_chave: ["chave_ur", "tipo_lancamento", "codigo_transacao_recebida"]
---

Use este chunk para consultas sobre conciliacao por UR e tipo de lancamento.

---
secao: "Registro 8 - Pix"
arquivos_aplicaveis: ["CIELO16"]
versao_layout: "15.15"
campos_chave: ["id_pix", "id_pix_original", "origem_ajuste"]
---

Use este chunk para fluxo de venda Pix, ajuste e estado de pagamento.

---
secao: "Tabela IX - Motivos de Ajuste"
arquivos_aplicaveis: ["CIELO03", "CIELO04", "CIELO16"]
versao_layout: "15.15"
campos_chave: ["codigo_motivo", "descricao", "descricao_canonica"]
---

Use este chunk para classificacao de ajustes com mapeamento canonico de descricao.

