# Troubleshooting Operacional - EDI Cielo

## Objetivo

Acelerar diagnostico de incidentes em producao com passos reproduziveis.

## Fluxo rapido de diagnostico

1. Validar arquivo recebido
- Rodar `validate_extrato_file.py --file ...`
- Se erro estrutural: tratar antes de qualquer conciliacao.

2. Validar regressao do pacote
- Rodar `run_homologation_suite.py`
- Se suite falhar: bloquear deploy da mudanca.

3. Validar conciliacao canonica
- Rodar `reconcile_extrato_canonical.py`
- Inspecionar `pendencias` por severidade.

4. Validar lado banco
- Rodar `reconcile_with_bank_statement.py`
- Verificar `unmatched_bank` e `unmatched_edi`.

## Erros comuns e acao

1. `first_record_must_be_header_0`
- Causa: arquivo corrompido ou recorte incorreto
- Acao: solicitar reenvio do arquivo completo

2. `last_record_must_be_trailer_9`
- Causa: upload incompleto
- Acao: validar transporte e checksum

3. `line_too_short_for_record_schema`
- Causa: truncamento de linha
- Acao: rejeitar arquivo e abrir incidente no canal de origem

4. `R001_D_E_NET_MATCH`
- Causa: divergencia entre consolidado (D) e detalhe (E)
- Acao: reprocessar lote e comparar com snapshot baseline

5. `R002_PIX_ADJUSTMENT_MUST_LINK_SALE`
- Causa: ajuste Pix sem `id_pix_original`
- Acao: classificar como pendencia critica e solicitar correca de origem

6. `unknown_domain_code`
- Causa: codigo novo nao mapeado
- Acao: registrar warning, preservar valor bruto e atualizar tabela de dominio

## Checklist de encerramento de incidente

1. Causa raiz identificada.
2. Evidencia anexada (arquivo, linha, regra, motivo).
3. Acao corretiva aplicada no artefato versionado.
4. Suite de homologacao executada com sucesso.
5. Comunicacao enviada para stakeholders.



