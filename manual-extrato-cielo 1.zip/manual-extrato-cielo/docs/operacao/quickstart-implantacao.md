# Quickstart de Implantacao

Este e o unico fluxo oficial para implantacao do toolkit em ambiente de cliente.

## 1. Pre-requisitos

- Python 3.13+
- Pip atualizado
- Acesso aos arquivos do toolkit

## 2. Instalacao

Na raiz deste diretorio:

```bash
python -m venv .venv
```

Windows PowerShell:

```bash
.\.venv\Scripts\Activate.ps1
```

Instalar dependencia minima:

```bash
python -m pip install --upgrade pip
pip install jsonschema
```

## 3. Estrutura esperada

A execucao exige estes artefatos:

- `2.manual-extrato-v15.15.schema.json`
- `3.schemas/`
- `4.tabelas/`
- `docs/core/5.manual-completo.md`
- `docs/core/6.glossario.md`
- `docs/prompts/7.prompt-implantacao-ai.md`
- `resultado-validacao.schema.json`
- `resultado-conciliacao.schema.json`

## 4. Comando de validacao estrutural

```bash
python scripts/validate_manual_package.py
```

Criterio de aceite:

- status = ok
- sem missing_required_file
- sem missing_required_directory

## 5. Comando de homologacao

```bash
python scripts/run_homologation_suite.py
```

Criterio de aceite:

- status = ok
- passed = total

## 6. Comandos essenciais adicionais

Parser posicional:

```bash
python scripts/parse_extrato_positional.py --file exemplos/CIELO04D_1234567890_20260701_20260701_20260701.TXT --out exemplos/snapshots/parse-cielo04-quickstart.json
```

Validacao de arquivo:

```bash
python scripts/validate_extrato_file.py --file exemplos/CIELO04D_1234567890_20260701_20260701_20260701.TXT
```

Conciliacao canonica baseline:

```bash
python scripts/reconcile_extrato_canonical.py --baseline --out exemplos/snapshots/resultado-conciliacao-baseline-quickstart.json
```

## 7. Troubleshooting basico

- Erro de arquivo ausente:
  - Execute `python scripts/validate_manual_package.py` e ajuste a estrutura do pacote.
- Erro de dependencia:
  - Reative o virtualenv e reinstale `jsonschema`.
- Erro de permissao em escrita:
  - Garanta permissao de escrita em `exemplos/snapshots/`.
