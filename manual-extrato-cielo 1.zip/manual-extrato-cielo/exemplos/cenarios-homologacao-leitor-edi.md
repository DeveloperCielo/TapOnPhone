# Cenarios de homologacao - Leitor EDI (Extrato Cielo)

## Objetivo

Validar se o leitor EDI:
- Faz parse posicional por tipo de arquivo e tipo de registro.
- Valida estrutura (header/trailer, tipos permitidos e consistencia basica).
- Aplica regras de negocio do manual (consolidacao, conciliacao e rastreabilidade).
- Gera erros rastreaveis por arquivo/linha/regra em cenarios invalidos.

## Base de homologacao (arquivos reais mascarados)

- CIELO03D_1234567890_20260701_20260701_20260701.TXT
- CIELO04D_1234567890_20260701_20260701_20260701.TXT
- CIELO09D_1234567890_20260701_20260701_20260701.TXT
- CIELO15D_1234567890_20260701_20260701_20260701.TXT
- CIELO16D_1234567890_20260701_20260701_20260701.TXT

## Cobertura observada na base

- CIELO03: 0, D, E, R, 9
- CIELO04: 0, D, E, 9
- CIELO09: 0, D, 9
- CIELO15: 0, A, B, C, 9
- CIELO16: 0, 8, 9

## Cenarios funcionais (positivo)

### H01 - Parse baseline CIELO03
Entrada:
- Arquivo CIELO03 de exemplo sem alteracoes.
Esperado:
- Parse concluido sem erro estrutural.
- Registros aceitos apenas entre {0, E, R, 9}.
- Header e trailer presentes.

### H02 - Parse baseline CIELO04
Entrada:
- Arquivo CIELO04 de exemplo sem alteracoes.
Esperado:
- Parse concluido sem erro estrutural.
- Registros aceitos apenas entre {0, D, E, 9}.
- Evidencia de consistencia D x E por chave de conciliacao.

### H03 - Parse baseline CIELO09
Entrada:
- Arquivo CIELO09 de exemplo sem alteracoes.
Esperado:
- Parse concluido sem erro estrutural.
- Registros aceitos apenas entre {0, D, 9}.

### H04 - Parse baseline CIELO15 (NRC)
Entrada:
- Arquivo CIELO15 de exemplo sem alteracoes.
Esperado:
- Parse concluido sem erro estrutural.
- Registros aceitos apenas entre {0, A, B, C, 9}.
- Blocos A/B/C correlacionados sem quebra de sequencia.

### H05 - Parse baseline CIELO16 (Pix)
Entrada:
- Arquivo CIELO16 de exemplo sem alteracoes.
Esperado:
- Parse concluido sem erro estrutural.
- Registros aceitos apenas entre {0, 8, 9}.
- Registros tipo 8 materializados para conciliacao Pix.

### H06 - Conciliacao Pix por status
Entrada:
- CIELO16 baseline.
Esperado:
- Classificacao de eventos por status (ex.: pago, bloqueado, desbloqueado, judicial, compensado), sem ambiguidade de codigo.

### H07 - Cenario Pix com compensacao por MED
Entrada:
- Fluxo com ajuste de compensacao por MED no tipo 8 (incluindo codigo 26 de compensacao por MED, conforme manual).
Esperado:
- Rastreio correto do ciclo da venda Pix.
- Estado final coerente com status/ajustes disponiveis no extrato.

### H08 - Regra de inferencia nao normativa
Entrada:
- Fluxo Pix com eventos parciais.
Esperado:
- Leitor nao assume regra formal de ordenacao quando a informacao nao estiver no extrato.
- Motor registra orientacao aplicada e grau de confianca da inferencia.

### H09 - Regra de corte para ajuste 0272
Entrada:
- Simulacao de arquivo antes e depois de 11/12/2024 (ou fixture sintetica derivada do baseline).
Esperado:
- Aplicacao da regra antiga para datas anteriores.
- Aplicacao da regra nova para datas posteriores/reprocessadas.

### H10 - Trailer e totalizadores
Entrada:
- Todos os 5 arquivos baseline.
Esperado:
- Quantidades e totalizadores do trailer consistentes com o conteudo parseado.

## Cenarios de robustez (negativo)

### N01 - Registro invalido por tipo de arquivo
Mutacao:
- Inserir registro tipo 8 em arquivo CIELO04.
Esperado:
- Erro com codigo de regra e linha.
- Arquivo rejeitado (ou segregado) com rastreabilidade.

### N02 - Ausencia de header
Mutacao:
- Remover primeira linha (registro 0).
Esperado:
- Falha estrutural imediata.

### N03 - Ausencia de trailer
Mutacao:
- Remover ultima linha (registro 9).
Esperado:
- Falha estrutural imediata.

### N04 - Linha truncada
Mutacao:
- Cortar colunas de um registro E.
Esperado:
- Erro de tamanho/offset com linha e campo.

### N05 - Valor numerico invalido
Mutacao:
- Inserir caractere alfabetico em campo numerico critico.
Esperado:
- Erro de parse tipado.

### N06 - Divergencia D x E
Mutacao:
- Alterar valor de um registro E sem ajustar consolidado D.
Esperado:
- Falha da regra de consistencia D x E.

### N07 - Pix ajuste sem referencia de origem
Mutacao:
- Ajuste Pix sem id_pix_original quando obrigatorio.
Esperado:
- Erro de integridade de chaves Pix.

### N08 - Codigo de dominio desconhecido
Mutacao:
- Substituir codigo de tabela por valor inexistente.
Esperado:
- Warning estruturado (ou erro, conforme criticidade) com valor bruto preservado.

## Criterios de aceite da homologacao

- 100% dos cenarios Hxx aprovados.
- 100% dos cenarios Nxx detectados com erro/warning correto.
- Todos os erros com rastreabilidade minima: arquivo, linha, regra, motivo.
- Sem divergencia silenciosa em totalizadores ou conciliacao Pix.

## Evidencias esperadas por execucao

- Relatorio consolidado (JSON ou CSV) por cenario.
- Logs estruturados por regra executada.
- Snapshot de saida canonica para comparacao regressiva.

Evidencias disponiveis nesta rodada:

- `exemplos/mutantes/manifest.json`
- `exemplos/mutantes/N01-*.TXT` ate `N08-*.TXT`
- `exemplos/snapshots/index.json`
- `exemplos/snapshots/CIELO*.snapshot.json`

## Execucao sugerida

1. Rodar baseline de validacao dos exemplos.
2. Gerar fixtures mutantes para N01-N08 (`scripts/generate_mutant_fixtures.py`).
3. Executar suite completa em pipeline (CI) com resultado versionado.


