# Exemplos

Arquivos reais de produção para smoke test de parser e validador.

Conjunto atual:

- CIELO03D_1234567890_20260701_20260701_20260701.TXT
- CIELO04D_1234567890_20260701_20260701_20260701.TXT
- CIELO09D_1234567890_20260701_20260701_20260701.TXT
- CIELO15D_1234567890_20260701_20260701_20260701.TXT
- CIELO16D_1234567890_20260701_20260701_20260701.TXT

Observacao sobre mascaramento:

- Dados sensiveis de identificacao (estabelecimento, CNPJ e dados bancarios) foram mascarados.
- O layout fixo, tipos de registro e regras de nomenclatura do manual foram preservados para validacao.

Nomenclatura esperada no validador:

- CIELOXXD_<ec_10_digitos>*<data_yyyymmdd>*<data_yyyymmdd>_<data_yyyymmdd>.TXT

Uso:

- `python manual-extrato-cielo/scripts/validate_extrato_file.py --self-check`
- `python manual-extrato-cielo/scripts/validate_extrato_file.py --file manual-extrato-cielo/exemplos/CIELO03D_1234567890_20260701_20260701_20260701.TXT`
- `python manual-extrato-cielo/scripts/reconcile_extrato_canonical.py --baseline --out manual-extrato-cielo/exemplos/snapshots/resultado-conciliacao-baseline-YYYYMMDD.json`
- `python manual-extrato-cielo/scripts/reconcile_with_bank_statement.py --recon manual-extrato-cielo/exemplos/snapshots/resultado-conciliacao-baseline-YYYYMMDD.json --bank-csv CAMINHO_DO_EXTRATO_BANCARIO_REAL.csv --out manual-extrato-cielo/exemplos/snapshots/resultado-conciliacao-banco-YYYYMMDD.json`

