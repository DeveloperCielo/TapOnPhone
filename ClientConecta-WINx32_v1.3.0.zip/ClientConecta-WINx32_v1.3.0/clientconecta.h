#ifndef _CLIENT_CONECTA_H
#define _CLIENT_CONECTA_H

/* Fonte exportav�l com os DEFINES que PODEM ser utilizados pela aplica��o comercial na montagem dos pacotes de comunica��o */

/* C�digos de opera��es dispon�veis pelo ConectaF�cil */
#define CFL_OPER_INITIALIZE						"1" // Opera��o de inicializa��o da biblioteca, deve ser a primeira opera��o a ser chamada pela aplica��o comercial, para configurar os par�metros de comunica��o e ambiente do ConectaF�cil
#define CFL_OPER_MERCHANT						"2" // Opera��o de consulta dos dados do estabelecimento comercial, como CNPJ, nome fantasia, endere�o, etc. Esta opera��o � necess�ria para a realiza��o de transa��es e pode ser chamada a qualquer momento ap�s a inicializa��o.
#define CFL_OPER_UNINSTALL						"3" // Opera��o de desinstala��o da biblioteca, deve ser a �ltima opera��o a ser chamada pela aplica��o comercial, para liberar os recursos alocados e encerrar a comunica��o com o ConectaF�cil. Ap�s esta opera��o, nenhuma outra opera��o deve ser chamada sem uma nova inicializa��o.
#define CFL_OPER_STATUS							"4" // Opera��o de consulta do status do ConectaF�cil, para verificar se a biblioteca est� pronta para receber comandos, se o pinpad est� conectado, se h� transa��es em andamento, etc. Esta opera��o pode ser chamada a qualquer momento ap�s a inicializa��o e antes da desinstala��o.
#define CFL_OPER_TRANSACTION					"5" // Opera��o de realiza��o de transa��o, para enviar os dados de uma venda, estorno, cancelamento ou pr�-autoriza��o ao ConectaF�cil e receber a resposta
#define CFL_OPER_TRANSREPRINT					"6" // Opera��o de reimpress�o de transa��o, para solicitar a reimpress�o do comprovante de uma transa��o j� realizada, utilizando filtros como NSU, data, valor, etc. Esta opera��o pode ser chamada a qualquer momento ap�s a realiza��o da transa��o e antes da desinstala��o.
#define CFL_OPER_CONFIRMATION					"7" // Opera��o de confirma��o de transa��o, para confirmar o recebimento da resposta de uma transa��o realizada, garantindo a consist�ncia dos dados e a finaliza��o do processo. Esta opera��o deve ser chamada ap�s receber a resposta de uma transa��o e antes de realizar qualquer outra opera��o relacionada � mesma transa��o (como reimpress�o ou consulta de status). Ap�s a confirma��o, a transa��o � considerada conclu�da e n�o pode mais ser modificada ou cancelada. Esta opera��o � importante para evitar
#define CFL_OPER_TRANSQUERY						"8" // Opera��o de consulta de transa��o, para consultar o status ou os detalhes de uma transa��o realizada, utilizando filtros como NSU, data, valor, etc. Esta opera��o pode ser chamada a qualquer momento ap�s a realiza��o da transa��o e antes da desinstala��o. 
#define CFL_OPER_PPRECEIVE						"9" // Opera��o de recebimento de dados do pinpad, para receber os dados lidos pelo pinpad, como cart�o magn�tico, cart�o chip, cart�o contactless, etc. Esta opera��o deve ser chamada ap�s a inicializa��o e antes da desinstala��o, e pode ser utilizada para obter os dados do cart�o
#define CFL_OPER_PPSEND						    "10" // Opera��o de envio de comando ao pinpad, para enviar comandos espec�ficos ao pinpad, como solicitar a leitura do cart�o, solicitar a captura do PIN, solicitar a criptografia dos dados, etc. Esta opera��o deve ser chamada ap�s a inicializa��o e antes da desinstala��o, e pode ser utilizada para controlar o fluxo de intera��o com o pinpad

/* C�digos de retorno
   Todas as fun��es da biblioteca, independentemente da sua funcionalidade, 
   possuem o mesmo tipo padronizado de c�digo de retorno, conforme a tabela a seguir. */

#define CFL_OK									   0 // Opera��o realizada com sucesso
#define CFL_ERROR_INVOPER						1 // C�digo de opera��o inv�lida/n�o reconhecida
#define CFL_ERROR_INVPARAM						2 // Par�metro inv�lido informado
#define CFL_ERROR_MANDAT						3 // Par�metro mandat�rio n�o informado
#define CFL_ERROR_INVCALL						4 // Chamada inv�lida � opera��o. Opera��es pr�vias s�o necess�rias
#define CFL_ERROR_CANCEL						5 // Opera��o cancelada
#define CFL_ERROR_TIMEOUT						6 // Esgotado o tempo m�ximo estipulado para a opera��o
#define CFL_ERROR_NOTALLOWED					7 // Opera��o n�o permitida
#define CFL_ERROR_INVMODE						8 // Modo inv�lido
#define CFL_ERROR_EXECERR						9 // Erro interno de execu��o � problema de implementa��o da biblioteca(software)
#define CFL_ERROR_PPC_OPENERR					10 // Erro no acesso ao pinpad/ppconecta - erro no comando de abertura da biblioteca do pinpad (comando OPN)
#define CFL_ERROR_PPC_EXECERR					11 // Erro no acesso ao pinpad/ppconecta - erro interno de execu��o da biblioteca do pinpad
#define CFL_ERROR_PPC_PORTERR					12 // Erro no acesso ao pinpad/ppconecta - porta serial utilizada para acesso ao pinpad inv�lida, provavelmente ocupada
#define CFL_ERROR_PPC_COMMERR					13 // Erro no acesso ao pinpad/ppconecta - falha ao encontrar o pinpad, provavelmente desconectado ou problemas com a interface serial
#define CFL_ERROR_PPC_COMMERR_EXT			14 // Erro no acesso ao pinpad/ppconecta - erro na comunica��o com o pinpad (status desconhecido, formato, timeout, propriet�rio)
#define CFL_ERROR_PPC_MCDATAERR				15 // Erro no acesso ao pinpad/ppconecta - erro de leitura do cart�o magn�tico
#define CFL_ERROR_PPC_ERRPIN					16 // Erro no acesso ao pinpad/ppconecta - erro na captura do pin ou de criptografia poss�vel falta de chave(s) no pinpad
#define CFL_ERROR_PPC_NOCARD					17 // Erro no acesso ao pinpad/ppconecta - cart�o n�o presente no leitor de cart�o de chip
#define CFL_ERROR_PPC_SECURITY				18 // Erro no acesso ao pinpad/ppconecta - cart�o n�o foi removido na �ltima transa��o realizada
#define CFL_ERROR_PPC_ERRCARD					19 // Erro no acesso ao pinpad/ppconecta - cart�o com erro ou mal inserido
#define CFL_ERROR_PPC_CARDINV					20 // Erro no acesso ao pinpad/ppconecta - cart�o inv�lido
#define CFL_ERROR_PPC_CARDINVALIDAT			21 // Erro no acesso ao pinpad/ppconecta - cart�o invalidado
#define CFL_ERROR_PPC_CARDAPPNAV				22 // Erro no acesso ao pinpad/ppconecta - modo inv�lido
#define CFL_ERROR_PPC_CARDAPPNAUT			23 // Erro no acesso ao pinpad/ppconecta - cart�o n�o aceito
#define CFL_ERROR_PPC_INVAMOUNT				24 // Erro no acesso ao pinpad/ppconecta - valor inv�lido 
#define CFL_ERROR_PPC_ERRMAXAID				25 // Erro no acesso ao pinpad/ppconecta - N�mero m�ximo de AIDs superado
#define CFL_ERROR_PPC_ERRCARDBLOCKED		26 // Erro no acesso ao pinpad/ppconecta - cart�o bloqueado
#define CFL_ERROR_PPC_CTLSSMULTIPLE			27 // Erro no acesso ao pinpad/ppconecta - mais de um cart�o contactless foi apresentado/aproximado ao leitor 
#define CFL_ERROR_PPC_CTLSSINV				28 // Erro no acesso ao pinpad/ppconecta - cart�o contactless inv�lido
#define CFL_ERROR_PPC_CTLSSINVALIDAT		29 // Erro no acesso ao pinpad/ppconecta - cart�o contactless invalidado
#define CFL_ERROR_PPC_CTLSSAPPNAV			30 // Erro no acesso ao pinpad/ppconecta - modo inv�lido do cart�o contactless
#define CFL_ERROR_PPC_CTLSSAPPNAUT			31 // Erro no acesso ao pinpad/ppconecta - cart�o contactless n�o aceito
#define CFL_ERROR_PPC_MFERR					32 // Erro no acesso ao pinpad/ppconecta - erro com o arquivo de multimidia utilizado

#define CFL_ERROR_TRMID_NOTCONFIG			50 // Terminal ID n�o configurado
#define CFL_ERROR_CNPJ							51 // CNPJ inv�lido
#define CFL_ERROR_CLIENTID						52 // ClientID inv�lido
#define CFL_ERROR_CLIENTSECRET				53 // ClientSecret inv�lido
#define CFL_ERROR_HASH_CLIENT					54 // ClientID e/ou ClientSecret n�o conferem com o cadastrado
#define CFL_ERROR_DATABASE						55 // Erro no acesso ao banco de dados
#define CFL_ERROR_TOKEN							56 // Erro na gera��o do Token � Token n�o dispon�vel
#define CFL_ERROR_MCH_NFOUND					57 // Estabelecimento n�o cadastrado
#define CFL_ERROR_TRMID							58 // Erro no cadastro do TerminalID
#define CFL_ERROR_NETWORK						59 // Erro na comunica��o com o Cielo Conecta
#define CFL_ERROR_TABLEPARAMETERS			60 // Erro na atualiza��o dos par�metros de opera��o no pinpad
#define CFL_ERROR_PINPAD						61 // Erro no acesso ao pinpad
#define CFL_ERROR_NOT_INIT						62 // Client n�o inicializado - opera��o de Inicializa��o ainda n�o foi realizada com sucesso nesta inst�ncia
#define CFL_ERROR_ERR_INIT						63 // Erro na opera��o de inicializa��o da biblioteca do Client
#define CFL_ERROR_TRANS_NFOUND				64 // Nenhuma transa��o encontrada para a consulta/listagem
#define CFL_ERROR_CONECTA_DATA_MANDAT		65 // Dados de resposta obrigat�rio n�o retornado pelo Conecta


#define CFL_ERROR_PENDING_TRANSACTION		66	// Transa��o com confirma��o/desfazimento pendente
#define CFL_ERROR_ALREADY_REFUND			67 // Transa��o j� estornada
#define CFL_ERROR_TRANS_NOT_FOUND			68 // Transa��o n�o encontrada/disponivel

#define CFL_ERROR_SECURITY_SHUTDOWN			999 // Detectado algum aplicativo em paralelo tentando depurar a aplica��o

/* Tipos de Transacao.*/

#define CFL_TRANSTYPE_CREDITO					   1
#define CFL_TRANSTYPE_DEBITO					   2
#define CFL_TRANSTYPE_CREDITOPARCSEMJUROS	   3
#define CFL_TRANSTYPE_CREDITOPARCCOMJUROS	   4
#define CFL_TRANSTYPE_VOUCHER					   30
#define CFL_TRANSTYPE_REF_CREDITO			   50
#define CFL_TRANSTYPE_REF_DEBITO				   51
#define CFL_TRANSTYPE_REF_VOUCHER			   52


/* Mensagens de notifica��o 
   Nesta se��o s�o definidas as mensagens de notifica��o de processamento que podem ser solicitadas 
   pela biblioteca CLIENT CONECTA � Automa��o Comercial durante a execu��o da fun��o RequestDispatcher.*/


#define CFL_MSG_NONOTIFY						0
#define CFL_MSG_WAITCARD						1  // Solicita��o de leitura de cart�o
#define CFL_MSG_SELECTAPP						2  // Solicita��o para selecionar aplica��o do cart�o
#define CFL_MSG_GETPIN							3  // Solicita��o para captura de senha
#define CFL_MSG_LOADTABLE						4  // Carga de tabelas em andamento
#define CFL_MSG_REMOVECARD						5  // Solicita��o para remo��o do cart�o
#define CFL_MSG_PROCESSING						6  // 6 aguarde
#define CFL_MSG_INITIALIZING					7  // 7 inicializando
#define CFL_MSG_PROCESS_CARD_ERROR			8  // 8 Erro no processamento do cart�o
#define CFL_MSG_FOREIGN_CARD					9	// Cartao estrangeiro
#define CFL_MSG_SECURITY_CHECK				10  // 9 Erro de seguran�a interna detectado 
#define CFL_MSG_PINPAD_DCC_SELECT			11  // Sele�ao do menu PINPad
#define CFL_MSG_MAX_NOTIFY						12 // 10 max callback msg types

#endif 