/********************************* SETIS - Automa��o e Sistemas ***********************************\
 Arquivo         : ppconecta_pltf.h
 Projeto         : Biblioteca de pinpad para o sistema Cielo Conecta
 Plataforma      : Windows 32/64
 Data de Criacao : 11/jul/2022
 Autor           : Wilson F. Martins

 Descri��o: Defini��es espec�ficas de plataforma para inclus�o no header "ppconecta.h".

 =========================================== HIST�RICO ============================================
 data     |respons�vel |modifica��o
 ---------|------------|---------------------------------------------------------------------------
\**************************************************************************************************/

#ifndef _PPCONECTA_PLTF_INCLUDED_
#define _PPCONECTA_PLTF_INCLUDED_

#define LIBEXP __declspec(dllexport)

#endif // -- #ifndef _PPCONECTA_PLTF_INCLUDED_

