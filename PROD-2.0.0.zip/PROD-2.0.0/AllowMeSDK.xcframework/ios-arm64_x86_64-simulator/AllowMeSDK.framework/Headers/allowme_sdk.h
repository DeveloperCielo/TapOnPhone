//
//  allowme_sdk.h
//  allowme-sdk
//
//  Created by Tiago Chaves on 26/11/19.
//  Copyright © 2019 Tempest. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <ifaddrs.h>

//! Project version number for allowme_sdk.
FOUNDATION_EXPORT double allowme_sdkVersionNumber;

//! Project version string for allowme_sdk.
FOUNDATION_EXPORT const unsigned char allowme_sdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <allowme_sdk/PublicHeader.h>
