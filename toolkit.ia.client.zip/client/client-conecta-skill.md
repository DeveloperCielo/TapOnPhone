# SKILL.md — Skill Autônoma e Agnóstica de Linguagem para Integração Client Conecta / Client TEF Cielo

## 1. Nome da Skill

**client-conecta-tef-cielo-integration**

## 2. Finalidade

Esta skill capacita uma IA a atuar de forma independente na integração com a DLL **Client Conecta / Client TEF Cielo**, incluindo arquitetura, configuração, inicialização, pagamentos, callbacks, comprovantes, estorno, logs, diagnósticos e geração de código.

Ela é autossuficiente e não depende de arquivos externos.

---

## 3. Quando ativar esta skill

Ative esta skill quando o usuário pedir:

- criar app desktop para pagamento com Client Conecta;
- corrigir integração com `clientconecta.dll`;
- montar payloads JSON;
- interpretar callback ou retorno da DLL;
- corrigir inicialização;
- corrigir pagamento;
- implementar comprovante;
- implementar estorno;
- implementar status, consulta, reemissão, confirmação ou desativação;
- gerar agente, documentação ou código sobre Client Conecta;
- revisar erros `CFL_ERROR_*`;
- trabalhar com pinpad via DLL.

---

## 4. Modelo mental da skill

O Client Conecta é uma DLL nativa. A aplicação não fala diretamente com Cielo via HTTP. A aplicação chama apenas:

```c
int RequestDispatcher(const char* ptrJSONInput, pDispatchCallback ptrfcCallback);
```

A DLL devolve:

1. retorno imediato inteiro;
2. callbacks JSON assíncronos.

A IA deve saber diferenciar:

- sucesso imediato de inicialização;
- aceite imediato de transação;
- callback final de transação;
- notificação intermediária;
- erro imediato;
- timeout indefinido.

---

## 5. Hard Rules

1. Nunca usar API HTTP da Cielo.
2. Nunca registrar PAN, PIN, trilha, criptograma ou dado sensível de cartão.
3. Sempre mascarar `ClientSecret` em logs.
4. Sempre persistir `MerchantOrderId` e `PaymentId`.
5. Sempre tratar timeout como indefinido.
6. Nunca tratar notificação como finalização.
7. Nunca tratar código `2` como sucesso.
8. `MerchantOrderId` deve ser numérico e ter 15 caracteres.
9. `Environment` deve ser `"0"` ou `"1"`.
10. Inicialização usa `Oper="1"`.
11. Pagamento usa `Oper="005"`.
12. Inicialização finaliza por retorno imediato `CFL_OK=0`.
13. Pagamento finaliza por callback `Code="0"`.
14. Sucesso financeiro exige `PhysicalTransactionStatus="2"` ou `"20"`.

---

## 6. Estrutura recomendada de projeto

A estrutura pode variar por linguagem, mas deve conter os mesmos blocos lógicos:

```text
projeto-client-conecta/
  aplicacao-principal
  config.ini
  clientconecta.dll
  conectafacil.dll
  libclient_hall.dll
  modulo-configuracao
  modulo-dll-client
  modulo-persistencia
  modulo-logs
  data/
    configuracoes-aplicacao
    transacoes
    integration.log
  integration.log
```

A nomenclatura dos arquivos e módulos pode mudar conforme C#, Java, Delphi, C/C++, Go, Rust, Node.js ou outra linguagem com suporte a chamada nativa.

---

## 7. Regras de `config.ini`

O arquivo precisa estar no mesmo diretório da DLL.

```ini
[DEFAULT]
TERMINAL_ID=PDV00001

[LOG]
LOG_LEVEL=63
LOG_PATH=dlllog.txt

[PPCONECTA]
PPC_SERVICE_STRING=Client Conecta
PPC_LICENSE_STRING=
PPC_LOGPATH=ppclog.txt
PPC_PORTPINPAD=AUTO
```

`TERMINAL_ID`:

- obrigatório;
- 8 caracteres;
- único;
- definido antes da primeira inicialização.

Evitar regravar `config.ini` após DLL carregada. Salvar preferências do app em `arquivo/banco de configurações da aplicação`.

---

## 8. Carregamento da DLL em qualquer linguagem

A integração deve usar o mecanismo de chamada nativa apropriado da linguagem escolhida, como FFI, P/Invoke, JNI/JNA, ctypes, cgo, Delphi external declarations, Node FFI, Rust FFI ou outro mecanismo equivalente.

Requisitos independentes de linguagem:

1. Carregar a DLL principal `clientconecta.dll`.
2. Garantir que as DLLs dependentes estejam no mesmo diretório ou em caminho conhecido do carregador.
3. Usar a mesma arquitetura do processo e da DLL: x86 com x86 ou x64 com x64.
4. Declarar a função nativa com assinatura equivalente a:

```c
int RequestDispatcher(const char* ptrJSONInput, pDispatchCallback ptrfcCallback);
```

5. Declarar callback equivalente a:

```c
typedef void (*pDispatchCallback)(const char* ptrJSONOutput);
```

6. Enviar `ptrJSONInput` como string JSON UTF-8/ASCII compatível.
7. Manter a referência da callback viva durante toda a operação para evitar coleta/desalocação prematura.
8. Não pré-carregar DLLs auxiliares sem necessidade.
9. Logar erro de carregamento com caminho absoluto da DLL principal.

---

## 9. Payloads

### 9.1 Inicialização

```json
{
  "Oper": "1",
  "Cnpj": "12345678000199",
  "ClientId": "client-id",
  "ClientSecret": "client-secret",
  "TerminalId": "PDV00001",
  "ConfirmationStatusSetup": "1",
  "Environment": "1"
}
```

`Environment`:

```text
0 = produção
1 = homologação
```

Não usar `PROD`, `HML`, `HOMO`.

### 9.2 Pagamento débito

```json
{
  "Oper": "005",
  "TransactionType": "02",
  "Amount": "1000",
  "MerchantOrderId": "260527143012123"
}
```

### 9.3 Pagamento crédito

```json
{
  "Oper": "005",
  "TransactionType": "01",
  "Amount": "1000",
  "Installments": "1",
  "MerchantOrderId": "260527143012123"
}
```

### 9.4 Estorno por PaymentId

```json
{
  "Oper": "005",
  "TransactionType": "51",
  "Amount": "1000",
  "MerchantOrderId": "260527143099999",
  "RefundPaymentId": "payment-id-original"
}
```

### 9.5 Estorno por dados transacionais

```json
{
  "Oper": "005",
  "TransactionType": "51",
  "Amount": "1000",
  "MerchantOrderId": "260527143099999",
  "RefundMerchantOrderId": "260527143012123",
  "RefundDatetime": "20260527143012",
  "RefundNSU": "123456",
  "RefundAuthorizationCode": "654321"
}
```

### 9.6 Status

```json
{"Oper":"4"}
```

### 9.7 Reemissão

```json
{
  "Oper": "6",
  "MerchantOrderId": "260527143012123",
  "Receipt": "0"
}
```

### 9.8 Confirmação

```json
{
  "Oper": "7",
  "MerchantOrderId": "260527143012123",
  "PaymentId": "payment-id",
  "TransactionConfirmationStatus": "1"
}
```

### 9.9 Consulta

```json
{
  "Oper": "8",
  "PaymentId": "payment-id"
}
```

### 9.10 Desativação

```json
{
  "Oper": "3",
  "TerminalId": "PDV00001"
}
```

---

## 10. Geração e validação de MerchantOrderId

Regra:

```text
N15 = 15 dígitos numéricos
```

Implementação recomendada:

```text
function gerarMerchantOrderId():
    value = dataHoraAtualNoFormato(YYMMDDHHMMSSmmm)
    if value não for numérico ou tamanho(value) != 15:
        gerar erro "MerchantOrderId deve conter exatamente 15 números"
    return value
```

Nunca usar:

- UUID;
- letras;
- hífen;
- prefixo `PDV-`;
- `ORD123456`.

---

## 11. Fluxo de inicialização

Pseudocódigo:

```text
payload = montarPayloadInicializacao()
code = RequestDispatcher(json.dumps(payload), callback)

if code == 0:
    initialized = True
else:
    initialized = False
    gerarErroImediato(code)
```

Importante:

- Não aguardar callback final para `Oper="1"`.
- Callback recebido durante inicialização deve ser logado, não usado como pré-condição de sucesso.

---

## 12. Fluxo de pagamento

Pseudocódigo:

```text
payload = montarPayloadPagamento()
code = RequestDispatcher(json.dumps(payload), callback)

if code != 0:
    gerarErroImediato(code)

final = aguardarCallbackFinalCodeZero(timeout=300)
status = final["PhysicalTransactionStatus"]

if status in {"2", "20", 2, 20}:
    approved = True
else:
    approved = False
```

Notificações como `WAITCARD`, `GETPIN`, `PROCESSING`, `REMOVECARD` devem ser exibidas/logadas, mas não finalizam a operação.

---

## 13. Comprovantes

Após aprovação, procurar:

```text
comprovanteCliente = TransactionReceiptCli se existir; senão TransactionReceiptCliImg
comprovanteEstabelecimento = TransactionReceiptMch se existir; senão TransactionReceiptMchImg
```

A UI deve mostrar:

- via cliente;
- via estabelecimento;
- botão de estorno.

---

## 14. Estorno automático do último pagamento

Para estornar o último pagamento aprovado:

1. Obter transação original persistida.
2. Identificar tipo original:
   - `01` -> `50`;
   - `02` -> `51`;
   - `30` -> `52`.
3. Gerar novo `MerchantOrderId` N15.
4. Usar `RefundPaymentId` se existir.
5. Caso contrário, usar dados originais.
6. Enviar `Oper="005"`.
7. Aguardar callback final.

---

## 15. Persistência

Persistir em `armazenamento transacional local` ou banco equivalente:

```json
{
  "merchant_order_id": "260527143012123",
  "payment_id": "payment-id",
  "amount": "1000",
  "transaction_type": "02",
  "datetime": "20260527143012",
  "physical_transaction_status": "20",
  "nsu": "123456",
  "authorization_code": "654321",
  "receipt_client": "...",
  "receipt_merchant": "..."
}
```

---

## 16. Logs

A skill deve implementar logs em dois arquivos:

```text
data/integration.log
integration.log
```

Cada linha deve ter origem:

```text
[APP]
[DLL/Conecta]
[SISTEMA]
```

Sanitização obrigatória:

```text
Campos sensíveis mínimos para mascarar:
ClientSecret, Pan, PAN, Pin, PIN, Track, Cryptogram, CardNumber, CardData, EMV, Token sensível
```

`ClientSecret` deve ser `***` no log.

---

## 17. Códigos e diagnóstico

Quando receber código imediato:

- `0`: seguir regra da operação.
- `2`: revisar payload; parâmetro inválido.
- `50`: TerminalId ausente/incorreto.
- `56`: token/credenciais/ambiente/rede.
- `57`: precisa cadastro estabelecimento.
- `59`: comunicação.
- `61`: pinpad.
- `62`: inicialização ausente.

Não inventar significado de código desconhecido.

---

## 18. Testes obrigatórios

Antes de entregar código, garantir:

- inicialização em modo mock/simulado funciona;
- inicialização real trata `CFL_OK=0`;
- pagamento em modo mock/simulado envia notificações;
- pagamento real aguarda callback final;
- comprovantes aparecem;
- estorno monta payload correto;
- logs aparecem em tela e arquivo;
- `MerchantOrderId` tem 15 números;
- `Environment` não usa texto;
- `ClientSecret` aparece mascarado.

---

## 19. Formato de entrega de soluções

Quando a IA gerar correção:

1. Informar causa provável.
2. Informar arquivos alterados.
3. Informar comportamento novo.
4. Gerar artefato final se aplicável.
5. Não prometer funcionamento sem validar sintaxe e regras.

---

## 20. Checklist final da skill

- [ ] Usa apenas DLL.
- [ ] Usa apenas `RequestDispatcher`.
- [ ] Inicializa com `Oper="1"`.
- [ ] Pagamento usa `Oper="005"`.
- [ ] `Environment` é `"0"/"1"`.
- [ ] `MerchantOrderId` é N15 numérico.
- [ ] Inicialização usa retorno imediato.
- [ ] Transação usa callback final.
- [ ] Timeout = indefinido.
- [ ] Logs existem em arquivo e tela.
- [ ] Dados sensíveis mascarados.
- [ ] Comprovantes exibidos.
- [ ] Estorno disponível.
- [ ] Operações auxiliares implementadas.
- [ ] Persistência de identificadores implementada.
