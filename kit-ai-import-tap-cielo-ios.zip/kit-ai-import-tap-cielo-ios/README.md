# Implementação Tap on Phone com IA

Este repositório contém instruções e documentação para implementar o SDK Cielo Tap on Phone utilizando agentes de IA como assistentes no desenvolvimento.

## Pré-requisitos

Antes de utilizar as instruções de IA para implementação, é necessário ter o SDK devidamente configurado no seu projeto.

### iOS

Para iOS, é necessário baixar os frameworks diretamente pelo [Manual de integração](https://desenvolvedores.cielo.com.br/api-portal/pt-br/content/documenta%C3%A7%C3%A3o-do-sdk-tap-phone-ios) e incluí-los no projeto seguindo os passos abaixo:

**1. Adicione os frameworks ao projeto:**

![Localização da libs](./skill-tap/docs/markdown/images-ios/img_35.png)

**2. Configure como "Embed & Sign":**

![Localização da libs](./skill-tap/docs/markdown/images-ios/img_34.png)


## Como utilizar as instruções de IA

Após descompactar o arquivo na raiz do projeto em uma pasta, por exemplo `skill-tap`, você pode escolher entre a melhor abordagens para integrar as instruções com seu agente de IA. Abaixo, segue dois exemplos.

### Opção 1: Arquivo AGENTS.md (Recomendado para GitHub Copilot Workspace)

**1. Estrutura de pastas:**
```
seu-projeto/
├── skill-tap/
│   └── tap_implementation.md
│   └── tap_ios.md
│   └── docs/
│       └── markdown/
└── AGENTS.md
```

![Localização das skills](./skill-tap/docs/markdown/images-ios/img_36.png)

**2. Crie o arquivo `AGENTS.md` na raiz do projeto:**

![Instruções do AGENTS.md](./skill-tap/docs/markdown/images-ios/img_37.png)

**Exemplo de conteúdo:**
```markdown
# Instruções para Agentes de IA

## Tap on Phone (SDK Cielo)

Para tudo relacionado à implementação do SDK Tap on Phone, incluindo:
- Inicialização e configuração
- Implementação de transações
- Tratamento de erros
- Customização de UI

Consulte as instruções detalhadas em:
- `skill-tap/tap_implementation.md` - Instruções gerais
- `skill-tap/tap_ios.md` - Específico para iOS
```

**3. Exemplo de uso com o agente:**

![Exemplo do agente usando](./skill-tap/docs/markdown/images-ios/img_38.png)

> 💡 **Dica:** Você pode gerar o AGENTS.md automaticamente usando o seguinte prompt:
> 
> _"Crie um arquivo padrão AGENTS.md na raiz do projeto. Para tudo relacionado a TAP (implementação, troubleshooting e customização), referencie o arquivo skill-tap/tap_implementation.md"_

### Opção 2: GitHub Copilot Instructions

Para usuários do GitHub Copilot, você pode criar instruções específicas no diretório `.github/instructions/`.

**1. Estrutura de pastas:**
```
seu-projeto/
├── .github/
│   └── instructions/
│       └── tap.instructions.md
└── skill-tap/
    └── ...
```

![Localização para o plugin do GitHub Copilot](./skill-tap/docs/markdown/images-ios/img_39.png)

**2. Conteúdo do arquivo `.github/instructions/tap.instructions.md`:**

![Exemplo de instruções](./skill-tap/docs/markdown/images-ios/img_40.png)

**Exemplo:**
```markdown
# Tap on Phone SDK - Instruções de Implementação

Ao trabalhar com o SDK Cielo Tap on Phone:

1. Sempre consulte a documentação em `skill-tap/tap_implementation.md`
2. Para código iOS específico: `skill-tap/tap_ios.md`
3. Siga as práticas recomendadas de segurança do SDK
4. Sempre trate erros usando os callbacks apropriados
```

**3. Exemplo de utilização:**

![Exemplo da utilização](./skill-tap/docs/markdown/images-ios/img_41.png)

## Documentação Disponível

Este repositório contém a seguinte documentação:

- 🍎 **iOS:**
  - [Manual de integração](https://desenvolvedores.cielo.com.br/api-portal/pt-br/content/documenta%C3%A7%C3%A3o-do-sdk-tap-phone-ios)

## Suporte

Para dúvidas ou problemas com o SDK, consulte:
1. Os manuais de integração específicos da sua plataforma
2. As instruções de troubleshooting nos arquivos `tap_*.md`
3. O suporte técnico da Cielo