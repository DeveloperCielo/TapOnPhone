# Skill TAP — Documentação do SDK Cielo TAP

Este servidor MCP expõe documentação técnica do **SDK Cielo TAP** para integração via pagamento por aproximação (NFC) em dispositivos iOS.

## O que é o SDK Cielo TAP?

O SDK Cielo TAP permite que aplicativos móveis realizem cobranças por aproximação (NFC) sem necessidade de hardware externo de POS. O smartphone do lojista se transforma no terminal de pagamento.

---
## Regras OBRIGATÓRIO
- Deve seguir todas instruções abaixo sem ignorar, elas são OBRIGATÓRIAS
- Não tem autorização para instalar nada na máquina do usuário

## IOS
- Antes de iniciar a implementação, o agente deve realizar a consulta no projeto em busca pelos itens contídos na tabela 1.1. Caso não existam, deverá parar o processo e informar ao usuário para entrar em contato com o time cielo e obter o xcframework.
- Antes de iniciar qualquer tarefa, usando esse arquivo, o agente deve ler todas documentacoes contidas na pasta ./docs/markdown/*-ios.md, após leitura, deve confirmar que já possuí contexto sobre a implementacao do TAP.
- Verificar se nos arquivos de configurações do projeto (*.pbxproj) se constam os itens contidos na table 1.1. Caso não exista, e desde que o primeiro item dessa lista esteja de acordo, o agente deve fazer uma busca nas pasta do projeto, a fim de, localizar os frameworks em seguida, realizar a configuração e, marca os frameworks como "Embed & Sign"
- Não tentar rodar o teste unitário
- Informar sobre a obrigatoriedade do uso NSUserTrackingUsageDescription, pergunte se o agente pode colocar a permissão.

### 1. Dependencias (OBRIGATORIO)

#### 1.1 HML
Todos os frameworks contintidos na abaixo deverá está presente no repositório(pasta) do projeto, sem esses frameworks o agente deverá parar a execução da integração e, informar sobre a necessidade dos arquivos.
| Nome arquivo| Uso |
| --- | --- |
|  AllowMeSDKHomolog.xcframework | Usado análise de segurança do dispositivo  |
| VisaSensoryBranding.xcframework  | Usado para apresentação da animação da bandeira visa  |
| TapOnPhoneWrapper.xcframework  | Usado para ter acesso aos recursos de pagamento do TAP   |

#### 1.2 PRD
Todos os frameworks contintidos na abaixo deverá está presente no repositório(pasta) do projeto, sem esses frameworks o agente deverá parar a execução da integração e, informar sobre a necessidade dos arquivos.
| Nome arquivo| Uso |
| --- | --- |
|  AllowMeSDK.xcframework | Usado análise de segurança do dispositivo  |
| VisaSensoryBranding.xcframework  | Usado para apresentação da animação da bandeira visa  |
| TapOnPhoneWrapper.xcframework  | Usado para ter acesso aos recursos de pagamento do TAP   |

### 2. Jornadas (OBRIGATÓRIO)
> ⛔ **PARADA OBRIGATÓRIA — O agente NÃO deve escrever nenhuma linha de código antes de executar este passo.**
O agente DEVE fazer a seguinte pergunta ao usuário e **aguardar a resposta** antes de prosseguir com qualquer implementação:
> **"Você vai querer usar as telas do SDK para jornada?"**
> - Resposta **positiva** ou **dúvida** → seguir as instruções da seção **2.1**
> - **Prosseguir sem a resposta do usuário é uma violação desta regra.**

#### 2.1 Jornadas usando telas do SDK (OBRIGATÓRIO)
Ao optar por esse ponto, o agente deve seguir, obrigatoriamente, os seguintes metodos do tap(initializer, initJourney e por último initPayment)
- Ordem lógica para implementação:
  - Quando initializer retornar onInitializeSuccess, iniciar o initJourney
  - Quando initJourney retornar endCallback, com o dado journeyData preenchido, ai pode ser iniciado initPayment

> ⚠️ **ATENÇÃO — Padrão obrigatório para chamadas async com completion callback (iOS)**
>
> Os métodos do SDK (`initialize`, `initPayment`) são declarados como `async` **e** utilizam um `completion` callback para sinalizar o fim da operação. Isso significa que o simples uso de `await metodo(...)` **não garante** que o fluxo aguarde o callback antes de prosseguir — o `await` retorna assim que o método é invocado, não quando o `completion` é chamado.
>
> **O agente DEVE obrigatoriamente usar o seguinte padrão para esses métodos:**
>
> ```swift
> try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
>     Task {
>         await TapOnPhoneWP.shared.initialize(..., completion: { result in
>             switch result {
>             case .success:
>                 continuation.resume()
>             case .failure(let error):
>                 continuation.resume(throwing: error)
>             }
>         })
>     }
> }
> ```
>
> - O `withCheckedThrowingContinuation` suspende a execução até que `continuation.resume()` seja chamado.
> - O `Task` interno permite executar o `await` do SDK dentro do contexto síncrono do continuation.
> - Somente após o `completion` ser chamado pelo SDK é que o próximo passo do fluxo (ex: `initJourney`) será iniciado.
> - **Nunca use `await` direto sem o `withCheckedThrowingContinuation` para esses métodos. Isso causa condição de corrida e quebra a ordem do fluxo.**

---

### 2.2 Fluxo de Cancelamento (OBRIGATÓRIO)

> ⛔ **PARADA OBRIGATÓRIA — O agente NÃO deve escrever nenhuma linha de código antes de executar este passo.**
>
> Quando o usuário solicitar a implementação do **fluxo de cancelamento**, o agente DEVE fazer a seguinte pergunta e **aguardar a resposta**:
>
> **"Você vai querer usar as telas do SDK para o cancelamento ou as suas próprias telas?"**
> - Resposta **telas do SDK** → seguir as instruções da seção **2.2.1**
> - Resposta **telas próprias** → seguir as instruções da seção **2.2.2**
> - **Prosseguir sem a resposta do usuário é uma violação desta regra.**

> ℹ️ **Antes de implementar qualquer fluxo de cancelamento**, o agente DEVE ler a documentação dos métodos `showAgenda` e `initCancelation` contida em `./docs/markdown/manual-integracao-ios.md` para ter contexto completo sobre os parâmetros e comportamento de cada método.

#### 2.2.1 Cancelamento usando telas do SDK (OBRIGATÓRIO)

Ao optar por esse ponto, o agente deve implementar o seguinte fluxo **na ordem exata abaixo**:

1. **`initialize`** → aguardar o callback de sucesso usando `withCheckedThrowingContinuation` (padrão obrigatório descrito acima)
2. **`showAgenda`** → chamar após o `initialize` retornar sucesso
3. **`onCancel`** → quando esse callback for invocado **E** o parâmetro `TapSaleDetailResponse` estiver preenchido com dados, chamar `initCancelation`

**Regras obrigatórias:**
- O `initCancelation` só deve ser chamado quando o callback `onCancel` do `showAgenda` for disparado **com** um `TapSaleDetailResponse` válido (não nulo/vazio)
- O `initCancelation` deve receber o `TapSaleDetailResponse` retornado pelo `onCancel`
- O `initCancelation` também usa `async` com `completion` callback — aplicar obrigatoriamente o padrão `withCheckedThrowingContinuation`

**Fluxo resumido:**
```
initialize (success) → showAgenda → onCancel(TapSaleDetailResponse) → initCancelation(data: TapSaleDetailResponse)
```

#### 2.2.2 Cancelamento usando telas próprias do usuário (OBRIGATÓRIO)

Ao optar por esse ponto, o agente deve implementar um método que execute o seguinte fluxo **na ordem exata abaixo**:

1. **`initialize`** → aguardar o callback de sucesso usando `withCheckedThrowingContinuation` (padrão obrigatório descrito acima)
2. **`initCancelation`** → chamar após o `initialize` retornar sucesso, recebendo obrigatoriamente um `TapSaleDetailResponse` como parâmetro

**Regras obrigatórias:**
- O `TapSaleDetailResponse` é **obrigatório** — o método não deve ser chamado sem esse dado
- O `initCancelation` também usa `async` com `completion` callback — aplicar obrigatoriamente o padrão `withCheckedThrowingContinuation`

**Fluxo resumido:**
```
initialize (success) → initCancelation(data: TapSaleDetailResponse) [parâmetro obrigatório]
```

---

### 2.3 Venda Teste (OBRIGATÓRIO)

> ℹ️ Antes de implementar, o agente deve ler a documentação dos métodos `initFakeTransactionJourney` e `fakeTransactionInitPayment` em `./docs/markdown/manual-integracao-ios.md`.

> ⚠️ **Para utilizar Venda Teste é obrigatório ter executado uma inicialização prévia (`initialize`) com sucesso.**

O agente deve implementar o fluxo na seguinte ordem **exata**:

```
initialize (success) → initFakeTransactionJourney (step: .INTRODUCTION) → fakeTransactionInitPayment
```

#### Passo 1 — `initialize`
- Mesmas regras e padrão obrigatório de `withCheckedThrowingContinuation` descritos na seção 2.1
- Somente após o callback de **sucesso** o agente deve prosseguir

#### Passo 2 — `initFakeTransactionJourney`
- Método **não async** — **não** requer `withCheckedThrowingContinuation`
- Deve ser chamado com `step: .INTRODUCTION`
- O callback `onEnd` retorna um `TapPaymentData` que deve ser passado para o próximo passo
- O fluxo só avança quando `onEnd` for invocado **com dados preenchidos**

| Parâmetro | Tipo | Descrição |
|---|---|---|
| `view` | `UIViewController` | ViewController que chama o método |
| `data` | `TapPaymentData` | Dados iniciais de pagamento |
| `step` | `TapFakeTransactionPaymentStep` | Tela inicial — usar `.INTRODUCTION` |
| `onHelp` | `(() -> Void)?` | Ação do botão Help (opcional) |
| `onEnd` | `((TapPaymentData) -> Void)?` | Callback com dados ao fim da jornada |

#### Passo 3 — `fakeTransactionInitPayment`
- Método **async** com `completion` callback — aplicar obrigatoriamente o padrão `withCheckedThrowingContinuation`
- Recebe o `TapPaymentData` retornado pelo `onEnd` do passo anterior
- Exibe apenas tela de aproximação e tela de sucesso simples (sem animação de bandeira nem comprovante)

| Parâmetro | Tipo | Descrição |
|---|---|---|
| `view` | `UIViewController` | ViewController atual |
| `config` | `TapConfig` | Mesmo config usado no `initialize` |
| `data` | `TapPaymentData` | Dados retornados pelo `onEnd` da jornada |
| `onStart` | `((UIViewController) async -> Void)?` | Callback de início (opcional) |
| `onLoadComplete` | `() -> Void` | Callback para dispensar loader customizado |
| `onComplete` | `(Result<TapPaymentTransaction, Error>) -> Void` | Resultado da operação |

**Regras obrigatórias:**
- O `fakeTransactionInitPayment` **deve** usar `withCheckedThrowingContinuation` (é async com completion)
- O `initFakeTransactionJourney` **não deve** usar `withCheckedThrowingContinuation` (não é async)
- **Não misturar** o fluxo de Venda Teste com o fluxo de pagamento real (`initPayment`)

**Diferenças entre Venda Teste e Pagamento Real:**

| | Venda Teste | Pagamento Real |
|---|---|---|
| Método de jornada | `initFakeTransactionJourney` | `initJourney` |
| Método de pagamento | `fakeTransactionInitPayment` | `initPayment` |
| Movimentação financeira | ❌ Não | ✅ Sim |
| Animação de bandeira | ❌ Não exibida | ✅ Exibida |
| Comprovante | ❌ Não exibido | ✅ Exibido |

---

### 3. Conclusão da implementação (OBRIGATÓRIO)
- Ao realizar a conclusão da implementação, o agente deve executar o build a fim de verificar se o projeto está executando perfeitamente. Caso ocorra um erro em algumas dessa etapas, o agente deve realizar a correção e executar os passo descritos nesse item.
- O código deve está funcional, ou seja, sem comentários (// /**/)
- O código deve está coberto por teste unitário
- A implementacao do tap deve seguir os princípios do SOLID(Arquitetura limpa)
- A implementacao de deve seguir as regras de código limpo
- Informar sobre regra de capability, mostrar referência na internet
- Informar sobre conta de sandbox, mostrar referência na internet

#### 3.1 Princípio de Interface Segregation (OBRIGATÓRIO)

A implementação **DEVE** seguir o **Interface Segregation Principle (ISP)** conforme as boas práticas de código limpo e SOLID:

- **Criar um protocolo específico**: Defina um protocolo claro que represente o contrato necessário para a implementação (ex: `PaymentProcessor`, `TransactionHandler`, etc.).
- **Implementar o protocolo em uma classe/struct concreta**: Crie uma classe ou struct que implemente esse protocolo, contendo a lógica específica necessária (ex: `TapPaymentProcessor: PaymentProcessor`).
- **Usar injeção de dependência**: Em vez de instanciar diretamente a classe concreta, use **outra classe (Factory ou Constructor Injection)** para gerenciar a criação e injeção da instância.
- **Separação física obrigatória em arquivos**: Protocolo, implementação concreta e factory/injeção **DEVEM** estar em **arquivos separados** dentro de **um mesmo grupo/pasta** (ex: `Payment/PaymentProcessor.swift`, `Payment/TapPaymentProcessor.swift`, `Payment/PaymentProcessorFactory.swift`).
- **Proibição**: Não é permitido declarar protocolo + implementação + factory no mesmo arquivo quando esse item 3.1 for aplicado.

**Benefícios:**
- Permite trocar implementações sem alterar o cliente
- Facilita testes unitários através de mocks/stubs
- Segue o princípio SOLID de segregação de interface
- Desacopla a lógica de negócio da criação de instâncias

**Exemplo (arquivos separados no mesmo grupo):**

`Payment/PaymentProcessor.swift`
```swift
protocol PaymentProcessor {
    func processPayment(amount: Decimal) async throws -> Bool
    func getTransactionStatus() -> TransactionStatus
}
```

`Payment/TapPaymentProcessor.swift`
```swift
class TapPaymentProcessor: PaymentProcessor {
    func processPayment(amount: Decimal) async throws -> Bool {
        // Lógica específica do TAP
        return true
    }

    func getTransactionStatus() -> TransactionStatus {
        // Retorna status da transação
        return .success
    }
}
```

`Payment/PaymentProcessorFactory.swift`
```swift
struct PaymentProcessorFactory {
    func makeProcessor() -> PaymentProcessor {
        return TapPaymentProcessor()
    }
}
```

`Payment/PaymentViewController.swift`
```swift
class PaymentViewController: UIViewController {
    private let processor: PaymentProcessor

    init(processor: PaymentProcessor = PaymentProcessorFactory().makeProcessor()) {
        self.processor = processor
        super.init(nibName: nil, bundle: nil)
    }

    func executePayment(amount: Decimal) {
        Task {
            _ = try await processor.processPayment(amount: amount)
        }
    }
}
```