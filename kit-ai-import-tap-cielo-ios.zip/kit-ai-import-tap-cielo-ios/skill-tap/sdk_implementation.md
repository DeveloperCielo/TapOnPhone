# SDK Implementation Guide

## Instruções para Agente de IA

Este documento contém as regras de implementação do SDK. Siga as instruções abaixo.

---

## Fluxo de Decisão

### 1. Fluxo para iOS

✅ **Ação:** Leia e siga as instruções do arquivo: [`tap_ios.md`](./tap_ios.md)

---

## Resumo do Fluxo

```
┌─────────────────────────────┐
│ Implementação iOS           │
└──────────┬──────────────────┘
           │
       ┌───▼───┐
       │  iOS  │
       └───┬───┘
           │
   ┌───────▼───────┐
   │ tap_ios.md    │
   └───────────────┘
```

---

## Arquivos de Referência

- **iOS + TAP:** [`tap_ios.md`](./tap_ios.md)

---

## Notas Importantes

1. Siga rigorosamente o arquivo de documentação apropriado após identificar o SDK

