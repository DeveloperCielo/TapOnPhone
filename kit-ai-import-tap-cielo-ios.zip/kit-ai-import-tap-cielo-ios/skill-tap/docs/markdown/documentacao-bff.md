# Documentação BFF

## Padrão de código


Ex:
TAP01001
- Produto
Backend de Origem Regra
de negocio do erro

01 - BFF

02 - Allowme

03 - DTF-Order

04 - DTF-Device

05 - SDK Tap - Para saber mais
sobre esses erros veja: [Documentação SDK - Códigos de erro na
inicialização (prefixo TAP 05)](https://jiracielo.atlassian.net/wiki/spaces/TONPC/pages/4630577153/Documenta+o+SDK+-+C+digos+de+erro+na+inicializa+o+prefixo+TAP+05)

06 - CCNT Payments Query


## Códigos
de Erros.

| **HTTP status code ** | **error code ** | **descrição** | **mensagem de retorno ** | **retorno para o frontend** |
| --- | --- | --- | --- | --- |
| 400 BAD REQUEST | BFF400001 TAP01001 | Requisição com dados inválidos ou faltantes. Ex: token jwt ou campos obrigatórios no payload da requisição. | Requisição inválida. Verifique os dados enviados e tente novamente. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP01001 |
| BFF400002 TAP01002 | Requisição com parâmetro version faltante. | Requisição inválida. Verifique os dados enviados e tente novamente. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP01002 |
| 401 UNAUTHORIZED | BFF401001 TAP01003 | BundleId e/ou clientId inválidos. | Ops! Parece que você não tem permissão para acessar este recurso. Verifique suas credenciais e tente novamente. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP01003 |
| BFF401002 TAP01004 | Parâmetro version não cadastrado no aws secret manager. | Versão inválida. Verifique os dados enviados e tente novamente. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP01004 |
| 422 UNPROCESSABLE ENTITY | BFF422001 TAP02001 | Erro de integração com a allowme. | Falha na validação de segurança do dispositivo. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP02001 |
| BFF422002 TAP03001 | Erro de integração com dtf-dt-order. | Não foi possível validar os dados de cadastro do usuário. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP03001 |
| BFF422003 TAP04001 | Erro de integração com dtf-top-device (consulta de dispositivo) | Não foi possível validar o cadastro do dispositivo do usuário. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP04001 |
| BFF422004 TAP04002 | Erro de integração com dtf-top-device (cadastro de dispositivo Android). | Não foi possível realizar o cadastro de dispositivo do usuário. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP04002 |
| BFF422005 TAP04003 | Erro de integração com dtf-top-device (cadastro dispositivo iOS). | Não foi possível realizar o cadastro de dispositivo do usuário. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP04003 |
| BFF422006 TAP04004 | Erro de integração com dtf-top-device (geração token iOS). | Não foi possível realizar a ativação do dispositivo cadastrado. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP04004 |
| 403 FORBIDDEN | BFF403001 TAP02002 | Device com suspeita de fraude. | Falha na validação de segurança do dispositivo. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP02002 |
| BFF403002 TAP03002 | Estabelecimento comercial com status diferente de 'aberto'. | Estabelecimento comercial fechado. | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Tente novamente mais tarde. /n Caso o erro persista, entre em contato com a Central de Atendimento. **Código de erro:** TAP03002 |
| BFF403003 TAP03003 | Estabelecimento com POS STATUS diferente de SUCCESS. | Estabelecimento comercial não está habilitado para utilizar o SDK. | **Titulo: **O Tap On Phone não está habilitado no momento **Mensagem: **Para mais informações, entre em contato com a Central de Atendimento. **Código de erro:** TAP03003 |
| BFF403004 TAP03004 | Estabelecimento não possui Tap on Phone habilitado. | Estabelecimento comercial não está habilitado para transacionar via Tap On Phone. | **Titulo: **O Tap On Phone não está habilitado no momento **Mensagem: **Para mais informações, entre em contato com a Central de Atendimento. **Código de erro:** TAP03004 |
| - | BFF000000 TAP01005 | Erro desconhecido. | - | **Titulo: **Parece que tivemos algum problema por aqui **Mensagem: **Nesse momento, não conseguimos concluir sua solicitação. /n Tente novamente mais tarde. **Código de erro:** TAP01005 |

##
