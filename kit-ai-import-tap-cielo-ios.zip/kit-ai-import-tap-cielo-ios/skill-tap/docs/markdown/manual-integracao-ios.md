# Manual de Integração — SDK Cielo TAP (iOS)

Manual de integração (IOS)

# Manual de integração (IOS)

**Documentação do SDK – Tap on phone** **iOS**

Este guia irá orientá-lo através dos requisitos do SDK, como configurar e inicializar a biblioteca, as diferentes jornadas disponíveis, como usar o white label e como realizar transações.

**Requisitos Apple**

Para que o SDK funcione propriamente no iOS a Apple necessita de algumas pré configurações e que suas guidelines sejam respeitadas.

- Solicitar no portal de desenvolvedor da Apple o capability de “TapToPay on iPhone”, indicando que o aplicativo contará com tal funcionalidade. [https://developer.apple.com/contact/request/contactless-payments/](https://developer.apple.com/contact/request/contactless-payments/)


- Seguir o Human Interface Guideline que todo aplicativo que implementar o SDK deverá seguir. [https://developer.apple.com/design/human-interface-guidelines/technologies/tap-to-pay-on-iphone/](https://developer.apple.com/design/human-interface-guidelines/technologies/tap-to-pay-on-iphone/)


- Exibir de forma fácil para o usuário as chamadas telas de educação que contam com um tutorial de como utilizar o framework da Apple para pagamentos, contendo uma explicação da possibilidade de pagamento por um cartão comum ou Apple Pay (Também abrangente a outras carteiras digitais) e que o PIN do cartão poderá ser solicitado caso necessário. Tais telas deverão obrigatoriamente ser apresentadas após a primeira inicialização do SDK além de serem acessíveis a qualquer momento em uma área de ajuda ou configurações após a primeira inicialização. Todas as imagens utilizadas deverão ser as fornecidas pela Apple e não poderão sofrer alterações. A Cielo irá prover dentro do SDK uma função para apresentação dessas telas.


- O aplicativo deverá contar com um controle de usuário para que somente um administrador do estabelecimento comercial possa dar o aceite nos termos e condições da Apple. Para aceitar os termos será necessário um Apple ID.


- O app deve ter preenchido na sua info.plist o parâmetro “NSUserTrackingUsageDescription” com uma mensagem reference à coleta de dados para log


- Qualquer invocação ao SDK deverá seguir o padrão estipulado pela Apple. Um botão com o texto “**Tap to Pay no iPhone**” ou “**Tap to Pay**” se não houver espaço. Caso seja escolhido utilizar um ícone junto do botão ele obrigatoriamente deverá ser `wave.3.right.circle` ou `wave.3.right.circle.fill`

**Requisitos técnicos do SDK**

| ****Requisitos**** 
| ****iOS**** 
|


| **Versão mínima do Sistema Operacional** 
| iOS 18.5 
|


| **Acesso à internet** 
| Sim 
|


| **Mínimo de espaço livre no dispositivo** 
| 50mb 
|


| **NFC no Dispositivo** 
| Sim 
|


| **Dispositivo** 
| iPhone XS ou mais recente 
|

**Requisitos do Sistema para Desenvolvimento**

| ****Requisitos**** 
| ****iOS**** 
|


| **IDE** 
| XCode 15+ recomendado 
|


| **Swift** 
| Swift 5+ 
|


| **Conta de sandbox** 
| Para testes em HML é necessário ter uma conta de sandbox. Para maiores informações sobre como criar, acesse esse [link](https://developer.apple.com/help/app-store-connect/test-in-app-purchases/create-a-sandbox-apple-account). 
|

**Adicionando o SDK ao seu projeto**

Inicialmente abra o projeto do seu aplicativo no XCode. Depois selecione o projeto e o seu target:

A seguir localize os arquivos enviados VisaSensoryBranding.xcframework, AllowMeSDK.xcframework, AllowMeSDKHomolog.xcframework e TapOnPhoneWrapper.xcframework:

a) Arrastar a partir do Finder para o campo “*Frameworks, Libraries and Embedded Content*”

b) Clicar sobre o botão "+” dentro da mesma área, localizar os arquivos e clicar em “Add”


![Imagem2-20240726-165446.png](images-ios/img_02.png)

Por fim, no arquivo que vai utilizar o componente realizar o import do “TapOnPhoneWrapper”

```kotlin
import TapOnPhoneWrapper
```

# Depreciação do AppleTapPayment para iOS 18.4 ou posteriores

A partir da versão 18.4, o iOS passa a estar em conformidade com a especificação PCI-SSC (Payment Card Industry - Security Standard Council) como uma Solução MPoC válida. Para garantir essa conformidade em futuras versões, o Tap to Pay no iPhone será compatível apenas com versões do iOS até um ano após a data de lançamento de cada versão.

Versões anteriores à 18.4 que foram aprovadas pelas bandeiras continuarão funcionando, mas agora respeitando o processo anual de depreciação implementado para as versões mais recentes.


## **Orientações para iOS 18.4 e versões posteriores **

O iOS 18.4 introduz um recurso que exibe um lembrete periódico de atualização do iOS para comerciantes na interface do Tap to Pay no iPhone, antes que o suporte para a versão do iOS no dispositivo seja encerrado.

O Tap to Pay no iPhone verifica a atualização durante a chamada *initializer* e adapta os lembretes ao idioma do dispositivo do comerciante. Cada alerta especifica uma data limite para que o comerciante realize a atualização, oferecendo a opção de ir diretamente para a seção *Atualização de Software* nos Ajustes do iOS.

O lembrete aparece uma vez por semana, 90 dias antes da data de descontinuação, e uma vez por dia, 3 dias antes da data de descontinuação.

A data de descontinuação está disponível na tabela abaixo.


## **Orientações para iOS 17.6 e versões posteriores**

Quando uma versão do iOS é descontinuada e removida da lista de versões suportadas, a chamada *initializer* retorna **osVersionNotSupported** e o Tap to Pay no iPhone exibe aos comerciantes uma notificação para atualizar para a versão mais recente do iOS.


## **Orientações para versões anteriores do iOS**

Em versões anteriores ao iOS 17.6, a chamada *initializer* retorna **osVersionNotSupported**, mas nenhuma notificação é exibida aos comerciantes na interface do Tap to Pay no iPhone.

Observe que a Apple também enviará e-mails para todos os comerciantes que estiverem usando uma versão do iOS anterior à 18.4, solicitando que atualizem para a versão mais recente do iOS pelo menos 3 meses antes da data de descontinuação.


## Tabela de Descontinuação de Versões do iOS para Tap to Pay no iPhone

| ****Versão do iOS**** 
| ****Data de Lançamento**** 
| ****Data de Descontinuação**** 
|


| iOS 18.5 
| 12 maio 2025 
| 12 maio 2026 
|


| iOS 18.4.1 
| 16 abril 2025 
| 16 abril 2026 
|


| iOS 18.4 
| 31 março 2025 
| 31 março 2026 
|


| iOS 18.3.2 
| 11 março 2025 
| 11 março 2026 
|


| iOS 18.3.1 
| 10 fevereiro 2025 
| 11 março 2026 
|


| iOS 18.3 
| 27 janeiro 2025 
| 27 janeiro 2026 
|


| iOS 18.2.1 
| 6 janeiro 2025 
| 27 janeiro 2026 
|


| iOS 18.2 
| 11 dezembro 2024 
| 27 janeiro 2026 
|


| iOS 18.1.1 
| 19 novembro 2024 
| 19 novembro 2025 
|


| iOS 18.1 
| 28 outubro 2024 
| 19 novembro 2025 
|


| iOS 18.0.1 
| 3 outubro 2024 
| 19 novembro 2025 
|


| iOS 18.0 
| 16 setembro 2024 
| 16 setembro 2025 
|


| iOS 17.7.2 
| 19 novembro 2024 
| 19 novembro 2025 
|


| iOS 17.7.1 
| 28 outubro 2024 
| 19 novembro 2025 
|


| iOS 17.7 
| 16 setembro 2024 
| 16 setembro 2025 
|


| iOS 17.6.1 
| 7 agosto 2024 
| 16 setembro 2025 
|


| iOS 17.6 
| 29 julho 2024 
| 16 setembro 2025 
|


| iOS 17.5.1 
| 20 maio 2024 
| 16 setembro 2025 
|


| iOS 17.5 
| 13 maio 2024 
| 16 setembro 2025 
|


| iOS 17.4.1 
| 26 março 2024 
| 16 setembro 2025 
|


| iOS 17.4 
| 5 março 2024 
| 16 setembro 2025 
|


| iOS 17.3.1 
| 8 fevereiro 2024 
| 16 setembro 2025 
|


| iOS 17.3 
| 22 janeiro 2024 
| 16 setembro 2025 
|


| iOS 17.2.1 
| 19 dezembro 2023 
| 16 setembro 2025 
|


| iOS 17.2 
| 11 dezembro 2023 
| 16 setembro 2025 
|


| iOS 17.1.2 
| 30 novembro 2023 
| 16 setembro 2025 
|


| iOS 17.1.1 
| 7 novembro 2023 
| 16 setembro 2025 
|


| iOS 17.1 
| 25 outubro 2023 
| 16 setembro 2025 
|


| iOS 17.0.3 
| 4 outubro 2023 
| 16 setembro 2025 
|


| iOS 17.0.2 
| 26 setembro 2023 
| 16 setembro 2025 
|


| iOS 17.0.1 
| 21 setembro 2023 
| 16 setembro 2025 
|


| iOS 17.0 
| 18 setembro 2023 
| 16 setembro 2025 
|


| iOS 16.7.2 
| 25 outubro 2023 
| 16 setembro 2025 
|


| iOS 16.7.1 
| 10 outubro 2023 
| 16 setembro 2025 
|


| iOS 16.7 
| 21 setembro 2023 
| 16 setembro 2025 
|

# Capability de background

Temos alguns processamentos que ocorrem em background, porém é opcional, caso queira habilitar é "Background Fetch" e “Background processing", conforme apresentando na imagem abaixo.


![image-20241108-135643.png](images-ios/img_31.png)

# Configuração de inicialização

O processo de inicialização pode ser feito no ViewController que precede o pagamento.

Exemplo de inicialização:

```kotlin
let config = TapConfigBuilder()
.initClient(clientID: "[CLIENT_ID]", clientSecret: "[CLIENT_SECRET]")
.loadWhiteLabel(fileName: "[ARQUIVO_WHITELABE].json", bundle: Bundle.main)
.setCNPJ(cnpj: "[CNPJ]") // ou .setCPF(cpf: "[CPF]")
.build()
```

Detalhe da construção do config:

**TapConfigBuilder**

**initClient:**

**client id (String)**: id único por cliente disponibilizado pela Cielo na aquisição.​

**client secret (String)**: secret do cliente informado pela Cielo na aquisição.​

**loadWhiteLabel:**

**fileName (String): **nome do arquivo de customizações visuais. Este é um arquivo em formato json com as customizações de *white label*. As definições do arquivo estão mais abaixo.

**bundle(Bundle)(Opcional): **bundle onde se encontra o arquivo que irá ser carregado. Caso nenhum valor seja fornecido irá ser usado o *bundle.main*.

**setCNPJ (cnpj: String) / setCPF (cpf: String): **número de documento do contratante (CNPJ / CPF).

**build: **retorna um objeto TapConfig com base nos dados informados nos métodos anteriores.


### Erros Possíveis:

- TapErrors.conversionFailed: levantado se o dado de entrada for inválido ou o arquivo for inexistente


- TapErrors.invalidJson: erro levantado quando o formato do json informado for inválido

## **Método WarmUp **

Método utilizado para realizar um pré carregamento de alguns componentes em vista a otimizar o tempo de inicialização transacional. Recomendamos que chame esse método o mais cedo possível dentro da sua aplicação.

Esse é um método não obrigatório que poderá ser utilizado na instalação do produto para ganho de tempo no nomento da inicialização. Sugerimos que esse método seja chamado uma única vez na primeira utilização do produto nesse aparelho.

Método executado em segundo plano.

```kotlin
TapOnPhoneWP.shared.warmUp(config: config)
```

**Descrição dos parâmetros:**

**config (TapConfig): **objeto de configuração construído no passo anterior, com os dados de acesso.


## **Método isAccountLinked**

Método para verificar se a conta do usuário atual está linkada com o Apple Tap to Pay, e tem como retorno boolean. Precisa ser executada depois do método Initialize para ser mais rápido. É um método async e deve ser executado com await.

Se o SDK não estiver inicializado, essa chamada irá executar a coleta dos tokens da apple.

```kotlin
await TapOnPhoneWP.shared.isAccountLinked(config: config)
```

**Descrição dos parâmetros:**

**config (TapConfig): **objeto de configuração construído no passo anterior, com os dados de acesso.


### Erros possíveis

- errorLinkingAccount(error): retorna um erro caso haja algum problema no processo de verificação. Possui um parâmetro de erro para análise do erro interno.

## **Método isSupported**

Esse método retorna um boolean indicando se o device que está executando o SDK suporta ou não o Apple Tap to Pay

```kotlin
TapOnPhoneWP.shared.isSupported()
```

## **Método initialize**

Método responsável por inicializar o SDK e carregar dados iniciais do usuário como chaves de inicialização, executar diversos procedimento de segurança, e validação de parceiro.

Para iniciar o método Initialize, basta seguir o exemplo abaixo:

```kotlin
TapOnPhoneWP.shared.initialize(
view: self.view,
config: config,
silentInit: false,
defaultLoading: true,
defaultErrorScreen: true,
start: {},
completion: {result in
switch result {
case .success:

case .failure(let error):
}
},
onLog: {})
```

**Descrição dos parâmetros:**

**view (UIView): **ViewController chamadora do processo.

**config (TapConfig): **objeto de configuração construído no passo anterior, com os dados de acesso.

**silentInit(bool): **Executa uma inicialização silenciosa, parâmetro não obrigatório com valor default false.

**defaultLoading (Bool): **campo booleano para mostrar ou não uma tela de loading durante a inicialização, por default esse campo é true. Caso o valor passado seja false, a aplicação não irá mostrar nenhuma tela de load durante as operações longas, sendo necessário que você as implemente.

**defaultErrorScreen(bool):** Se será usada as telas padrões de erros do sdk, parâmetro não obrigatório com valor default true.

**start ((() -> Void)): **callback chamado quando o processo de initialize se inicia. Recomendamos que, caso possua uma animação de load customizada, a inicie neste ponto.

**completion(@escaping (Result<Void,TapErrors>) -> Void): **callback chamado quando o método initialize completa todos os seus processos, podendo retornar *success *em caso de sucesso em todos os processos ou *failure *em caso de alguma problema ocorra, neste caso voltamos o tipo de erro que ocorreu. Mais abaixo uma lista dos erros levantados.

**onLog((Void, String) -> Void): **Com esse método você pode obter os logs do sdk. Os tipos de log são:

1. **.debug: **Log do tipo debug

2. **.info: **Log do tipo informação

3. **.notice: **Log do tipo noticia

4. **.warn: **Log do tipo aviso

5. **.error: **Log do tipo erro

6. **.critical: **Log do tipo erro critico


## **Método initJourney**

Este método irá exibir as telas responsáveis por coletar os dados de pagamento. Essas telas são personalizáveis de acordo com as especificações de white label (na seção de white label do manual, mais abaixo). A execução das telas retorna um objeto contendo os dados de pagamento que deve ser usado para chamar o método de pagamento (initPayment). A chamada das telas é opcional, caso possua a suas telas para o mesmo fim.

A jornada possui duas telas: a **input price**, que pede que seja inserido um valor para pagamento, e a **payment method**, que permite a seleção do tipo de pagamento e parcelamento.

Descrição dos parâmetros:

- **view (UIViewController)**: view que fez a chamada do método.


- **data (TapPaymentData)**: dados de pagamento. Neste caso funciona como dados padrão que podem ser alterados pela tela durante o preenchimento.


- **step (TapPaymentStep)**: tela inicial da jornada. Possui as seguintes opções:​

- **.INPUT_PRICE:** inicia a jornada na tela de input de valores​.


- **.PAYMENT_METHOD**: inicia a jornada pela tela de seleção de tipo de pagamento​.

- **onHelp (() -> Void)**: método chamado para habilitar e configurar a ação o botão Help. Caso não seja passado nenhum código, o botão ficará oculto.

- **onEnd((TapPaymentData) -> Void)**: método chamado quando o usuário termina de preencher a jornada de telas. Ele retorna os dados preenchidos dentro do objeto TapPaymentData. Esses dados servem de input para o método de pagamento.​


Para iniciar a transação com as telas, o código é o seguinte:​

```kotlin
TapOnPhoneWP.shared.initJourney(view: self.view,
data:[Dados da inicialização] ,
step: .INPUT_PRICE, 
onHelp: {

}, onEnd: { tapPaymentData in

}
)
```

## **Método InitPayment**

A partir da **versão 1.7.0**, estaremos disponibilizando duas opções de initPayment, com parâmetros de sobrecarga diferentes, portanto, leia com atenção e escolha a que mais e adequa a sua implementação. Abaixo, segue a descrição detalhada de cada uma delas

### **Método InitPayment(onComplete) **

Método chamado para transacionar o pagamento, no qual ira receber o callback(onComplete) somente quando pressionado sobre o botão “Ver comprovante" da tela de sucesso. Em caso erro, será recebido o callback depois do fechamento da tela de error

**Descrição dos parâmetros:**

- **view (UIViewController):** view atual usada como contexto para exibição das telas necessárias


- **config (TapConfig)**: config com os dados de configuração. O mesmo informado na inicialização.


- **data (TapPaymentData)**: os dados de pagamento, retornados pela jornada de telas de pagamento ou preenchido com o resultado da suas próprias telas.


- **onStart (((UIViewController) async -> Void)?):** evento chamado quando inicializa o método initPayment. Caso esteja utilizando uma animação de load customizada, este é o momento recomendado para inicia-la.


- **onLoadComplete (() -> Void): **evento chamado quando o loader customizado deve ser dispensado


- **onComplete((Result<Void, Error>) -> Void):** método chamado quando o pagamento completa todos os seus processos, podendo ser success ou failure em caso de algum problema. Mais a frente existe a seção com os tipos de erros retornados.​


**Exemplo:**

```kotlin
Task {
await TapOnPhoneWP.shared.initPayment(config: config, data: jData, onStart: { vc in
print("start")
}, 
onLoadComplete: {},
onComplete: { result in
switch result {
case .success:
case .failure(let error):
}
})
}
```

### **Método InitPayment (onPaymentSuccess, onPaymentError)**

Método chamado para transacionar o pagamento, no qual ira receber o onPaymentSuccess logo após a animação da bandeira. Em caso erro, será recebido o callback depois do fechamento da tela de error

**Descrição dos parâmetros:**

- **view (UIViewController): **view atual usada como contexto para exibição das telas necessárias


- **config (TapConfig): **config com os dados de configuração. O mesmo informado na inicialização.


- **data (TapPaymentData): **os dados de pagamento, retornados pela jornada de telas de pagamento ou preenchido com o resultado da suas próprias telas.


- **onStart (((UIViewController) async -> Void)?): **evento chamado quando inicializa o método initPayment. Caso esteja utilizando uma animação de load customizada, este é o momento recomendado para inicia-la.


- **onLoadComplete (() -> Void): **evento chamado quando o loader customizado deve ser dispensado


- **onPaymentSuccess: ((Transaction) -> Void)?: **método chamado quando o pagamento completado com sucesso. Esse callback, e emitido logo após a execução da animação da bandeira.


- **onPaymentError:((Error) → Void)?:** método chamado quando ocorre uma falha durante o pagamento. Mais a frente existe a seção com os tipos de erros retornados.​


**Exemplo:**

```kotlin
Task {
await TapOnPhoneWP.shared.initPayment(config: config, data: jData, onStart: { vc in
print("start")
}, 
onLoadComplete: {},
onPaymentSuccess: { result in
...
},
onPaymentError: { result in
...
})
}
```

# **Método getSaleList**

Método responsável por retornar os dados básico as vendas realizadas por este terminal. Retorna um objeto com os dados carregados bem com informações de paginação e método para carga de novos dados de acordo com a paginação configurada.

Descrição dos parâmetros:

- **config (TapConfig): **mesmo parâmetro obrigatório solicitado na função *initialize***.**


- **onSuccess (TapSalesListCallback):** Método chamado após concluir com sucesso, a coleta da lista e paginar os dados, retorna os dados no formato `TapSalesListCallback`.


- **onFailure (Error): **Método chamado quando ocorre algum erro ao tentar pegar lista, retorna o erro obtido.


Para iniciar o método, bata seguir o exemplo:

```kotlin
await TapOnPhoneWP.shared.getSalesList(config: config,
onSuccess: { response in 

}, onFailure: { error in 

})
```

A seguir a estrutura do objeto TapSalesListCallback, com os dados retornados

```kotlin
struct TapSalesListCallback {
var data: [TapTransactionModel]?
var pagination: TapPagination
public func loadMore()
}


struct TapPagination {
var currencyPage: Int
var pageSize: Int = 0
var limitItemsPerPage: Int = 10
}
```

Os dados vem na seguinte estrutura

```kotlin
public class TapTransactionModel: Codable {

public var paymentId: String?
public var merchantOrderId: String?
public var status: Int?
public var date: Date?
public var brand: String?
public var transactionType: String?
public var amount: Double?
public var aid: String?
public var installments: Int?
public var loadingCard: Bool?
public var emvData: String?
public var issuerScriptResults: String?
public var localStatus: Int?

}
```

# **Método getSaleDetails:**

Método responsável por retornar os dado detalhados de uma venda em particular.

Descrição dos parâmetros:

- **paymentId (String): **Dado utilizado como chave para consultar as informações de venda.


- **config (TapConfig): **mesmo parâmetro obrigatório solicitado na função *initialize*.


- **onSuccess(TapSaleDetailResponse): **Callback chamado quando a consulta de informações é realizada com sucesso.​​ Retornando um modal com as informações da venda realizada


- **onFailure(Error)**: Callback chamado quando ocorre um erro durante o fluxo.


Para iniciar esse método basta seguir o exemplo abaixo:

```kotlin
await TapOnPhoneWP.shared.getSaleDetails(paymentId: "PAYMENT_ID", config: TapConfig,
onSuccess: { response in 

}, onFailure: { error in 

})
```

```kotlin
public class TapSaleDetailResponse: Codable {
var paymentId: String?
var merchantOrderId: String?
var status: Int?
var amount: Int?
var installment: Int?
var authorizationId: String?
var transactionDate: String?
var cardFirstNumbers: String?
var cardLastNumbers: String?
var nsu: String?
var receiptHour: String?
var receiptDate: String?
var transactionType: String?
var merchantAddress: String?
var cpfcnpj: String?
var merchantName: String?
}
```

# **Método showAgenda**

Este método inicia a exibição da jornada de agenda, que permite que o usuário consulte em tela as transações realizadas pelo terminal corrente, veja o seus detalhes e, também, inicie o processo de cancelamento de alguma transação em particular.

Para iniciar a jornada de agenda, o código é o seguinte:

```kotlin
TapOnPhoneWP.shared.showAgenda(view: self, config: config, onDetailsLoadStart{ vc in
}, onDetailsLoadEnd: { vc in },
onCancel: @escaping (TapSaleDetailResponse?) -> Void)
```

Onde:

- **view (UIViewController)**: ViewController chamando a agenda


- **config (TapConfig): **mesmo parâmetro obrigatório solicitado na função *initialize*.


- **onDetailsLoadStart (((UIViewController) async -> Void)? = nil):** callback chamado quando o usuário vai chamar a tela para ver os detalhes de uma transação. Se estiver implementando um loader customizado é nesse momento que ele deverá ser chamado


- **onDetailsLoadEnd: (((UIViewController) async -> Void)? = nil):** callback chamado quando acaba de carregar a tela de detalhes de uma transação. Caso esteja usando um loader customizado, esse é o momento de remove-lo


- **onCancel (@escaping (TapSaleDetailResponse?) -> Void):** closure de callback chamada quando o usuário realizar o cancelamento de uma transação. Esse callback é chamado na solicitação do usuário, onde deve-se chamar o método initCancelation

# **Método initCancelation**

Método que inicia o fluxo de cancelamento de uma transação.

Para iniciar esse método basta seguir o exemplo abaixo:

```kotlin
TapOnPhoneWP.shared.initCancelation(view: self, 
config: config, 
data: saleResponse,
onStart: { vc in },
onLoadComplete: { vc in },
onComplete: ((Result<Void, Error>) -> Void)?){ result in

}
```

Onde:

- **view (UIViewController)**: ViewController chamando o fluxo de cancelamento.


- **config (TapConfig): **Mesmo parâmetro obrigatório solicitado na função *initialize*.


- **data (TapSaleDetailResponse): **Objeto do `SaleDetailResponse` referente a transação a ser cancelada.


- **onStart (((UIViewController) async -> Void)?):** callback chamado quando se inicia o processo de callback. Caso possua um loader customizado, deve-se apresenta-lo agora


- **onLoadComplete ((() async -> Void)?):** callback invocado quando o processo de pré cancelamento para. Caso esteja usando um loader customizado, este é o momento para dispensa-lo.


- **onComplete ((Result<Void, Error>) -> Void):** callback invocado quando o cancelamento é realizado. É do tipo result então indica sucesso ou falha na operação. Em caso de falha o erro se encontra no parâmetro Error.

# **Método showEducationScreen**

Esse método irá retornar a tela inicial da sequencia de telas de educação do comerciante requeridas pela Apple. É um método async e deve ser executado com await.

Para executar o método, o código é o seguinte:

```kotlin
Task {
await TapOnPhoneWP.shared.showEducationScreen(view: self)
}
```

Onde:

- **view (UIViewController)**: ViewController que chamará a tela.

# **Método cleanUp**

Esse método irá limpar os objetos da biblioteca de pagamento Apple da memória.

Para executar o método, o código é o seguinte:

```kotlin
TapOnPhoneWP.shared.cleanUp()
```

# **Método isUserActive**

Esse método irá iniciar uma verificação se o usuário está ativo, comparando a data de ultima transação com a data atual, e retornará um Bool (True para igual ou menor que 30 dias; False para maior que 30 dias)

Para executar o método, o código é o seguinte:

```kotlin
TapOnPhoneWP.shared.isUserActive()
```

# **Métodos do TapOnPhoneDelegateWP **

Para permitir uma melhor integração do parceiro com o SDK foram criados métodos chamados em no final do fluxo, no recibo. São eles:

- `onNewSale()`: Método chamado no botão "Nova Venda" após realizar uma venda.

- `onMySales()`: Método chamado no botão "Minhas Vendas" no recibo de cancelamento.


![image-20240829-213929.png](images-ios/img_27.png)

- `onCloseReceipt()`: Método chamado no botão "Fechar" de ambos comprovantes.


![image-20240829-214145.png](images-ios/img_05.png)

## Método initFakeTransactionJourney

Para utilizar venda teste é necessário ter executado uma inicialização.

O initFakeTransactionJourney é responsável por coletar os dados para criar uma venda teste. Essas telas são personalizáveis de acordo com as especificações de white label (na seção de white label do manual, mais abaixo). A execução das telas retorna um objeto contendo os dados de pagamento para venda teste que, deve ser usado para chamar o método de pagamento (fakeTransactionInitPayment).

A jornada possui três telas: a **introduction, **que trás informações para o cliente final a respeito da venda teste**,** a **input price**, que pede que seja inserido um valor para pagamento, e a **payment method**, que permite a seleção do tipo de pagamento e parcelamento.

Introduction

Input price

Payment method

Descrição dos parâmetros:

- **view (UIViewController)**: view que fez a chamada do método.


- **config (TapConfig): **objeto de configuração construído no passo anterior, com os dados de acesso.


- **data (TapPaymentData)**: dados de pagamento. Neste caso funciona como dados padrão que podem ser alterados pela tela durante o preenchimento.


- **step (TapPaymentStep)**: tela inicial da jornada. Possui as seguintes opções:​

- **.INTRODUCTION:** inicia a jornada na tela de introdução.


- **.INPUT_PRICE:** inicia a jornada na tela de input de valores​.


- **.PAYMENT_METHOD**: inicia a jornada pela tela de seleção de tipo de pagamento​.

- **onHelp (() -> Void)**: método chamado para habilitar e configurar a ação o botão Help. Caso não seja passado nenhum código, o botão ficará oculto.

- **onEnd((TapPaymentData) -> Void)**: método chamado quando o usuário termina de preencher a jornada de telas. Ele retorna os dados preenchidos dentro do objeto TapPaymentData. Esses dados servem de input para o método de pagamento.​


Para iniciar a transação com as telas, o código é o seguinte:​

```kotlin
TapOnPhoneWP.shared.initJourney(view: self.view,
data:[Dados da inicialização] ,
step: .INTRODUCTION, 
onHelp: {
}, onEnd: { tapPaymentData in
}
)
```

## **Método fakeTransactionInitPayment**

Para utilizar venda teste é necessário ter executado uma inicialização.

Ao chamar esse método, será executada a tela de aproximação do cartão. Por se tratar de uma venda teste, não será apresentada telas de animação da bandeira e comprovante, será exibida apenas tela de sucesso.

Descrição dos parâmetros:

- **view (UIViewController):** view atual usada como contexto para exibição das telas necessárias


- **config (TapConfig): **config com os dados de configuração. O mesmo informado na inicialização.


- **data (TapPaymentData)**: os dados de pagamento, retornados pela jornada de telas de pagamento ou preenchido com o resultado da suas próprias telas.


- **onStart (((UIViewController) async -> Void)?)**: evento chamado quando inicializa o método initPayment. Caso esteja utilizando uma animação de load customizada, este é o momento recomendado para inicia-la.


- **onLoadComplete (() -> Void):** evento chamado quando o loader customizado deve ser dispensado


- **onComplete((Result<Void, Error>) -> Void)**: método chamado quando o pagamento completa todos os seus processos, podendo ser *sucess* ou *failure* em caso de algum problema. Mais a frente existe a seção com os tipos de erros retornados.​


Exemplo:

```kotlin
Task {
await TapOnPhoneWP.shared.fakeTransactionInitPayment(
view: self.view,
config: config, 
data: jData, 
onStart: { vc in
print("start")
}, 
onLoadComplete: {},
onComplete: { result in
switch result {
case .success:
case .failure(let error):
}
})
}
```

# **Customização**

O arquivo JSON contém as customizações visuais aplicáveis aos componentes. O conteúdo deste arquivo é carregado via config na inicialização. Existe uma função de apoio para carregar um arquivo json a partir de um bundle.

Existe duas formas de aplicar estilo em um componente:​

- Na primeira forma o usuário altera os estilos de um determinado tipo de controle, como labels, botões e outros. Um exemplo disso seria:​


"button": {​

"textButtonColor": "#000000",​

"backgroundButtonColor": "#FFFFFF",​

"borderButtonColor": "#000000"​

}

Abaixo o exemplo de JSON que deve ser informado:

- A segunda forma é através de cada instância de controle. Nesse caso somente é alterado um controle, como um botão determinado de uma tela determinada:​


”button1ScreenA": {​

"textButtonColor": "#000000",​

"backgroundButtonColor": "#FFFFFF",​

"borderButtonColor": "#000000"​

}​


### Customizando a fonte do app

As telas padrão definidas no framework utilizam a fonte Montserrat. Caso queria trocar de fonte existem alguns passos que devem ser realizados antes de definir o nome da fonte nos arquivos do White Label.

- Copie o arquivo de fonte para dentro do seu projeto em uma pasta de recursos


- Marque o projeto no Target Membership do arquivo. Essa propriedade está no File Inspector (com o arquivo selecionado)

![Imagem5-20240726-172600.png](images-ios/img_32.png)

- Localize o arquivo info.plist dentro do seu projeto. Caso não exista vá até o projeto, depois selecione o target e ele estará na aba info

- Inclua a chave “Fonts provided by application”. Essa chave é um array, então pode-se incluir dentro dele todas as fontes que forem ser usadas.


- Inclua um item e nesse item defina o nome do arquivo de fonte com extensão


- Repita o passo 4 para demais fontes que deseja incluir

![Imagem4-20240726-172336.png](images-ios/img_14.png)

Depois de importar a fonte, basta usar o seu nome nos arquivos de WL, onde aplicável

Em ambos os casos a estrutura de customização é no formato json, onde o nome do objeto é o nome do controle ou tipo do controle (“button1” e “button” por exemplo respectivamente). Além disso são cadastradas as propriedades. Cada tipo de controle tem algumas propriedades. A relação completa das propriedades e dos controles está abaixo.


### Header Flui

```kotlin
"headerFlui": {
"statusBarBackgroundColor": "#000000",
"navigationBackgroundColor": "#000000",
"backgroundColor": "#000000",
"buttonBackColor": "#000000",
"buttonHelpColor": "#000000",
"buttonTextColor": "#000000",
}
```

- `statusBarBackgroundColor`: cor de fundo da status bar


- `navigationBackgroundColor`: cor de fundo da navigation


- `backgroundColor`: cor de fundo do header (**ATENÇÃO: PROPRIEDADE DEPRECIADA**)


- `buttonBackColor`: cor do botão de voltar


- `buttonHelpColor`: cor do botão de ajuda


- `buttonTextColor`: cor do texto

### Label Flui

```kotlin
"labelFlui": {
"colorText": "#000000",
"fontName": "Times New Roman",
"fontSize": 16.0
}
```

- colorText: altera a cor do label


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### ButtonBlock

```kotlin
"buttonBlock": {
"color": "#0000CD",
"disabledColor": "#ADD8E6",
"textColor": "#FFFFFF",
"disabledTextColor": "#FFFFFF",
"borderColor": "#00B8E0",
"disabledBorderColor": "#E012CF",
"fontName": "Times New Roman",
"fontSize": 16.0
}
```

- color: altera a cor de background do botão


- disabledColor: altera a cor de background do botão quando ele está desativado


- textColor: altera a cor do texto do botão


- disabledTextColor: altera a cor do texto do botão quando ele está desabilitado


- borderColor: altera a cor da borda do botão, quando aplicável (nem todos os botões possuem borda)


- disabledBorderColor: altera a cor da borda do botão, em estado desabilitado, quando aplicável (nem todos os botões possuem borda)


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Input with Edit

```kotlin
"inputWithEdit": {
"colorSaleValue": "#A56D5F",
"colorValue": "#FA603B",
"colorButtonEdit": "#504947",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorSaleValue: altera a cor do texto exibido sobre o valor, quando houver


- colorValue: altera a cor do valor e do simbolo monetário


- colorButtonEdit: altera a cor do botão de edição, quando estiver visível


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Radio

```kotlin
"radio": {
"colorText": "#2F363E",
"colorSelectedText": "#2F363E",
"colorRadio": "#C5CED7",
"colorSelectedRadio": "#2F363E",
"colorBorder": "#C5CED7",
"colorSelectedBorder": "#2F363E",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorText: altera a cor do texto do radio


- colorSelectedText: altera a cor do texto do radio quando o mesmo está selecionado


- colorRadio: altera a cor do circulo do radio


- colorSelectedRadio: altera a cor do circulo do radio, quando o mesmo esta selecionado


- colorBorder: altera a cor da borda do radio, a mesma que envolve tanto o radio (circulo), quando o texto


- colorSelectedBorder: altera a cor da borda do radio, quando o mesmo está selecionado


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Installments Details

```kotlin
"installmentsDetails":{
"colorBackground": "#FAC000",
"colorTitle": "#FA1400",
"colorIcon": "#FA1400",
"colorInstallments": "#FA1400",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorBackground: altera a cor de fundo dos detalhes de parcel


- colorTitle: altera a cor do texto padrão


- colorIcon: altera a cor do ícone exibido no controle


- colorInstallments: altera a cor do label que exibe a quantidade de parcelas e o valor de cada parcela


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Bottom Sheet Flui

```kotlin
"bottomSheetFlui": {
"colorTitle": "#2F363E",
"colorCloseButton": "#5C6A7B",
"colorRadioText": "#2F363E",
"colorRadioSelectedText": "#2F363E",
"colorRadio": "#C5CED7",
"colorRadioSelected": "#2F363E",
"colorButton": "#5C6A7B",
"colorButtonDisabled": "#C5CED7",
"colorButtonText": "#FFFFFF",
"colorButtonTextDisabled": "#FFFFFF",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorTitle: altera a cor do titulo do bottom sheet


- colorCloseButton: altera a cor do botão de fechar, o “x”


- colorRadioText: altera a cor do texto de cada opção de seleção


- colorRadioTextSelected: altera a cor do texto de cada opção de seleção, somente da linha selecionada


- colorRadio: altera a cor do círculo de seleção


- colorRadioSelected: altera a cor do círculo de seleção, somente do item selecionado


- colorButton: altera a cor de fundo do botão


- colorButtonDisabled: altera a cor de fundo do botão quando o mesmo está desabilitado


- colorButtonText: altera a cor do texto do botão


- colorButtonTextDisabled: altera a cor do texto do botão, para quando o mesmo está desabilitado


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Sale Card

```kotlin
"saleCard":{
"colorTextStatusApproved": "#FF6347",
"colorStatusApproved": "#4169E1",
"colorTextStatusCanceled": "#20B2AA",
"colorStatusCanceled": "#8A2BE2",
"colorTextStatusContested": "#32CD32",
"colorStatusContested": "#FFD700",
"colorTextPaymentMethod": "#FFA07A",
"colorTextDateTime": "#9370DB",
"colorTextPrice": "#00FF7F",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorTextStatusApproved: cor do texto do card quando o status de uma transação é aprovado


- colorStatusApproved: cor de fundo do indicador de status, quando o status da transação é aprovado


- colorTextStatusCanceled: cor do texto do indicador de status quando o status de uma transação é canceladoou


- colorStatusCanceled: cor de fundo do indicador de status, quando o status de uma transação é cancelado


- colorTextStatusContested: cor do texto do indicador de status, quando o status de uma transação é contestado


- colorStatusContested: cor de fundo do indicador de status, quando o status de uma transação é contestado


- colorTextPaymentMethod: cor do texto que indica o tipo da transação


- colorTextDateTime: cor do texto que indica a data ou hora da transação


- colorTextPrice: cor do texto que mostra o valor da transação


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Sale Detail Status

```kotlin
"saleDetailStatus":{
"colorTextStatusApproved": "#FF6347",
"colorStatusApproved": "#4169E1",
"colorTextStatusCanceled": "#20B2AA",
"colorStatusCanceled": "#8A2BE2",
"colorTextStatusContested": "#32CD32",
"colorStatusContested": "#FFD700",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorTextStatusApproved: cor do texto do card quando o status de uma transação é aprovado


- colorStatusApproved: cor de fundo do indicador de status, quando o status da transação é aprovado


- colorTextStatusCanceled: cor do texto do indicador de status quando o status de uma transação é cancelado


- colorStatusCanceled: cor de fundo do indicador de status, quando o status de uma transação é cancelado


- colorTextStatusContested: cor do texto do indicador de status, quando o status de uma transação é contestado


- colorStatusContested: cor de fundo do indicador de status, quando o status de uma transação é contestado


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Loader

```kotlin
"loader": {
"colorBackground": "#FFFFFF",
"interval": 2000,
"messages": [
"Carregando as informações necessárias...",
"Aguarde um momento...",
"Estamos finalizando..."
],
"colorText": "#2F363E",
"colorLoader": "#2F363E",
"fontName": "Times New Roman",
"fontSize": 16.0 
}
```

- colorBackground: cor de fundo da tela de load


- interval: tempo em milissegundos em que as mensagens são trocadas


- messages: uma coleção de mensagens que serão exibidas na tela de load


- colorText: cor do texto das mensagens exibidas


- colorLoader: cor do loader da tela


- fontName: nome da fonte que deve ser aplicada


- fontSize: tamanho da fonte em pontos

### Receipt

```kotlin
"receipt": {
"closeIconColor": "#000000",
"background": "#000000",
"shareButtonBorderColor": "#000000",
"shareButtonTitleColor": "#000000",
"shareButtonBackground": "#000000",
"newSaleBorderColor": "#000000",
"newSaleTitleColor": "#000000",
"newSaleBackground": "#000000"
},
```

- `closeIconColor`: cor do icone fechar


- `background`: cor do fundo da tela de comprovante


- `shareButtonBorderColor`: cor da borda do botão compartilhar


- `shareButtonTextColor`: cor do texto do botão compartilhar


- `shareButtonBackground`: cor do fundo do botão compartilhar


- `newSaleBorderColor`: cor da borda do botão nova venda ou minhas vendas


- `newSaleTitleColor`: cor do texto do botão nova venda ou minhas vendas


- `newSaleBackground`: cor do fundo do botão nova venda ou minhas vendas

### WarningView

```kotlin
"WarningView": {
"backgroundColor": "#DBE0E5",
"colorText": "#000000",
"iconImageColor": "#FFFFFF",
"iconBackgroundColor": "#6A6E75",
"fontName": "Times",
"fontSize": 16.0
}
```

- `backgroundColor`: cor de fundo


- `colorText`: cor do texto


- `iconImageColor`: cor do icone de alerta


- `iconBackgroundColor`: fundo a view onde está o icone de alerta


- `colorLoader`: cor do pregresso


- `fontName`: nome da fonte family


- `fontSize`: tamanho do texto


Abaixo a relação de telas e componentes com os seus respectivos nomes, e tipos:


### Header Flui (DEPRECIADO)

- backgroundColor

### Header Flui

- statusBarBackgroundColor


- navigationBackgroundColor

### Inserir valor

![Imagem1-20240927-141423.png](images-ios/img_33.png)

1- ivLabel1 - labelFlui

2- ivLabelPrefixCurrency - labelFlui

3- ivTextField1 - inputWithEdit

4- ivButton1 - buttonBlock

### Selecionar forma de pagamento

1- sptLabel1 - labelFlui

2- spLabelPrefixCurrency - labelFlui

3- sptLabel2 - labelFlui

4- sptTextField1 - inputWithEdit

5- sptLabel3 - labelFlui

6- sptRadio1 - radio

7- sptInstallments1 - installmentsDetails

8- sptButton1 - buttonBlock

### Modal Parcelas

1- sptBottomSheet1 - bottomSheetFlui

### Minhas vendas

![mysales-20240621-125838.png](images-ios/img_10.png)

1- slLabel1 - labelFlui

2- saleCard

### Show agenda (Sem dados)

1- slLabelNoResults - labelFlui

### Show agenda (tela de error)

![list_error-20240624-181011.png](images-ios/img_20.png)

1- sbLabelReload - labelFlui

2- slButtonReload - buttonBlock

### Detalhes da venda

1- sdLabelTitle - labelFlui

2- saleDetailStatus

3- sdcLabel - labelFlui

4- sdcLabelContent - labelFlui

5- sdLabelInstruction - labelFlui

6- sdButton1 - ButtonBlock

1- odsLabel1 - labelFlui

2- odsLabel2 - labelFlui

### Tela de error

1- erLabel1 - labelFlui

2- erLabel2 - labelFlui

3- erButton1 - buttonBlock

### Loader

1- loader

### Tela de sucesso

- fbsLabel1 - labelFlui


- fbsLabel2 - labelFlui


- fbsLabel3 - labelFlui


- fbsButton1 - buttonBlock

### Comprovante

- receipt

### BottomSheet

![imagem](images-ios/img_30.png)

- ccTitle - labelFlui


- ccBody - labelFlui


- ccConfirm - buttonBlock


- ccBack - buttonBlock

### Introdução**:**

![imagem](images-ios/img_15.png)

- fkiLabel1 - LabelFlui


- fkiLabel2 - LabelFlui


- fkiLabel3 - LabelFlui


- fkiwView1 - WarningView


- fkiwButtonNext - ButtonBlock

### Inserir valor**:**

![imagem](images-ios/img_08.png)

- ivLabel1 - labelFlui


- ivLabelPrefixCurrency - labelFlui


- ivTextField1 - inputWithEdit


- ivWarningFakeSale - WarningView


- ivButton1 - buttonBlock

### Seleção do tipo de pagamento**:**

- sptLabel1 - labelFlui


- spLabelPrefixCurrency - labelFlui


- sptLabel2 - labelFlui


- sptTextField1 - inputWithEdit


- sptWarningTestSale - WarningView


- sptLabel3 - labelFlui


- sptRadio1 - radio


- sptInstallments1 - installmentsDetails


- sptButton1 - buttonBlock

### Sucesso

![image-20250616-173129.png](images-ios/img_25.png)

- fbsLabel1 - labelFlui


- fbsLabel2 - labelFlui


- fbsLabel3 - labelFlui


- fksWarning - WarningView


- fbsButton1 - buttonBlock

### Error para transação teste para tipo 01

- fkeLabel1 - labelFlui


- fkeLabel2 - labelFlui


- fkeLabel3 - labelFlui


- fkeLabel4 - labelFlui


- fkeWarning - warning


- fkeNextButton - buttonBlock

### Error para transação teste para tipo 02

- fkeLabel1 - labelFlui


- fkeLabel2 - labelFlui


- fkeWarning - warning


- fkeNextButton - buttonBlock

Utilize o JSON abaixo como exemplo para alterar as cores:

# Tratamento de erros

Durante a integração haverá algumas exceções que podem ser levantas por algum erro interno, validação de dados ou mesmo algum problema de implementação, por exemplo, não realizar a inicialização, ou informar valores inválidos para transacionar.

Caso haja algum problema durante o processo temos os seguintes erros:

```kotlin
enum TapOnPhoneErrors: Error {
case getSaleDetail //Erro ao tentar pegar os detalhes de uma venda
case getSaleList //Erro ao tentar carregar as lista de vendas do usuario
case deviceCheckError //Erro relacionado a verificação do device para uso do SDK
case deviceIncompatibleException //Erro relacionado a um device incompátivel com o SDK
case invalidAppleToken //Erro ao tentar pegar o token da Apple (Fingerprint)
case invalidDeviceId //Erro ao tentar pegar o id do device
case noAvailableSpace //Erro relacionado ao verificar se o device tem espaço em disco para usar o SDK
case invalidPaymentData //Dados de pagamento informados são invalidos
case unableToConfirmTransaction //Erro ao tentar salvar uma transação
case appleTapPrepareError //Erro ao inicializar o AppleTap
case cancelationException //Erro no Cancelamento
case invalidInitialData //Dados de configuração inicial incorretos 
case invalidMerchantNumber //Erro no número do Comerciante
case invalidPaymentMethod //Erro do método de pagamento inválido
case invalidReceiptData //Dados do comprovante inválidos
case unableToGetPaymentInfo //Erro ao recuperar dados do pagamento
case unspecifiedError(Error) //Erro genérico
case paymentError //Erro no pagamento
case errorPreparingDevice //Erro ao prepar o aparelho
case documentNotProvided //Documento não informado
case osVersionNotSupported // Quando o sistema operacional do aparelho não ter suporte ao card reader.
case fileNotFound // Quando um arquivo de whitelabel informado não exitir
case conversionFailed // Quando o arquivo de whitelabel tiver no padrão de JSON.
case invalidJson // Quando o arquivo de whitelabel estiver algum algum problema
case genericError(Error) //Erro genérico
case accountAlreadyLinked //Um erro que indica já aceitou os Termos e Condições.
case errorLinkingAccount(Error) // Erro durante o processo de linkar a conta
case accountLinkingCancelled // Quando o usuário cancela o processo de linkar a conta
}
```

Sabendo disso, passamos o controle para o parceiro integrador se adequar aos erros, e notificar o usuário conforme necessidade.

Os erros podem ser levantados diretamente pelos métodos através de um throw ou retornados pelo failure dos métodos de retorno. Verifique a documentação de cada método para preparar a sua chamada de acordo.


# **Conclusão**

Este guia forneceu uma visão geral dos requisitos do SDK iOS e de como pode ser feita a sua inicialização e customização.
