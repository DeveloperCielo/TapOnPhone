# Release Notes — SDK Cielo TAP iOS

# Release Notes SDK Cielo TAP iOS

O documento abaixo tem o objetivo de detalhar as modificações realizadas nas versões do SDK Cielo TAP iOS.

| ****Legenda**** 
| ****Descrição**** 
|


| n/m 
| Não mudou 
|


| n/c 
| Não criado 
|


| p/o 
| Pacote oficial (todos os pacotes foram enviados para parceiros) 
|

# p/o - v2.1.0 - 23/02/2026


### Descrição:

- Nova logo elo

- A bandeira Elo recentemente revisou a sua identidade visual. O SDK de Tap on Phone realizou a incorporação da nova logomarca e está em conformidade com o boletim da bandeira.

- Prepare em background

- Implementamos um novo processo de preparação em background, permitindo carregar informações de forma antecipada. Essa melhoria reduz o tempo de execução durante o *initPayment*.

- Tap on phone: v2.1.0


- AllowMe: v3.3.13


- VisaSensoryBranding: v2.2.0


- Dynatrace: v8.311.1

# p/o - v2.0.1 - 04/12/2025


### Descrição:

- Correção problema com PLCrashReport

- Essa versão ajustar problema que ocorria esporadicamente e estava relacionado à classe **PLCrashReport**, garantindo maior estabilidade.

- Inclusão da nova bandeira amex

- Inclusão animação de bandeira para transações realizadas com bandeira AMEX


- Inclusão de ícone da bandeira amex na lista de transações(show Agenda)

- Atualização da allowMe para correção de bug que ocorre durante o setup


- Correção de problema encontrado na versão 1.7.0:

- Durante a utilização do método initPayment, quando informado o callback onStart, estava perdendo a referência impedindo que o TapOnPhone acionasse o callback.

### Versão das dependências:

- Tap on phone: v2.0.1


- AllowMe: v3.3.13


- VisaSensoryBranding: v2.2.0


- Dynatrace: v8.311.1

# p/o - v1.7.0 - 29/09/2025


### Descrição:

- Correção na troca de telas usando o loadingDefault

- Ao utilizar a tela de loading padrão, foi identificado um problema em que a interface do cliente parceiro era exibida brevemente antes da transição para a tela do SDK.

- Inclusão de um novo método do initPayment

- Implementamos o novo método initPayment com o objetivo de notificar o cliente parceiro assim que o pagamento for concluído com sucesso. Essa notificação será enviada imediatamente após a exibição da animação das bandeiras.

### Versão das dependências:

- Tap on phone: v1.7.0


- AllowMe: 3.3.10


- VisaSensoryBranding: 2.2.0


- Dynatrace: 8.311.1

# p/o - v1.6.1 - 27/08/2025


### Descrição:

- Atualização da biblioteca da allowMe.

- Essa atualização tem como objetivo corrigir falhas na validação da chave de segurança(cryptoError) gerada pela biblioteca.

### Versão das dependências:

- Tap on phone: v1.6.1


- AllowMe: 3.3.10


- VisaSensoryBranding: 2.2.0


- Dynatrace: 8.311.1

# p/o - v1.6.0 - 21/08/2025


### Descrição:

- Ajuste na tela de erro para exibir o código de erro;

- Será exibida a tela de erro para todos erros durante o fluxo de inicialização. As telas apenas serão apresentadas caso o parâmetro ***defaultErrorScreen (true)** e **silentInit (false) *** (Para maiores informações consultar o manual).


- Quando ocorrer um erro durante a inicializar será possível visualizar um código na tela de erro.

- Callback de erro retornando o código da falha;

- Quando ocorrer um erro durante uma inicializar, será possível receber o código de falha no **completion** com enum **initializerFailure**.

- Exposição do métodos SalesList e SalesDetail

- O SalesList é um objeto com dados de vendas realizadas no SDK (Para maiores informações consultar o manual)


- O SalesDetail é um objeto contendo informações detalhas de uma venda (Para maiores informações consultar o manual)

### Versão das dependências:

- Tap on phone: v1.6.0


- AllowMe: 3.3.8


- VisaSensoryBranding: 2.2.0


- Dynatrace: 8.311.1

# p/o - v1.5.0 - 07/07/2025


### Descrição:

- Correção para IOS 26;

- Foi identificada uma falha do AllowMe no IOS 26.

- Melhoria na visualização de layout;

- Melhoria no layout do loading


- Inclusão de algumas chaves de linguagens faltantes.

- Melhoria em alguns componentes do WHITE LABEL;

- Equalização de componentes para tornar mais próximo do android

- Inclusão do venda teste.

- Liberação dos métodos fakeTransactionInitPayment e initFakeTransactionJourney com o objetivo de demonstrar aos clientes o funcionamento do pagamento via TapOnPhone.

### Versão das dependências:

- Tap on phone: v1.5.0


- AllowMe: 3.3.8


- VisaSensoryBranding: 2.2.0


- Dynatrace: 8.311.1

# p/o - v1.4.1 - 14/05/2025


### Descrição:

- Ajustes de comportamento:

- Habilitado Session Debug


- Habilitado Arquiteturas x86 (Simulador)

- Gerenciamento de dependências:

- Allowme: Bump da versão 3.3.4 para habilitar o proxy

### Versão das dependências:

- Tap on phone: v1.4.1


- AllowMe: 3.3.4


- VisaSensoryBranding: 2.2.0


- Dynatrace: 8.311.1

# p/o - v1.4.0 - 17/04/2025


### Descrição:

- White label:

- Adição nomenclatura atributos

- Gerenciamento de dependências:

- Allowme: Bump da versão 3.3.2

- Fluxos Transacionais:

- Ajuste no comportamento do loading nativo (não custom) ao aparecer

- Remoção Integração dos tracers no Datadog


- Ofuscação XCFramework


- função isUserActive(Consultar manual para maiores informações)

### Versão das dependências:

- Tap on phone: v1.4.0


- AllowMe: 3.3.2


- VisaSensoryBranding: 2.2.0


- Dynatrace: 8.311.1

# p/o - v1.3.0 - 25/02/2025


### Descrição:

- White label:

- Correção nomenclatura atributos


- Correção cor status bar

- Gerenciamento de dependências:

- Dynatrace: Integração + Logs


- Allowme: gerenciamento de dependencia via script

- Fluxos Transacionais:

- Ajuste quando app entra em background durante o processando.


- Fluxo transacional: Confirmação + Undo em sequencia


- Ação voltar: Adicionado callback para capturar retorno


- Data: Correção na formatação da data ao usar o formato de 12h

### Versão das dependências:

- Tap on phone: v1.3.0


- AllowMe: 3.1.4


- VisaSensoryBranding: 2.2.0


- Dynatrace: v8.307.1

# p/o - v1.2.2 - 12/02/2025


### Descrição:

- White label:

- Separar a propriedades para status bar e navigation


- Ajuste para possibilitar alteração da status bar nas telas de feedback(sucesso e error)


- Correção ao aplicar cor no botão voltar


- Correção ao aplicar cor no componente textPrice do showAgenda

### Versão das dependências:

- Tap on phone: v1.2.2


- AllowMe: 3.1.4


- VisaSensoryBranding: 2.2.0

# p/o - v1.2.1 - 17/01/2025


### Descrição:

- Fix do showAgenda - Quando aberto o show agenda e tocado sobre o botão voltar, e tentar abrir novamente o SDK impedia à abertura.

### Versão das dependências:

- Tap on phone: v1.2.1


- AllowMe: 3.1.4


- VisaSensoryBranding: 2.2.0

# p/o - v1.2.0 - 10/01/2025


### Descrição:

- Certificado MTLS

- Certificado antigo removido e URL base atualizada

- Fix na inicialização do app

- Foi adicionados continuation.resume para tratar assíncrona de execução

- Adicionado logs nas camadas de networkFeature proteção para chamadas duplicadas


- Fix quando o token expira na chamada do isAccountLinked.


- Fix do White Label - ajuste no headerFlui - aparência do UINavigationBar:wq

### Versão das dependências:

- Tap on phone: v1.2.0


- AllowMe: 3.1.4


- VisaSensoryBranding: 2.2.0

# p/o - v1.1.0 - 02/01/2025


### Descrição:

- Inclusão de logs nas camadas de Network Service


- Correções de estabilidade

### Versão das dependências:

- Tap on phone: 1.1.0


- AllowMe: 3.1.4


- VisaSensoryBranding: 2.2.0

# v1.0.0 - 02/09/2024


### Descrição:

- Versão inicial de lançamento do SDK TAP iOS

- Features inclusas:

- Transacional


- Listagem de Transações


- Estorno de transações

### Versão das dependências:

- Tap on phone: v1.0.0


- AllowMe: 3.1.4


- VisaSensoryBranding: 2.2.0
