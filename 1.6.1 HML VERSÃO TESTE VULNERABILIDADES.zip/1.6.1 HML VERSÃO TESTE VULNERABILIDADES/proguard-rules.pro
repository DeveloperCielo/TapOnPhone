-keep class sym.** { *; }
-keep enum sym.** { *; }
-keepclassmembers class sym.** { *; }
-keepclassmembers enum sym.** { *; }
-keepnames class sym.** { *; }
-keepnames enum sym.** { *; }
-keep class net.danlew.** { *; }
-keep class sym.c.n.** { *; }
-keepnames class net.danlew.** { *; }
-keepclassmembers class net.danlew.** { *; }
-keep class com.mastercard.** { *; }
-keep class com.combateafraude.helpers.server.model.** { <fields>; }

-keep class com.appdynamics.eumagent.runtime.DontObfuscate
-keep @com.appdynamics.eumagent.runtime.DontObfuscate class * { *; }

-keep class sym.c.** { *; }
-keepnames class sym.c.** { *; }
-keepclassmembers class sym.c.** { *; }
-keep enum sym.c.** { *; }
-keepnames enum sym.c.** { *; }
-keepclassmembers enum sym.c.** { *; }

-keep class com.symbiotic.** { *; }
-keepnames class com.symbiotic.** { *; }
-keepclassmembers class com.symbiotic.** { *; }
-keep enum com.symbiotic.** { *; }
-keepnames enum com.symbiotic.** { *; }
-keepclassmembers enum com.symbiotic.** { *; }
-dontwarn com.mastercard.terminalsdk.**
-keep class com.mastercard.terminalsdk.** {*;}
-keep class com.mastercard.terminalsdk.**$** {*;}
-keep interface com.mastercard.terminalsdk.** { *; }
-keep enum com.mastercard.terminalsdk.** { *; }
-keep class com.visa.** {*;}
-keep class com.visa.**$** {*;}
-keep enum com.visa.** { *; }

-keepattributes SourceFile,LineNumberTable
-keep public class * extends java.lang.Exception


# ---------------Begin: proguard configuration for Gson  ----------
 # Gson specific classes
-keep class sun.misc.Unsafe {
    <fields>;
    <methods>;
}
 # Application classes that will be serialized/deserialized over Gson
-keep class com.google.gson.examples.android.model.** {
    <fields>;
    <methods>;
}
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer
 # ---------------End: proguard configuration for Gson  ----------

 # ===APP 1=== BEGIN: Do not re-obfuscate Terminal SDK Jar ======
-keep class com.mastercard.terminalsdk.** {*;}
-keep class com.mastercard.terminalsdk.**$** {*;}
-keep interface com.mastercard.terminalsdk.** { *; }
-keep enum com.mastercard.terminalsdk.** { *; }
 # ===APP 1=== END: Do not re-obfuscate Terminal SDK Jar ======

 # ===APP 2=== BEGIN: Do not obfuscate references to GSON ======
 -keep class com.google.gson.**{*;}
 # ===APP 2=== END: Do not obfuscate references to GSON ======

 ##---------------Begin: proguard configuration for BouncyCastle  ----------
-keep class org.bouncycastle.** { *; }
-keepnames class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
  ##---------------End: proguard configuration for BouncyCastle  ----------

  ##---------------Begin: proguard configuration for SpongyCastle  ----------
-keep class org.spongycastle.** { *; }
-keepclasseswithmembernames class javax.crypto.**
-keepclasseswithmembernames class javax.crypto.Cipher
-keep interface javax.crypto.** { *; }
-keepclasseswithmembernames class java.security.**
-keep interface java.security.**
-keepclasseswithmembernames class java.security.** { *; }
-keep interface java.security.** { *; }
-keepclasseswithmembernames class java.security.Key
  ##---------------End: proguard configuration for SpongyCastle  ----------

  ##---------------Begin: proguard configuration for JsonWebToken  ----------
-keep class io.jsonwebtoken.** { *; }
-keepnames class io.jsonwebtoken.** { *; }
-keepnames interface io.jsonwebtoken.** { *; }
  ##---------------End: proguard configuration for JsonWebToken ----------

-dontwarn org.joda.convert.**
-dontwarn org.joda.time.**
-keep class org.joda.time.** { *; }
-keep interface org.joda.time.** { *; }
-keep class net.danlew.** { *; }

-keep class com.airbnb.** { *; }
-keep class br.com.allowme.** { *; }
-keep class com.americanexpress.** { *; }
-keep class sym.c.k1.** { *; }
-keep class sym.c.j1.** { *; }
-keep class com.discover.** { *; }
-keep class com.e.d.** { *; }
-keep class com.facebook.** { *; }
-keep class com.scottyab.** { *; }
-keep class br.com.cielo.** { *; }

-keep class br.com.allowme.android.** {*;}
-keep class br.com.allowme.android.**$** {*;}

-keep class br.com.cielo.** { *; }
-keepnames class br.com.cielo.** { *; }
-keepclassmembers class br.com.cielo.** { *; }

-keep class retrofit2.** { *; }
-keepattributes *Annotation*
-keep class com.squareup.okhttp.** { *; }
-keep interface com.squareup.okhttp.** { *; }
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }

-keep class com.github.luben.** {*;}
-dontwarn com.github.luben.zstd.ZstdInputStream
-dontwarn com.github.luben.zstd.ZstdOutputStream

-keep class org.brotli.** {*;}
-dontwarn org.brotli.dec.BrotliInputStream

-keep class org.tukaani.** {*;}
-dontwarn org.tukaani.xz.ARMOptions
-dontwarn org.tukaani.xz.ARMThumbOptions
-dontwarn org.tukaani.xz.DeltaOptions
-dontwarn org.tukaani.xz.FilterOptions
-dontwarn org.tukaani.xz.FinishableOutputStream
-dontwarn org.tukaani.xz.FinishableWrapperOutputStream
-dontwarn org.tukaani.xz.IA64Options
-dontwarn org.tukaani.xz.LZMA2InputStream
-dontwarn org.tukaani.xz.LZMA2Options
-dontwarn org.tukaani.xz.LZMAInputStream
-dontwarn org.tukaani.xz.LZMAOutputStream
-dontwarn org.tukaani.xz.MemoryLimitException
-dontwarn org.tukaani.xz.PowerPCOptions
-dontwarn org.tukaani.xz.SPARCOptions
-dontwarn org.tukaani.xz.SingleXZInputStream
-dontwarn org.tukaani.xz.UnsupportedOptionsException
-dontwarn org.tukaani.xz.X86Options
-dontwarn org.tukaani.xz.XZ
-dontwarn org.tukaani.xz.XZInputStream
-dontwarn org.tukaani.xz.XZOutputStream

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn org.apache.avalon.framework.logger.Logger
-dontwarn org.apache.log.Hierarchy
-dontwarn org.apache.log.Logger
-dontwarn org.apache.log4j.Level
-dontwarn org.apache.log4j.Logger
-dontwarn org.apache.log4j.Priority

-dontwarn org.apache.http.**
-dontwarn android.net.**
-keep class org.apache.** {*;}
-keep class org.apache.http.** { *; }

-keep class org.apache.commons.** {*;}
-dontwarn org.apache.commons.**

#OPCIONAL - DE ACORDO COM O PROJETO QUE ESTIVER INTEGRANDO
#AS SEGUINTES CONFIGURAÇÕES DE PROGUARD SERÃO NECESSÁRIAS
# Regras para androidx.security.crypto
-keepclassmembers class androidx.security.crypto.** { *; }
-keep class androidx.security.crypto.** { *; }

# Regras para manter as classes e métodos usados por EncryptedSharedPreferences e EncryptedFile
-keep class javax.crypto.spec.SecretKeySpec { *; }
-keep class javax.crypto.Cipher { *; }
-keep class javax.crypto.KeyGenerator { *; }
-keep class javax.crypto.Mac { *; }

# Manter classes específicas que podem ser usadas pelo MasterKeys
-keep class androidx.security.crypto.MasterKeys { *; }

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn com.visa.CheckmarkMode
-dontwarn javax.naming.NamingEnumeration
-dontwarn javax.naming.NamingException
-dontwarn javax.naming.directory.Attribute
-dontwarn javax.naming.directory.Attributes
-dontwarn javax.naming.directory.DirContext
-dontwarn javax.naming.directory.InitialDirContext
-dontwarn javax.naming.directory.SearchControls
-dontwarn javax.naming.directory.SearchResult
-dontwarn kotlinx.parcelize.Parcelize

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn com.fasterxml.jackson.annotation.JsonInclude$Include
-dontwarn com.fasterxml.jackson.annotation.JsonInclude
-dontwarn com.fasterxml.jackson.annotation.JsonProperty
-dontwarn com.fasterxml.jackson.core.type.TypeReference
-dontwarn com.fasterxml.jackson.databind.ObjectMapper
-dontwarn com.github.gcacace.signaturepad.views.SignaturePad
-dontwarn java.lang.reflect.AnnotatedType